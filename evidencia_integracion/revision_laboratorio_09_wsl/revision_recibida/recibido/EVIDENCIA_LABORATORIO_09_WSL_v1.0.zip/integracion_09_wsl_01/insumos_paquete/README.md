# Integración del laboratorio 9 · preparada para revisión

Este paquete incorpora el laboratorio de confiabilidad y seguridad, su distribución autónoma, la ampliación del verificador común y la continuidad documental del cierre del laboratorio 8. La aplicación se prepara en una rama local y termina con evidencia para revisión. No autoriza commit, integración en main, etiquetas ni push.

## Empieza aquí

1. Conserva el ZIP original y descomprime esta carpeta junto al repositorio autorizado.
2. Ejecuta `python -B VERIFICAR_PAQUETE.py`. Debe aprobar todas las entradas y la cobertura completa de `SHA256SUMS`.
3. Para Git Bash de Windows, sigue `INSTRUCCIONES_WINDOWS.md` paso a paso. Para delegar el trabajo a Codex, utiliza `PROMPT_INTEGRACION_CODEX_LAB09_v1.0.md` dentro del proyecto existente.
4. Conserva cada ejecución en una carpeta nueva. El auxiliar `EJECUTAR_VERIFICACION.py` captura las pruebas y comprueba las huellas finales; `EMPAQUETAR_EVIDENCIA.py` prepara el ZIP que se revisará antes del cierre.

El manifiesto identifica los bytes del paquete recibido; no es una firma digital del editor. No modifiques el paquete para hacer coincidir una comprobación. Si hay un conflicto con una base avanzada, conserva el trabajo y documenta la adaptación por separado.

## Identidad de la preparación

| Elemento | Identidad |
| --- | --- |
| Commit de partida | `9212ee99b88f70f0b289837b88d6bbf34da91a52` |
| Árbol de partida | `d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0` |
| Árbol preparado | `251105483bc5bef040c57dc3a036d5bc3a7e0da0` |
| Rama utilizada al preparar | `integracion/laboratorio-09` |
| Etiquetas previstas, todavía ausentes | `lab-09-v1.0`, `repositorio-v1.5` |

`BASE_INTEGRACION.json` registra las 771 rutas del parche, su SHA-256 y la consulta remota de sólo lectura. Main y las etiquetas históricas permanecieron sin cambios. El árbol preparado identifica contenido; no es un commit nuevo ni una publicación.

## Qué contiene

- `INTEGRAR_LABORATORIO_09.patch`: cambio binario completo, probado sobre una copia limpia de la base registrada.
- `BASE_INTEGRACION.json`: identidad de base y resultado, rutas, huella del parche y referencias consultadas.
- `VERIFICAR_PAQUETE.py` y `SHA256SUMS`: comprobación de bytes y cobertura del paquete.
- `REGISTRAR_ESTADO.py`: observación inicial y preparada, con consultas de Git y del remoto; no publica.
- `EJECUTAR_VERIFICACION.py`: ocho pruebas del recolector, nueve del evaluador, cuatro de recursos SQLite y conjunto funcional con navegador, contados por separado.
- `EMPAQUETAR_EVIDENCIA.py`: envío de una carpeta de evidencia nueva sin modificar los originales.
- `INSTRUCCIONES_WINDOWS.md` y el prompt para Codex: preparación, dependencias, aplicación, verificación y límite del encargo.
- Los estados `ESTADO_DEL_LIBRO_v1.8.md` y `ESTADO_REPOSITORIO_v1.7.md`.
- `evidencia/`: aplicación real del parche, verificación en esa copia, conservación de archivos y revisión final. Estas observaciones quedan fuera del árbol que acreditan para evitar una referencia circular.

Dentro del parche se conservan por separado las evidencias originales, las pruebas nuevas de producción, el ensayo del ZIP autónomo y la incorporación exacta del cierre del laboratorio 8. Los manuscritos permanecen en la entrega editorial y no se añaden al repositorio técnico.

## Cómo leer los resultados

La expectativa funcional para esta versión completa es: 92 baterías, 805 ejecuciones, 781 APROBADO y 24 FALLIDO didácticos exactos, cero bloqueos. Los 48 NO EJECUTADO históricos dentro de baterías y diez criterios ausentes se registran aparte. La solución del laboratorio 9 debe aprobar 74 de 74 casos. Los resultados realmente observados están en cada `resumen.json`; estas cifras de referencia no sustituyen la ejecución del autor.

Las ocho, nueve y cuatro pruebas de infraestructura no se suman al total funcional. Tampoco se suman entre sí las repeticiones de producción, ZIP y parche para aparentar mayor cobertura. El comprobador verifica todas las huellas declaradas; no se fija un recuento histórico obligatorio.

El ensayo de este paquete se realizó en Linux con HTTP y navegador locales. La consulta remota está documentada por separado. Las llamadas a `REGISTRAR_ESTADO.py` dentro de la copia de ensayo utilizan `--sin-consulta-remota` porque su origen es otra copia local: lo registran como NO EJECUTADO remoto, sin convertirlo en una nueva consulta de GitHub.

La futura ejecución en Windows o WSL es una evidencia nueva pendiente. Las 583 ejecuciones Windows históricas y el cierre posterior WSL del laboratorio 8 conservan su atribución original. Los capítulos 1–9 continúan pendientes de revisión editorial del autor. No se redactó el capítulo 10.
