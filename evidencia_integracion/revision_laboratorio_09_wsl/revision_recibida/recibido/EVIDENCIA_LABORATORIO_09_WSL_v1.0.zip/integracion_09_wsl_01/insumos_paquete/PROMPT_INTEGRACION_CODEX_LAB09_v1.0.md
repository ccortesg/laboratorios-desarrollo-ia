# Encargo para Codex: preparar y verificar la integración del laboratorio 9

Trabaja en el proyecto existente `laboratorios-desarrollo-ia`. Localiza el paquete `INTEGRACION_LABORATORIO_09_v1.0` descomprimido junto al repositorio o entre los archivos que te adjunto. No accedas a otros proyectos.

Lee `INSTRUCCIONES_WINDOWS.md`, `BASE_INTEGRACION.json` y los auxiliares del paquete; después lee `AGENTS.md`, `CONTINUIDAD.md` y los estados vigentes del repositorio. Ejecuta la preparación y verificación completas con autonomía en las decisiones rutinarias. Mantén el alcance exclusivamente en el proyecto sintético del libro.

Base probada del paquete:

- Commit: `9212ee99b88f70f0b289837b88d6bbf34da91a52`.
- Árbol: `d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0`.
- `main`, `lab-08-v1.0` y `repositorio-v1.4` coincidían con ese commit al preparar el paquete. Comprueba nuevamente las referencias sin modificar etiquetas.

Primero identifica el entorno real: Windows nativo/Git Bash o WSL/Linux. Registra las versiones efectivas y adapta las rutas. No atribuyas una ejecución Linux a Windows. Si no tienes terminal o acceso a la carpeta, indícalo sin simular operaciones.

Verifica el manifiesto del paquete. Revisa los cambios existentes antes de actuar y conserva cualquier trabajo del autor. Utiliza una rama local identificable distinta de `main`. Consulta `origin/main` sin traer ni forzar etiquetas. Si avanzó, conserva sus cambios y revisa su relación con la base; adapta la integración en una rama aislada si resulta necesario. No uses reset destructivo, limpieza de archivos ni sobreescritura de cambios para recuperar la base anterior.

Comprueba la aplicabilidad del parche y aplícalo una sola vez. Distingue `git apply --check --index` de `git apply --index`: el primero sólo comprueba. Si el árbol ya coincide con el preparado, no reapliques el parche. Si hay diferencias, investígalas y registra la identidad realmente verificada.

Prepara las dependencias de navegador descritas en el paquete. Ejecuta `REGISTRAR_ESTADO.py` para los estados inicial y preparado y `EJECUTAR_VERIFICACION.py` sobre una carpeta nueva de `trabajo/`. El segundo auxiliar conserva las ocho pruebas del recolector, nueve del evaluador, cuatro regresiones de recursos SQLite y la verificación conjunta con navegador. Mantén separados sus conteos. Verifica todas las huellas declaradas contra los bytes finales, sin cambiar evidencia histórica.

Los fallos didácticos deben coincidir exactamente con los documentados. Un error de ejecución, TimeoutExpired o fallo adicional es un problema pendiente; no lo conviertas en esperado. Resuelve los problemas de entorno dentro del alcance autorizado, conserva cada intento y repite en una carpeta nueva. No ajustes las expectativas heredadas para conseguir una aprobación.

Al terminar, compara main, HEAD, etiquetas, índice y cambios sin preparar con los registros iniciales. Empaqueta la evidencia nueva con `EMPAQUETAR_EVIDENCIA.py`, indicando Windows o WSL según corresponda. Entrega el ZIP, su SHA-256 y un informe con base utilizada, árbol preparado, resultados funcionales, pruebas de infraestructura separadas, huellas y límites. Las cifras esperadas del paquete no sustituyen los resultados de tu ejecución.

Termina con la integración preparada para revisión: **no crees un commit, no integres en main, no crees ni muevas etiquetas y no hagas push**. `lab-09-v1.0` y `repositorio-v1.5` son sólo nombres previstos para un cierre posterior autorizado.

Conserva la revisión editorial pendiente de los capítulos 1–9. No modifiques manuscritos ni redactes el capítulo 10. Los estados del libro y del repositorio incluidos en el parche documentan esta preparación; la ejecución nueva que realices se entrega aparte como evidencia posterior, sin sobrescribirla.
