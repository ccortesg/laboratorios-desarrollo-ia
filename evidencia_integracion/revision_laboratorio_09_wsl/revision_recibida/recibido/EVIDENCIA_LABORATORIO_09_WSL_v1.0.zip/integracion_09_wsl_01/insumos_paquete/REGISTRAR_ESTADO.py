"""Registra una observación Git sin modificar código, índice ni referencias."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sqlite3
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repositorio", type=Path, default=Path("."))
    parser.add_argument("--fase", choices=("antes", "preparado"), required=True)
    parser.add_argument("--salida", type=Path, required=True)
    parser.add_argument("--sin-consulta-remota", action="store_true",
                        help="Sólo para ensayos desconectados; registra NO EJECUTADO remoto.")
    args = parser.parse_args()
    repo = args.repositorio.resolve()
    paquete = Path(__file__).resolve().parent
    base = json.loads((paquete / "BASE_INTEGRACION.json").read_text("utf-8"))
    if args.salida.exists():
        raise ValueError("El registro ya existe; elige una salida nueva.")

    def ejecutar(*comando):
        return subprocess.run(comando, cwd=repo, capture_output=True)

    def git(*comando):
        p = ejecutar("git", *comando)
        if p.returncode:
            raise ValueError("No se pudo completar una consulta Git; se conserva el estado.")
        return p.stdout.decode("utf-8", errors="replace").strip()

    if git("rev-parse", "--show-toplevel").replace("\\", "/").casefold() != repo.as_posix().casefold():
        raise ValueError("Indica la raíz del repositorio.")
    rama = git("branch", "--show-current")
    head = git("rev-parse", "HEAD")
    if ejecutar("git", "merge-base", "--is-ancestor", base["commit_base"], head).returncode:
        raise ValueError("HEAD no conserva la base registrada; requiere revisión.")
    locales = dict((ref, sha) for sha, ref in
                   (linea.split() for linea in git("for-each-ref", "--format=%(objectname) %(refname)", "refs/tags").splitlines()))
    nuevos = ["refs/tags/" + nombre for nombre in base["etiquetas_previstas"]]
    if any(ref in locales for ref in nuevos):
        raise ValueError("Una etiqueta prevista ya existe; revisar sin moverla.")
    remotas = {}
    if not args.sin_consulta_remota:
        texto = git("ls-remote", "--refs", "origin", "refs/heads/main", "refs/tags/*")
        remotas = dict((ref, sha) for sha, ref in (l.split() for l in texto.splitlines()))
        for etiqueta in base["consulta_remota"]["etiquetas"]:
            if remotas.get(etiqueta["ref"]) != etiqueta["sha"]:
                raise ValueError("Una etiqueta histórica difiere; revisar sin forzarla.")
        if any(ref in remotas for ref in nuevos):
            raise ValueError("Una etiqueta prevista ya existe remotamente; revisar.")
    arbol_indice = git("write-tree")
    preparados = git("diff", "--cached", "--name-only").splitlines()
    sin_preparar = git("diff", "--name-only").splitlines()
    if args.fase == "antes":
        if git("status", "--porcelain"):
            raise ValueError("La preparación inicial requiere conservar y resolver primero los cambios existentes.")
    else:
        if rama in {"", "main"}:
            raise ValueError("La preparación debe estar en una rama identificable distinta de main.")
        if sin_preparar or ejecutar("git", "diff", "--cached", "--check").returncode:
            raise ValueError("Hay cambios sin preparar o problemas de formato; revisar.")
        if sorted(preparados) != sorted(base["rutas_parche"]):
            raise ValueError("Las rutas preparadas difieren del parche; revisar la adaptación sin sobrescribirla.")
        if head == base["commit_base"] and arbol_indice != base["arbol_preparado"]:
            raise ValueError("El árbol del índice no coincide con el paquete probado.")
    registro = {
        "fecha_hora_utc": datetime.now(timezone.utc).isoformat(), "fase": args.fase,
        "estado": "APROBADO", "rama": rama, "head": head,
        "arbol_head": git("rev-parse", "HEAD^{tree}"), "main_local": git("rev-parse", "main"),
        "arbol_indice": arbol_indice, "base_exacta": head == base["commit_base"],
        "arbol_esperado_paquete": base["arbol_preparado"],
        "coincide_arbol_paquete": arbol_indice == base["arbol_preparado"],
        "archivos_preparados": preparados, "archivos_sin_preparar": sin_preparar,
        "etiquetas_locales": locales, "referencias_remotas": remotas,
        "consulta_remota": "NO EJECUTADO" if args.sin_consulta_remota else "APROBADO",
        "git": git("--version"), "python": platform.python_version(),
        "sqlite": sqlite3.sqlite_version, "sistema": platform.system(),
        "sha256_parche": hashlib.sha256((paquete / "INTEGRAR_LABORATORIO_09.patch").read_bytes()).hexdigest(),
        "limites": ["El registro no ejecuta pruebas funcionales.",
                    "Una base avanzada requiere revisar sus diferencias y verificar el resultado compuesto."]
    }
    args.salida.parent.mkdir(parents=True, exist_ok=True)
    with args.salida.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(registro, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print("APROBADO: registro de " + args.fase + " guardado.")
    print("Base exacta:", registro["base_exacta"])
    print("Árbol del índice:", arbol_indice)
    if args.fase == "preparado" and not registro["base_exacta"]:
        print("Base avanzada: revisar su combinación; no se exige el árbol de la base antigua.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as error:
        print("FALLIDO:", str(error))
        raise SystemExit(1)
