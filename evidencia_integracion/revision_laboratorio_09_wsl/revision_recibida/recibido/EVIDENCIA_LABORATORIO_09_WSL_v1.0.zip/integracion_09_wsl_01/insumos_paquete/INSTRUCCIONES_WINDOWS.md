# Integración del laboratorio 9 en Git Bash de Windows

## Punto de cierre de esta entrega

Este procedimiento termina en una rama local con el parche preparado y evidencia nueva para revisión. No crea un commit, no integra en `main`, no crea ni mueve etiquetas y no hace push. Los nombres `lab-09-v1.0` y `repositorio-v1.5` quedan previstos para una autorización posterior.

Base probada: `9212ee99b88f70f0b289837b88d6bbf34da91a52`, árbol `d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0`. `BASE_INTEGRACION.json` contiene el árbol preparado exacto, las rutas del parche y las referencias consultadas. Las trece etiquetas anteriores se conservan.

Los comandos suponen el repositorio en `/c/github/laboratorios-desarrollo-ia` y este paquete descomprimido en `/c/github/INTEGRACION_LABORATORIO_09_v1.0`. Si tus carpetas son otras, cambia sólo esos prefijos. Copia cada bloque completo, sin el símbolo `$` de la terminal. No vuelvas a ejecutar un parche ya aplicado.

## 1. Verifica el paquete recibido

```bash
cd /c/github/INTEGRACION_LABORATORIO_09_v1.0
export PYTHONIOENCODING=utf-8
python -B VERIFICAR_PAQUETE.py
```

Debe indicar APROBADO y cobertura completa. Un SHA-256 coincidente comprueba los bytes contra el manifiesto recibido; no es una firma del editor. Conserva el ZIP original y este paquete sin modificaciones. Si falla, detén la aplicación y conserva su salida.

## 2. Revisa la copia y consulta el remoto

```bash
cd /c/github/laboratorios-desarrollo-ia
git status --short
git branch --show-current
git rev-parse HEAD
git rev-parse main
git tag --list lab-09-v1.0 repositorio-v1.5
git fetch --no-tags origin
```

El árbol de trabajo debe estar limpio y las etiquetas previstas deben estar ausentes. Si hay cambios, consérvalos: no uses `reset --hard`, `clean`, `checkout --` ni una aplicación forzada del parche. Termina o separa ese trabajo antes de continuar. Si `fetch` falla, resuelve el acceso sin avanzar; una variable consultada después de otro comando no conserva su código de salida.

El registro inicial comprueba la ascendencia de la base, consulta las etiquetas remotas, identifica el entorno real y guarda una observación nueva:

```bash
python -B /c/github/INTEGRACION_LABORATORIO_09_v1.0/REGISTRAR_ESTADO.py --repositorio . --fase antes --salida trabajo/integracion_09_windows_01/antes.json
```

No repitas la salida `antes.json` si ya existe. Para otro intento utiliza una carpeta `integracion_09_windows_02` y sustitúyela de forma consistente en los pasos restantes. El auxiliar no descarga código ni cambia referencias.

## 3. Prepara una rama y conserva cualquier avance de main

```bash
git switch -c integracion/laboratorio-09 main && git merge --ff-only origin/main
```

Sólo después de que ese bloque termine correctamente, consulta:

```bash
git rev-parse HEAD
git diff --name-status 9212ee99b88f70f0b289837b88d6bbf34da91a52 HEAD
```

Si la rama ya existe, consulta su estado; no la borres ni la recrees automáticamente. Si el avance rápido falla, conserva ambas ramas y solicita una revisión de su relación. `main` permanece sin cambios: el avance anterior se hace en la rama de integración.

Si HEAD sigue en la base registrada, la última comparación no muestra diferencias. Si avanzó, revisa esas diferencias antes de aplicar. El parche no debe descartar trabajo posterior. Un conflicto de aplicabilidad requiere adaptar el cambio en esta rama y registrar un árbol nuevo; no recuperar la base antigua sobre `main` ni forzar etiquetas. Una adaptación deja de ser el parche exacto ya probado y exige revisión y comprobaciones del resultado compuesto.

## 4. Comprueba y aplica una sola vez

Primero se comprueba, sin aplicar:

```bash
git apply --check --index /c/github/INTEGRACION_LABORATORIO_09_v1.0/INTEGRAR_LABORATORIO_09.patch
```

Sólo si el comando anterior termina sin errores, aplica realmente:

```bash
git apply --index /c/github/INTEGRACION_LABORATORIO_09_v1.0/INTEGRAR_LABORATORIO_09.patch
git diff --cached --check
git diff --name-only
git write-tree
git --no-pager diff --cached --stat
```

`--check` no incorpora archivos. `--index` sin `--check` sí los incorpora y prepara. La revisión de formato debe salir sin errores y `git diff --name-only` sin cambios pendientes fuera del índice. Si aparecen mensajes «already exists in index» o «patch does not apply», no insistas: revisa el árbol y comprueba si el parche ya está aplicado.

Registra y compara la preparación:

```bash
python -B /c/github/INTEGRACION_LABORATORIO_09_v1.0/REGISTRAR_ESTADO.py --repositorio . --fase preparado --salida trabajo/integracion_09_windows_01/preparado.json
```

Sobre la base exacta, el árbol debe coincidir con `BASE_INTEGRACION.json`. Sobre una base avanzada, se registra otra identidad; el auxiliar verifica ascendencia y rutas, pero no sustituye la revisión semántica de los cambios posteriores. Una adaptación que cambie las rutas se documenta y revisa expresamente en vez de alterar silenciosamente el paquete.

## 5. Prepara el navegador

Necesitas Python 3.11 o posterior, Git, Node y npm. Desde el laboratorio nuevo:

```bash
cd /c/github/laboratorios-desarrollo-ia/laboratorios/laboratorio_09
python --version
node --version
npm --version
npm install --ignore-scripts --package-lock=false
npx --no-install playwright --version
npx --no-install playwright install chromium
cd /c/github/laboratorios-desarrollo-ia
```

`package.json` fija Playwright 1.62.1. No debe quedar un `package-lock.json` nuevo. La preparación de herramientas puede acceder a sus distribuciones públicas; las pruebas funcionales se ejecutan sobre el catálogo sintético y HTTP local. `found 0 vulnerabilities` de npm no certifica la seguridad de la aplicación.

No reutilices una variable `LAB06_CHROMIUM` que señale a una ruta de otra máquina. Si existe por una configuración previa, comprueba su necesidad antes de usarla. La descarga del navegador o su inicio pueden quedar BLOQUEADO; conserva el diagnóstico y no declares aprobada la verificación completa sin navegador. Una ejecución desde WSL se registra como Linux/WSL, separada de Windows nativo.

## 6. Ejecuta y conserva las comprobaciones

El auxiliar siguiente ejecuta las ocho pruebas del recolector, las nueve del evaluador nuevo, las cuatro regresiones heredadas de recursos SQLite y la verificación funcional completa con navegador. Cada grupo conserva su captura y se contabiliza por separado. Usa una salida nueva:

```bash
export PYTHONIOENCODING=utf-8
python -B /c/github/INTEGRACION_LABORATORIO_09_v1.0/EJECUTAR_VERIFICACION.py --repositorio . --salida trabajo/integracion_09_windows_01/verificacion
codigo_revision_09=$?
printf 'Codigo de la revision: %s\n' "$codigo_revision_09"
```

El comando funcional que ejecuta internamente es:

```bash
python -B herramientas/verificar_todo.py --navegador --salida trabajo/integracion_09_windows_01/verificacion/conjunto
```

No lo repitas después sobre la misma carpeta. La versión combinada del auxiliar incluye capturas adicionales de infraestructura y no debe confundirse con el número de huellas del conjunto funcional.

Comprueba los bytes finales guardados, sin recalcularlos para cambiar su estado:

```bash
python herramientas/huellas_evidencia.py trabajo/integracion_09_windows_01/verificacion
python herramientas/huellas_evidencia.py trabajo/integracion_09_windows_01/verificacion/conjunto
```

No añadas `--esperadas 34` ni otro recuento histórico fijo. El auxiliar comprueba todas las huellas declaradas en la ejecución recibida. El resultado funcional esperado es 92 baterías, 805 ejecuciones, 781 APROBADO y 24 FALLIDO didácticos; cero bloqueos. Los 48 NO EJECUTADO en baterías y diez criterios ausentes se registran aparte. Estas cifras son expectativas de esta versión; los JSON de tu ejecución son la evidencia observada.

Los doce fallos didácticos históricos de los laboratorios 1–8 conservan su identidad. El laboratorio 9 añade nueve fallos de base frente a requisitos nuevos y tres de propuesta: S02.a/S02.b/S02.c. Su solución debe aprobar 74/74 casos. Un TimeoutExpired, un error de ejecución o cualquier otro fallo no forma parte de ese patrón. En tal caso conserva el intento, revisa su causa y repite en otra carpeta después de resolverla.

## 7. Conserva el estado para revisión

```bash
git branch --show-current
git rev-parse HEAD
git rev-parse main
git diff --name-only
git diff --cached --check
git write-tree
git status --short
```

El parche debe seguir preparado en la rama. `main` y las etiquetas anteriores deben conservarse; las carpetas `trabajo/` y `node_modules/` se ignoran. No añadas toda la carpeta de trabajo mediante `git add -f`.

Empaqueta la evidencia nueva, sin incluir dependencias ni datos ajenos al ejercicio:

```bash
python -B /c/github/INTEGRACION_LABORATORIO_09_v1.0/EMPAQUETAR_EVIDENCIA.py --origen trabajo/integracion_09_windows_01 --destino trabajo/EVIDENCIA_LABORATORIO_09_WINDOWS_v1.0.zip
```

Comparte ese ZIP y el informe del auxiliar para revisar el estado real. Si ejecutaste desde WSL, usa un nombre terminado en `_WSL_v1.0.zip` y conserva la atribución de Linux. El commit, la integración en `main`, las etiquetas y el push pertenecen al siguiente encargo. Los capítulos 1–9 siguen pendientes de revisión editorial del autor.
