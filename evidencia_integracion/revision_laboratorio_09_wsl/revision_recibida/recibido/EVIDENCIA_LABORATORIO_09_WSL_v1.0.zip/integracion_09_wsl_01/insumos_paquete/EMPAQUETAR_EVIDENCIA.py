"""Empaqueta sólo una carpeta de evidencia nueva, sin alterar sus archivos."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--origen", type=Path, required=True)
    p.add_argument("--destino", type=Path, required=True)
    a = p.parse_args()
    origen, destino = a.origen.resolve(), a.destino.resolve()
    if not origen.is_dir() or destino.exists() or destino.is_relative_to(origen):
        raise ValueError("Se requiere una carpeta existente y un ZIP nuevo fuera de ella.")
    objetos = sorted(origen.rglob("*"))
    if any(x.is_symlink() for x in objetos):
        raise ValueError("La evidencia no debe contener enlaces.")
    archivos = [x for x in objetos if x.is_file()]
    if not archivos:
        raise ValueError("La evidencia está vacía.")
    if any(x.suffix.lower() in {".sqlite", ".db"} or "node_modules" in x.parts for x in archivos):
        raise ValueError("La carpeta contiene bases o dependencias; selecciona sólo la evidencia.")
    if any(x.relative_to(origen).as_posix() == "MANIFIESTO_ENVIO.json" for x in archivos):
        raise ValueError("La carpeta ya incluye un manifiesto de envío con el nombre reservado.")
    entradas = [{"archivo": x.relative_to(origen).as_posix(), "bytes": x.stat().st_size,
                 "sha256": hashlib.sha256(x.read_bytes()).hexdigest()} for x in archivos]
    manifiesto = {"fecha_utc": datetime.now(timezone.utc).isoformat(),
                  "archivos": entradas,
                  "alcance": "Huellas del envío; no reemplazan las huellas de cada captura ni convierten fallos en aprobaciones."}
    destino.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(destino, "x", compression=ZIP_DEFLATED) as z:
        for archivo in archivos:
            z.write(archivo, arcname=origen.name + "/" + archivo.relative_to(origen).as_posix())
        z.writestr(origen.name + "/MANIFIESTO_ENVIO.json",
                   json.dumps(manifiesto, ensure_ascii=False, indent=2) + "\n")
    print("APROBADO: ZIP de evidencia creado; originales conservados.")
    print("Archivos de evidencia:", len(archivos))
    print("Entradas del ZIP incluido manifiesto:", len(archivos) + 1)
    print("SHA256:", hashlib.sha256(destino.read_bytes()).hexdigest())


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError) as error:
        print("FALLIDO:", str(error))
        raise SystemExit(1)
