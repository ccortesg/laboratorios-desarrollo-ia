"""Ejecuta la revisión local y conserva capturas nuevas; no publica ni hace commits."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import sqlite3
import subprocess
import sys
import tempfile


def ahora():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repositorio", type=Path, default=Path("."))
    parser.add_argument("--salida", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repositorio.resolve()
    salida = args.salida.resolve()
    if not (repo / "herramientas/huellas_evidencia.py").is_file():
        raise ValueError("No se encuentra el repositorio preparado.")
    if salida.exists():
        raise ValueError("La salida ya existe; utiliza una carpeta nueva.")
    if not salida.is_relative_to(repo / "trabajo"):
        raise ValueError("Guarda la ejecución en una carpeta nueva dentro de trabajo/.")
    git = lambda *a: subprocess.check_output(["git", *a], cwd=repo).decode("utf-8").strip()
    rama = git("branch", "--show-current")
    if rama in {"", "main"}:
        raise ValueError("Ejecuta en la rama de integración, conservando main.")
    if git("diff", "--name-only"):
        raise ValueError("Hay cambios sin preparar: revísalos antes de verificar.")
    arbol_antes = git("write-tree")
    referencias_antes = git("for-each-ref", "--format=%(objectname) %(refname)",
                           "refs/heads/main", "refs/tags")
    salida.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env.update(PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    registros = []
    cantidades = {"recolector": 8, "evaluador_09": 9, "recursos_sqlite": 4}
    tareas = [
        ("recolector", [sys.executable, "-B", "-m", "unittest", "discover",
                        "-s", "herramientas/pruebas", "-p", "test_huellas_evidencia.py", "-v"], 180),
        ("evaluador_09", [sys.executable, "-B", "-m", "unittest", "discover",
                           "-s", "herramientas/pruebas", "-p", "test_evaluador_laboratorio_09.py", "-v"], 180),
        ("recursos_sqlite", [sys.executable, "-B", "laboratorios/laboratorio_09/pruebas_recursos.py"], 180),
        ("conjunto", [sys.executable, "-B", "herramientas/verificar_todo.py", "--navegador",
                       "--salida", str(salida / "conjunto")], 1800),
    ]
    for nombre, comando, limite in tareas:
        print("Ejecutando " + nombre + "...", flush=True)
        inicio = ahora()
        try:
            p = subprocess.run(comando, cwd=repo, env=env, capture_output=True, timeout=limite)
            stdout, stderr, codigo = p.stdout, p.stderr, p.returncode
            estado = "APROBADO" if codigo == 0 else "BLOQUEADO" if codigo == 2 else "FALLIDO"
            detalle = ""
        except subprocess.TimeoutExpired as error:
            stdout, stderr, codigo = error.stdout or b"", error.stderr or b"", None
            estado = "BLOQUEADO"
            detalle = "El proceso superó el tiempo máximo del auxiliar; no se acredita una ejecución completa."
        conteo = None
        if nombre in cantidades:
            texto = (stdout + b"\n" + stderr).decode("utf-8", errors="replace")
            encontrados = re.findall(r"(?m)^Ran (\d+) tests? in [^\r\n]+", texto)
            conteo = int(encontrados[0]) if len(encontrados) == 1 else None
            if codigo == 0 and (conteo != cantidades[nombre]
                                or re.search(r"(?m)^OK\r?$", texto) is None):
                estado = "FALLIDO"
                detalle = "El proceso terminó con cero, pero no acredita el número exacto de pruebas sin omisiones."
        registro = {"id": nombre, "comando": ["python" if i == 0 else a for i, a in enumerate(comando)],
                    "inicio_utc": inicio, "fin_utc": ahora(), "codigo_salida": codigo,
                    "estado_proceso": estado, "detalle": detalle}
        if nombre in cantidades:
            registro.update(pruebas_esperadas=cantidades[nombre], pruebas_observadas=conteo)
        for flujo, datos in (("stdout", stdout), ("stderr", stderr)):
            archivo = nombre + "." + flujo + ".txt"
            (salida / archivo).write_bytes(datos)
            registro[flujo] = archivo
            registro["sha256_" + flujo] = hashlib.sha256(datos).hexdigest()
        registros.append(registro)
        print(nombre + ": " + estado + "; código " + str(codigo), flush=True)
    (salida / "comandos.json").write_bytes((json.dumps({"registros": registros},
        ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    entorno = {"fecha_utc": ahora(), "sistema": platform.system(),
               "python": platform.python_version(), "sqlite": sqlite3.sqlite_version,
               "git": git("--version"), "rama": rama, "head": git("rev-parse", "HEAD"),
               "arbol_indice_antes": arbol_antes, "arbol_indice_despues": git("write-tree"),
               "referencias_locales_conservadas": referencias_antes == git("for-each-ref",
                    "--format=%(objectname) %(refname)", "refs/heads/main", "refs/tags"),
               "alcance": "Pruebas nuevas de esta ejecución; no uso comercial ni publicación."}
    (salida / "entorno_auxiliar.json").write_bytes((json.dumps(entorno,
         ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    sys.path.insert(0, str(repo / "herramientas"))
    from huellas_evidencia import cerrar_evidencia, comprobar_huellas
    reemplazos = [(salida, "EVIDENCIA_NUEVA"), (repo, "REPOSITORIO"),
                  (Path(tempfile.gettempdir()), "TEMPORAL"), (Path.home(), "USUARIO")]

    def sanear(texto):
        for ruta, alias in reemplazos:
            for forma in (str(ruta), ruta.as_posix(), str(ruta).replace("\\", "\\\\")):
                texto = texto.replace(forma, alias)
        return texto

    cerrar_evidencia(salida, sanear)
    huellas = comprobar_huellas(salida)
    (salida / "HUELLAS_FINALES.json").write_bytes((json.dumps(huellas,
        ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    resumen = salida / "conjunto/resumen.json"
    conjunto = json.loads(resumen.read_text("utf-8")) if resumen.is_file() else {}
    aprobado = (all(r["estado_proceso"] == "APROBADO" for r in registros)
                 and conjunto.get("estado") == "APROBADO"
                 and huellas["estado"] == "APROBADO"
                 and entorno["arbol_indice_antes"] == entorno["arbol_indice_despues"]
                 and entorno["referencias_locales_conservadas"]
                 and not git("diff", "--name-only"))
    estado = "APROBADO" if aprobado else "BLOQUEADO" if any(
        r["estado_proceso"] == "BLOQUEADO" for r in registros) else "FALLIDO"
    resultado = {"estado": estado, "fecha_utc": ahora(), "huellas": huellas,
                 "estado_funcional": conjunto.get("estado", "NO EJECUTADO"),
                 "totales_funcionales": conjunto.get("totales", {}),
                 "infraestructura_separada": {r["id"]: {"estado": r["estado_proceso"],
                    "pruebas_esperadas": r["pruebas_esperadas"],
                    "pruebas_observadas": r["pruebas_observadas"]}
                     for r in registros if r["id"] != "conjunto"},
                 "limites": ["Los fallos didácticos se identifican en el resumen funcional; ningún otro fallo se acepta.",
                             "No se crearon commits o etiquetas ni se hizo push."]}
    (salida / "RESULTADO_REVISION.json").write_bytes((json.dumps(resultado,
        ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    print(estado + ": revisión local con evidencia nueva.")
    print("Huellas: {coincidentes}/{comprobadas}.".format(**huellas))
    return {"APROBADO": 0, "FALLIDO": 1, "BLOQUEADO": 2}[estado]


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, subprocess.CalledProcessError) as error:
        print("FALLIDO: no se pudo completar el auxiliar; se conserva la evidencia creada.")
        print(type(error).__name__)
        raise SystemExit(1)
