**Informe de integración del laboratorio 9 · WSL · v1.0**

**APROBADO: integración preparada para revisión.** Informe generado el 2026-11-01T22:29:11.917268+00:00. La ejecución completa se conservó en `verificacion_01/`, sin repetirla ni sustituir resultados históricos.

El paquete recibido aprobó sus 373 archivos y la cobertura completa de SHA256SUMS. El árbol inicial estaba limpio. Se consultó el remoto mediante `git fetch --no-tags origin` y mediante los registros inicial, preparado y final. Main no había avanzado; no fue necesaria una adaptación. El parche pasó `git apply --check --index` y se aplicó una sola vez con `git apply --index`.

| Identidad | Resultado observado |
| --- | --- |
| Base, HEAD y main local/remoto | `9212ee99b88f70f0b289837b88d6bbf34da91a52` |
| Árbol de base | `d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0` |
| Rama local | `codex/integracion-laboratorio-09` |
| Árbol preparado y verificado | `251105483bc5bef040c57dc3a036d5bc3a7e0da0` |
| Parche SHA-256 | `219e9b2f2353c0b55c3418d3af3277f643ce5ce151deebafcd4f425d31cc8f42` |
| Rutas preparadas | 771, exactamente las declaradas en BASE_INTEGRACION.json |
| Archivos anteriores protegidos | 1502/1502 con bytes conservados |

El incremento añade el laboratorio 9, su distribución y evidencia, amplía el verificador común e incorpora el cierre documental confirmado del laboratorio 8. Coincide exactamente con el árbol del paquete. Los archivos anteriores de laboratorios, distribuciones, historiales y evidencia protegida conservan sus bytes. El recolector y sus ocho pruebas permanecen sin cambios.

La aplicación del parche emitió advertencias sobre 30 líneas con espacios finales de materiales importados. Se conservaron esos bytes. `git diff --cached --check` terminó con código 0 utilizando los atributos suministrados; la revisión final volvió a comprobarlo. No hubo cambios sin preparar ni archivos nuevos fuera de las exclusiones de Git.

El entorno real fue Linux/WSL2, con Git 2.34.1, Node v22.23.1, npm 10.9.8, Playwright 1.62.1 y Chromium 151.0.7922.34. Las pruebas utilizaron Python 3.12.16 y SQLite 3.53.1. El Python inicial 3.10.12 se usó para observaciones y preparación; se instaló un runtime compatible aislado bajo trabajo/ para las pruebas. Chromium arrancó realmente. La instalación no generó un package-lock.json. Consulta ENTORNO_REAL.json y las operaciones 03, 05 y 14–17.

El auxiliar EJECUTAR_VERIFICACION.py comenzó en 2026-11-01T22:15:48.841016+00:00 y terminó en 2026-11-01T22:27:00.079912+00:00, con código 0. Ejecutó las pruebas de infraestructura y `python -B herramientas/verificar_todo.py --navegador --salida trabajo/integracion_09_wsl_01/verificacion_01/conjunto` usando el intérprete funcional registrado.

| Alcance funcional | Estado del recorrido | Ejecuciones | APROBADO | FALLIDO didáctico |
| --- | --- | ---: | ---: | ---: |
| Nueve laboratorios, 92 baterías | APROBADO | 805 | 781 | 24 |
| Base 9, incluida dentro del conjunto | APROBADO, patrón satisfecho | 74 | 65 | 9 |
| Propuesta 9, incluida dentro del conjunto | APROBADO, patrón satisfecho | 74 | 71 | 3 |
| Solución 9, incluida dentro del conjunto | APROBADO, patrón satisfecho | 74 | 74 | 0 |

El conjunto registró 0 bloqueos y 0 errores de ejecución. Los 48 NO EJECUTADO dentro de baterías y los 10 criterios ausentes se conservan aparte. La solución 9 aprobó 74/74, incluidos los 62 heredados. El laboratorio 4 comprobó las etiquetas y el árbol reconstruido de su referencia distribuida.

Los FALLIDO conservan su estado individual. El evaluador aprobó exactamente estas identidades y tipos de fallo, sin aceptar errores de infraestructura:

| Batería | FALLIDO didácticos observados |
| --- | --- |
| `laboratorio_01/inicial` | C04 |
| `laboratorio_03/defecto` | B05, B06 |
| `laboratorio_05/propuesta_resumen` | P04, P05 |
| `laboratorio_06/propuesta_navegador` | W05 |
| `laboratorio_07/propuesta_integracion` | I01, I07 |
| `laboratorio_08/propuesta_depuracion` | D03, D05, D08.a |
| `laboratorio_08/propuesta_depuracion_navegador` | D04 |
| `laboratorio_09/base_seguridad` | S02.a, S02.b, S02.c, S03, S04.a, S04.b, S05.a, S05.b |
| `laboratorio_09/base_seguridad_navegador` | S06 |
| `laboratorio_09/propuesta_seguridad` | S02.a, S02.b, S02.c |

Las comprobaciones de infraestructura se contabilizan por separado de las 805 ejecuciones funcionales:

| Grupo | Estado | Pruebas observadas |
| --- | --- | ---: |
| recolector | APROBADO | 8 |
| evaluador_09 | APROBADO | 9 |
| recursos_sqlite | APROBADO | 4 |

Las comprobaciones de sólo lectura posteriores al cierre aprobaron 156/156 huellas del conjunto y 164/164 de la revisión que incluye las capturas externas de infraestructura. Las 164 contienen las 156; no se suman como resultados independientes. Las operaciones de preparación añaden 46 referencias de salida: el envío contiene 210/210 huellas declaradas coincidentes, comprobadas sin fijar un recuento histórico obligatorio. Las diez distribuciones ZIP también coincidieron con su SHA256SUMS.

Se conservaron los auxiliares e instrucciones utilizados en insumos_paquete/, con sus huellas en INSUMOS_UTILIZADOS.json. Las operaciones guardan comandos, directorios, tiempos UTC, códigos de salida y stdout/stderr en operaciones/*/comandos.json. Sus rutas personales se sustituyeron por alias. Se verificaron las capturas antes del saneamiento y se conservaron sus huellas originales y las finales. Las capturas originales de las operaciones permanecen localmente en `trabajo/integracion_09_wsl_01_capturas_originales`, fuera del ZIP compartible. No se modificó verificacion_01/ durante este cierre ni se saneó evidencia histórica.

CONSERVACION_FINAL.json acredita HEAD y main conservados, las trece etiquetas locales y remotas intactas y la ausencia local/remota de lab-09-v1.0 y repositorio-v1.5. La única referencia nueva es la rama local de integración en la base original. El índice conserva el árbol preparado exacto. No se creó commit, no se integró en main, no se crearon ni movieron etiquetas y no se hizo push.

El ZIP se genera con EMPAQUETAR_EVIDENCIA.py fuera de esta carpeta y añade MANIFIESTO_ENVIO.json para todos sus archivos. Su SHA-256 y la comprobación posterior de CRC, cobertura y huellas dentro del archivo se entregan aparte, evitando incluir en el ZIP una referencia a su propio hash.

**NO EJECUTADO:** Windows nativo, CI remota, producción, una nueva interacción de Copilot o Grok Build, el reto opcional y la publicación del laboratorio 9. Esta es evidencia local nueva de la presente sesión Codex en WSL; los resultados Windows y WSL históricos mantienen su atribución. No acredita una evaluación integral de seguridad ni sustituye la revisión editorial.

**Pendiente:** revisión del autor de la integración preparada y de los capítulos 1–9. Los manuscritos permanecieron fuera del cambio. No se redactó el capítulo 10. Cualquier commit, integración en main, etiquetado o push corresponde a un encargo posterior.

Documentos de respaldo: [resultado de revisión](verificacion_01/RESULTADO_REVISION.json), [resumen funcional](verificacion_01/conjunto/resumen.json), [detalle de resultados](DETALLE_RESULTADOS.json), [conservación final](CONSERVACION_FINAL.json), [huellas del envío](HUELLAS_ENTREGA.json), [estado inicial](antes.json) y [estado final](despues.json).
