"""Conserva capturas originales y cierra sólo las operaciones nuevas."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
OPS = ROOT / 'operaciones'
BACKUP = ROOT.with_name(ROOT.name + '_capturas_originales')
sys.path.insert(0, str(REPO / 'herramientas'))
from huellas_evidencia import cerrar_evidencia, comprobar_huellas

records = []
for path in sorted(OPS.glob('*/comando.json')):
    record = json.loads(path.read_text())
    for flow in ('stdout', 'stderr'):
        observed = hashlib.sha256((path.parent / (flow + '.txt')).read_bytes()).hexdigest()
        if observed != record['sha256_capturado_' + flow]:
            raise ValueError('Divergencia previa al saneamiento: ' + str(path.parent.name))
    if (path.parent / 'comandos.json').exists():
        raise ValueError('La captura ya fue cerrada; no sobrescribir.')
    records.append((path, record))
if BACKUP.exists():
    raise ValueError('La copia original ya existe; conservar sin sobrescribir.')
shutil.copytree(OPS, BACKUP)
for original in OPS.rglob('*'):
    if original.is_file() and original.read_bytes() != (BACKUP / original.relative_to(OPS)).read_bytes():
        raise ValueError('No coincide la copia de captura original.')
for path, raw in records:
    record = dict(raw, id=path.parent.name)
    for flow in ('stdout', 'stderr'):
        record[flow] = flow + '.txt'
        record['sha256_' + flow] = raw['sha256_capturado_' + flow]
        record['sha256_' + flow + '_capturado'] = raw['sha256_capturado_' + flow]
    with (path.parent / 'comandos.json').open('x', encoding='utf-8') as f:
        json.dump({'registros': [record]}, f, ensure_ascii=False, indent=2)
        f.write('\n')

aliases = [(ROOT, 'EVIDENCIA_NUEVA'),
           (REPO.parent / 'INTEGRACION_LABORATORIO_09_v1.0', 'PAQUETE_INTEGRACION'),
           (REPO, 'REPOSITORIO'), (Path.home(), 'USUARIO')]

def sanitize(text):
    for source, replacement in aliases:
        for value in (str(source), str(source).replace('\\', '\\\\')):
            text = text.replace(value, replacement)
    return text

closed = cerrar_evidencia(OPS, sanitize)
result = {'estado': closed['estado'], 'fecha_utc': datetime.now(timezone.utc).isoformat(),
          'operaciones': len(records), 'huellas_operaciones': closed,
          'copias_originales': 'trabajo/' + BACKUP.name,
          'conservacion_copia_original': 'APROBADO',
          'alcance': 'Sólo capturas nuevas de esta sesión. Las huellas capturadas se conservan; las finales identifican los bytes saneados. No se altera verificacion_01 ni evidencia histórica.'}
with (ROOT / 'CIERRE_OPERACIONES.json').open('x', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
final = comprobar_huellas(ROOT)
with (ROOT / 'HUELLAS_ENTREGA.json').open('x', encoding='utf-8') as f:
    json.dump(final, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({'operaciones': result, 'todas_las_huellas_declaradas': final}, ensure_ascii=False, indent=2))
raise SystemExit(0 if closed['estado'] == final['estado'] == 'APROBADO' else 1)
