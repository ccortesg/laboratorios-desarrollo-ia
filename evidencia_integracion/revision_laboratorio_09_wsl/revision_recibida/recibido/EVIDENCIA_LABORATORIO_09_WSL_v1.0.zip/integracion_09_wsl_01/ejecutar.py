"""Captura comandos de esta integración en salidas nuevas, sin sobrescribirlas."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
label, cwd, *cmd = sys.argv[1:]
dest = ROOT / 'operaciones' / label
dest.mkdir(parents=True, exist_ok=False)
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (dest / 'stdout.txt').open('wb') as out, (dest / 'stderr.txt').open('wb') as err:
    result = subprocess.run(cmd, cwd=cwd, stdout=out, stderr=err)
record = {'comando': cmd, 'directorio': cwd, 'inicio_utc': start,
          'fin_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'codigo_salida': result.returncode}
for flow in ('stdout', 'stderr'):
    record['sha256_capturado_' + flow] = hashlib.sha256((dest / (flow + '.txt')).read_bytes()).hexdigest()
(dest / 'comando.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'operacion': label, 'codigo_salida': result.returncode}))
for flow in ('stdout', 'stderr'):
    data = (dest / (flow + '.txt')).read_text(encoding='utf-8', errors='replace')
    if data:
        print(flow + ':\n' + data[-5000:])
sys.exit(result.returncode)
