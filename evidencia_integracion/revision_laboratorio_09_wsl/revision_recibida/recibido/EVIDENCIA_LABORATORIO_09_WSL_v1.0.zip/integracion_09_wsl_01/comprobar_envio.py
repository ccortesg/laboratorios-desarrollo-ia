"""Verifica CRC, cobertura del envío y todas las salidas declaradas dentro del ZIP."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile

archive, output = map(Path, sys.argv[1:])
if output.exists():
    raise ValueError('El comprobante ya existe; no sobrescribir.')
with ZipFile(archive) as z:
    names = z.namelist()
    if len(names) != len(set(names)) or z.testzip() is not None:
        raise ValueError('Entradas duplicadas o CRC incorrecto.')
    manifests = [n for n in names if n.endswith('/MANIFIESTO_ENVIO.json')]
    if len(manifests) != 1:
        raise ValueError('Debe existir un manifiesto de envío.')
    manifest_name = manifests[0]
    prefix = manifest_name.rsplit('/', 1)[0] + '/'
    manifest = json.loads(z.read(manifest_name))
    entries = manifest['archivos']
    expected = {prefix + e['archivo'] for e in entries}
    if len(expected) != len(entries) or set(names) != expected | {manifest_name}:
        raise ValueError('La cobertura del manifiesto no coincide.')
    for item in entries:
        data = z.read(prefix + item['archivo'])
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise ValueError('Divergencia del manifiesto: ' + item['archivo'])
    checked = 0
    for name in names:
        if not name.endswith('/comandos.json'):
            continue
        doc = json.loads(z.read(name))
        for record in doc['registros']:
            for flow in ('stdout', 'stderr'):
                key = 'sha256_' + flow
                if key not in record:
                    continue
                target = name.rsplit('/', 1)[0] + '/' + record[flow]
                if hashlib.sha256(z.read(target)).hexdigest() != record[key]:
                    raise ValueError('Divergencia de salida declarada: ' + target)
                checked += 1
    evidence = json.loads(z.read(prefix + 'HUELLAS_ENTREGA.json'))
    if evidence['estado'] != 'APROBADO' or checked != evidence['comprobadas']:
        raise ValueError('No se acreditan todas las huellas declaradas del envío.')
result = {'estado': 'APROBADO', 'fecha_utc': datetime.now(timezone.utc).isoformat(),
          'zip': archive.name, 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'crc': 'APROBADO',
          'entradas_zip': len(names), 'archivos_manifiesto': len(entries),
          'cobertura_manifiesto': 'APROBADO', 'huellas_declaradas_en_zip': checked,
          'huellas_declaradas_coincidentes': checked,
          'alcance': 'Lectura del ZIP final; los totales de infraestructura y funcionales no se agregan.'}
with output.open('x', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
