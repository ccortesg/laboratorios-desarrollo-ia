"""Compara la observación final contra la inicial y los bytes protegidos."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
BASE = json.loads((REPO.parent / 'INTEGRACION_LABORATORIO_09_v1.0/BASE_INTEGRACION.json').read_text())
before = json.loads((ROOT / 'antes.json').read_text())
prepared = json.loads((ROOT / 'preparado.json').read_text())
after = json.loads((ROOT / 'despues.json').read_text())
protected = json.loads((ROOT / 'protegidos_antes.json').read_text())
different = [p for p, sha in protected.items()
             if not (REPO / p).is_file() or hashlib.sha256((REPO / p).read_bytes()).hexdigest() != sha]

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()

initial_refs = dict(line.split(' ', 1)[::-1] for line in
                    (ROOT / 'operaciones/02_referencias_iniciales/stdout.txt').read_text().splitlines())
final_refs = dict(line.split(' ', 1)[::-1] for line in
                  git('for-each-ref', '--format=%(objectname) %(refname)',
                      'refs/heads', 'refs/remotes', 'refs/tags').splitlines())
extra = {k: v for k, v in final_refs.items() if k not in initial_refs}
checks = {
    'head_conservado': before['head'] == prepared['head'] == after['head'],
    'main_conservado': before['main_local'] == after['main_local'],
    'trece_etiquetas_locales_conservadas': before['etiquetas_locales'] == after['etiquetas_locales'],
    'referencias_remotas_conservadas': before['referencias_remotas'] == after['referencias_remotas'],
    'referencias_preexistentes_conservadas': all(final_refs.get(k) == v for k, v in initial_refs.items()),
    'solo_nueva_rama_local': extra == {'refs/heads/codex/integracion-laboratorio-09': before['head']},
    'arbol_indice_exacto': prepared['arbol_indice'] == after['arbol_indice'] == BASE['arbol_preparado'],
    'rutas_preparadas_exactas': sorted(after['archivos_preparados']) == sorted(BASE['rutas_parche']),
    'sin_cambios_sin_preparar': not after['archivos_sin_preparar'],
    'sin_archivos_nuevos_no_ignorados': not git('ls-files', '--others', '--exclude-standard'),
    'bytes_protegidos_conservados': not different,
    'sin_etiquetas_previstas': not any('refs/tags/' + name in final_refs or
        'refs/tags/' + name in after['referencias_remotas'] for name in BASE['etiquetas_previstas']),
}
result = {'estado': 'APROBADO' if all(checks.values()) else 'FALLIDO',
          'fecha_utc': datetime.now(timezone.utc).isoformat(), 'comprobaciones': checks,
          'archivos_protegidos': len(protected), 'divergencias_protegidas': different,
          'rutas_preparadas': len(after['archivos_preparados']), 'referencias_nuevas': extra,
          'head': after['head'], 'arbol_indice': after['arbol_indice'],
          'limite': 'La creación de una rama y objetos de árbol no crea un commit ni publica referencias.'}
with (ROOT / 'CONSERVACION_FINAL.json').open('x', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if result['estado'] == 'APROBADO' else 1)
