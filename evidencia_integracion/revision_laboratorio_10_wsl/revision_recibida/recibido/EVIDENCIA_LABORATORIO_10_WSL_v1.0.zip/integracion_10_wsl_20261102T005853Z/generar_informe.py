"""Genera el informe a partir de resultados nuevos ya cerrados y auditados."""
from datetime import datetime, timezone
import json
from registrar_operacion import SESION

def leer(nombre):
    return json.loads((SESION / nombre).read_text('utf-8'))

antes = leer('antes.json')
prep = leer('preparado.json')
revision = leer('verificacion_intento_01/RESULTADO_REVISION.json')
conjunto = leer('verificacion_intento_01/conjunto/resumen.json')
audit = leer('AUDITORIA_CIERRE.json')
recuento = leer('RECUENTO_OBSERVADO_INDEPENDIENTE.json')
remoto = leer('CONSULTA_REMOTA_FINAL.json')
huellas = leer('HUELLAS_SESION.json')
capturas = leer('CAPTURAS_ORIGINALES_COTEJADAS.json')
distribucion = leer('COTEJO_DISTRIBUCION_10.json')
entorno = leer('operaciones/entorno_python_utilizado.stdout.txt')
browser = leer('operaciones/entorno_chromium.stdout.txt')
assert all(d['estado'] == 'APROBADO' for d in [revision, conjunto, audit, recuento, remoto, huellas, capturas, distribucion])
total = recuento['totales_recontados']
filas_fallos = '\n'.join('| `' + nombre + '` | ' + ', '.join(ids) + ' |'
                        for nombre, ids in recuento['fallos_observados_por_bateria'].items())
filas_10 = '\n'.join('| ' + nombre + ' | ' + str(d.get('APROBADO', 0)) + ' | '
                     + str(d.get('FALLIDO', 0)) + ' | ' + str(d.get('NO EJECUTADO', 0)) + ' |'
                     for nombre, d in recuento['laboratorio_10_por_estado'].items())
filas_infra = '\n'.join('| ' + nombre + ' | ' + str(d['pruebas_observadas']) + ' | ' + d['estado'] + ' |'
                        for nombre, d in revision['infraestructura_separada'].items())
hg = conjunto['huellas_salidas']
hr = revision['huellas']
texto = f'''# Integración del laboratorio 10 · revisión WSL v1.0

**Resultado técnico: APROBADO. Integración preparada para revisión.**

Evidencia nueva de esta sesión, cerrada a {datetime.now(timezone.utc).isoformat()} (UTC).
Los capítulos 1–10 siguen pendientes de la revisión editorial del autor.

## Cambio e identidad

Se incorporó una sola vez el parche del paquete recibido: laboratorio 10, distribución,
contrato y contexto, operador con propuesta y solución, pruebas, evidencia aportada y
continuidad documental. El operador importa una instantánea CSV y consulta la misma
SQLite mediante dos CLI; la solución exige confirmación de importación antes de consultar.
El manuscrito y Word recibidos permanecen en el paquete editorial sin cambios.

| Identidad | Valor observado |
| --- | --- |
| Rama local | `{prep['rama']}` |
| Base utilizada y HEAD conservado | `{prep['head']}` |
| Árbol de la base | `{prep['arbol_head']}` |
| Árbol preparado | `{prep['arbol_indice']}` |
| Rutas preparadas | {len(prep['archivos_preparados'])} |
| Índice y bytes de trabajo cotejados | {audit['archivos_indice']} archivos coincidentes |
| SHA-256 del parche | `{prep['sha256_parche']}` |

La base local y remota coincidía exactamente con la del paquete. `git fetch --no-tags origin`
y las consultas actuales de referencias funcionaron en esta sesión. No hubo avances que
adaptar ni divergencias que resolver. Se eligió el prefijo local `codex/`; las rutas y los bytes
del incremento no se adaptaron. El manifiesto aprobó sus 624 archivos al inicio y al cierre.
El árbol coincide con el declarado por el paquete; su manifiesto y archivo de base no se modificaron.

`git apply --check --index` y la aplicación real terminaron con código 0. La aplicación emitió
34 avisos de espacios; se conservaron sus capturas y los bytes recibidos. La revisión posterior
`git diff --cached --check` aprobó, sin reescribir espacios ni terminadores de evidencia.

## Entorno y ejecución

| Componente | Observado |
| --- | --- |
| Sistema efectivo | Linux/WSL2, `{entorno['release']}` |
| Python utilizado | {entorno['python']} ({entorno['implementacion']}) |
| SQLite | {entorno['sqlite']} |
| Git | 2.34.1 |
| Node / npm | 22.23.1 / 10.9.8 |
| Playwright | {browser['playwright']} |
| Chromium iniciado y utilizado | {browser['chromium']} |

El `python3` predeterminado era 3.10.12. Se utilizó el intérprete aislado 3.12.16 ya existente
en `trabajo/runtime_lab09_wsl/python/cpython-3.12.16-linux-x86_64-gnu/bin/python3.12` para
los auxiliares y todas las pruebas funcionales y de infraestructura. No se modificó el Python del sistema.
`LAB06_CHROMIUM`, `NODE_PATH` y las variables Playwright inspeccionadas estaban ausentes.
Se ejecutaron `npm install --ignore-scripts --package-lock=false` y la instalación declarada
de Chromium desde el laboratorio 10. No se creó un package-lock versionado.

Se ejecutó `EJECUTAR_VERIFICACION.py` con repositorio, registro preparado y salida explícitos:
`verificacion_intento_01/`. El auxiliar contrastó HEAD, índice, rama, main, etiquetas y parche
antes de probar. Su resultado fue **APROBADO, código 0**. Hubo un solo intento integral;
no se ajustaron expectativas ni se repitieron pruebas para obtener ese resultado.

Los comandos, argumentos saneados, versiones, tiempos UTC, códigos de salida y SHA-256
capturados/finales están en `operaciones/` y en los `comandos.json` del auxiliar y del conjunto.
El comando interno del conjunto incluye `--navegador`; no se volvió a ejecutar sobre su salida.

## Resultados funcionales observados

**APROBADO:** {total['laboratorios']} laboratorios, {total['baterias']} baterías y {total['ejecutados']}
ejecuciones: **{total['aprobados']} APROBADO y {total['fallidos']} FALLIDO didácticos**.
Bloqueos: {total['bloqueados']}. Errores de ejecución: {recuento['errores_de_ejecucion']}.
Los {total['no_ejecutados_en_baterias']} NO EJECUTADO en baterías y los
{total['no_ejecutados_fuera_de_baterias']} criterios ausentes de inicio 4 se registran aparte.
Un recuento independiente de los estados observados coincide con todos los totales y el patrón.

| Laboratorio 10 / estado | APROBADO | FALLIDO | NO EJECUTADO |
| --- | ---: | ---: | ---: |
{filas_10}

Los 74 heredados aprobaron en los tres estados. En base faltan únicamente los ocho T por
alcance. Propuesta falló exclusivamente T02 por AssertionError; T08 aprobó. Solución aprobó
82/82, incluido el recorrido real CSV → operador → CLI → SQLite → HTTP → Chromium.
También se comprobaron las referencias y el árbol actual reconstruido del laboratorio 4.

Los siguientes identificadores conservaron **FALLIDO**, por aserción, en sus estados didácticos:

| Batería | Identificadores FALLIDO observados |
| --- | --- |
{filas_fallos}

No hubo fallos adicionales. Los resultados de los laboratorios anteriores fueron ejecutados
de nuevo por este conjunto; no son sustituciones por los informes históricos suministrados.

## Infraestructura e integridad, separadas de los casos funcionales

| Grupo | Métodos observados | Resultado |
| --- | ---: | --- |
{filas_infra}

RO01 es un método con dos estados como subcasos. Inyecta OSError y comprueba un bloqueo
simulado al iniciar un hijo; no describe una incidencia real ni se suma a T01–T08.

| Comprobación de huellas | Resultado |
| --- | --- |
| Conjunto funcional, todas las declaradas | {hg['estado']}: {hg['coincidentes']}/{hg['comprobadas']} |
| Revisión del auxiliar, todas las declaradas | {hr['estado']}: {hr['coincidentes']}/{hr['comprobadas']} |
| Sesión completa, incluidos los comandos propios agregados | {huellas['estado']}: {huellas['coincidentes']}/{huellas['comprobadas']} |
| Bytes originales de las capturas de la revisión | {capturas['estado']}: {capturas['declaraciones_comprobadas']} declaraciones cotejadas |

Se invocó el recolector vigente sobre la revisión y el conjunto sin fijar `--esperadas`.
Las cantidades anteriores son observadas, no constantes históricas. Las ocho pruebas del
recolector y su código se conservaron exactos. También se cotejó la distribución autónoma:
CRC correcto y sus {distribucion['archivos']} archivos idénticos a la copia integrada.
Ese cotejo de bytes no representa una segunda ejecución funcional autónoma.

Para conservar los bytes antes del saneamiento se utilizó un observador documentado en
`soporte_de_sesion/sitecustomize.py`: copia las salidas declaradas antes de llamar al cierre
original, con los mismos argumentos y resultado. No se modificó ninguna fuente versionada.
El alcance y el cotejo de cada captura están documentados; los fixtures de infraestructura
no se contabilizan como criterios funcionales adicionales.

Los originales con rutas locales permanecen fuera del envío compartible, en
`trabajo/{SESION.name}_capturas_originales/`. El ZIP conserva las salidas saneadas, sus huellas
capturadas y finales y el inventario que demuestra la correspondencia de los bytes originales.
No se normalizaron LF/CRLF para hacer coincidir huellas ni se repararon evidencias históricas.

## Conservación y consultas finales

`main` y HEAD permanecen en `{audit['head']}`. Las quince etiquetas históricas y todas las
referencias locales preexistentes conservan sus identidades. No existen las etiquetas previstas
`lab-10-v1.0` y `repositorio-v1.6`. No se crearon commits, no se integró en main, no se crearon
ni movieron etiquetas y no se hizo push.

La reconsulta remota final terminó a {remoto['fin_consulta_utc']}: main sigue en
`{remoto['main_final']}`; no hubo avances y las etiquetas remotas se conservan.
El índice final conserva el árbol preparado y no hay cambios sin preparar ni archivos ajenos
sin seguimiento. Se cotejaron {audit['originales_protegidos']} archivos versionados originales
protegidos y {audit['archivos_evidencia_anterior']} archivos de evidencia anterior en trabajo:
todos conservan sus bytes. Los modos de los originales versionados también se conservaron.
Los nueve archivos existentes modificados por el parche se distinguen explícitamente de los
protegidos. El inventario de contenido comenzó antes de aplicar; sus metadatos Git se leyeron
al terminar. `antes.json` acredita el estado inicial limpio y el cotejo con HEAD confirma los
bytes anteriores de esos nueve archivos. No se sustituye esa precisión temporal por una
afirmación de captura atómica.

## Límites y entrega

Windows nativo: **NO EJECUTADO**. Esta ejecución es WSL2 y no se atribuye a Windows.
CI remota, producción, nuevas sesiones Copilot/Grok Build y publicación: **NO EJECUTADO**.
No hay bloqueos técnicos pendientes dentro del alcance comprobado. No se acredita una
revisión editorial ni se redactó contenido adicional del libro.

Los escenarios son locales, sintéticos y secuenciales. No amplían el contrato a concurrencia,
fallos físicos o recuperación destructiva. RO01 no sustituye una prueba de agotamiento del
timeout. Una consulta fallida no revierte una importación ya confirmada.

La evidencia nueva se entrega aparte de los estados y evidencias históricos del parche.
El ZIP se crea con EMPAQUETAR_EVIDENCIA.py; su SHA-256 y la comprobación independiente del
CRC y manifiesto se entregan fuera del ZIP para evitar autorreferencias. El punto de cierre
es la rama local preparada para revisión. Los capítulos 1–10 permanecen pendientes del autor.
'''
with (SESION / 'INFORME_INTEGRACION_LABORATORIO_10_WSL_v1.0.md').open('x', encoding='utf-8') as f:
    f.write(texto)
print('Informe generado a partir de resultados observados y auditorias aprobadas.')
