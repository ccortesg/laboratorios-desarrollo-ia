"""Captura una operacion real y conserva sus bytes originales fuera del envio."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

SESION = Path(__file__).resolve().parent
REPO = SESION.parent.parent
PAQUETE = REPO.parent / 'INTEGRACION_LABORATORIO_10_v1.0'
ORIGINALES = SESION.with_name(SESION.name + '_capturas_originales')

def ahora():
    return datetime.now(timezone.utc).isoformat()

def sanear(texto):
    for ruta, alias in [(ORIGINALES, 'CAPTURAS_ORIGINALES'), (SESION, 'EVIDENCIA_NUEVA'),
                        (PAQUETE, 'PAQUETE'), (REPO, 'REPOSITORIO'),
                        (Path.home(), 'USUARIO')]:
        texto = texto.replace(str(ruta), alias)
    return texto

def ejecutar(nombre, comando, cwd=None, timeout=180, env=None):
    carpeta = SESION / 'operaciones'
    crudos = ORIGINALES / 'operaciones'
    carpeta.mkdir(parents=True, exist_ok=True)
    crudos.mkdir(parents=True, exist_ok=True)
    if (carpeta / (nombre + '.json')).exists():
        raise ValueError('La operacion ya fue capturada; utiliza otro nombre.')
    registro = {'id': nombre, 'argv': comando, 'cwd': str(cwd or REPO),
                'inicio_utc': ahora(), 'entorno_explicito': env or {}}
    entorno = os.environ.copy()
    entorno.update(PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1', GIT_TERMINAL_PROMPT='0')
    entorno.update(env or {})
    try:
        p = subprocess.run(comando, cwd=cwd or REPO, env=entorno,
                           capture_output=True, timeout=timeout)
        stdout, stderr, codigo = p.stdout, p.stderr, p.returncode
    except subprocess.TimeoutExpired as error:
        stdout, stderr, codigo = error.stdout or b'', error.stderr or b'', None
        registro['limite'] = 'Tiempo de operacion agotado; no se acredita terminacion.'
    registro.update(fin_utc=ahora(), codigo_salida=codigo)
    for flujo, datos in [('stdout', stdout), ('stderr', stderr)]:
        archivo = nombre + '.' + flujo + '.txt'
        (crudos / archivo).write_bytes(datos)
        finales = sanear(datos.decode('utf-8', errors='replace')).encode('utf-8')
        (carpeta / archivo).write_bytes(finales)
        registro[flujo] = archivo
        registro['sha256_' + flujo + '_capturado'] = hashlib.sha256(datos).hexdigest()
        registro['sha256_' + flujo] = hashlib.sha256(finales).hexdigest()
    texto = json.dumps(registro, ensure_ascii=False, indent=2) + '\n'
    (crudos / (nombre + '.json')).write_text(texto, encoding='utf-8')
    (carpeta / (nombre + '.json')).write_text(sanear(texto), encoding='utf-8')
    print(nombre + ': codigo ' + str(codigo), flush=True)
    for flujo in ['stdout', 'stderr']:
        contenido = (carpeta / registro[flujo]).read_text('utf-8')
        if contenido:
            print(contenido[:8000], end='' if contenido.endswith('\n') else '\n', flush=True)
    return codigo

if __name__ == '__main__':
    raise SystemExit(ejecutar(sys.argv[1], sys.argv[2:]))
