"""Recuenta estados observados sin fijar cifras historicas como constantes."""
from collections import Counter
import json
from registrar_operacion import SESION

datos = json.loads((SESION / 'verificacion_intento_01/conjunto/resumen.json').read_text())
conteo = Counter()
fallos = {}
estados_10 = {n: Counter() for n in ('base', 'propuesta', 'solucion')}
for bateria in datos['baterias']:
    observados = bateria['criterios_observados']
    conteo.update(observados.values())
    ids = sorted(k for k, v in observados.items() if v == 'FALLIDO')
    if ids:
        fallos[bateria['bateria']] = ids
    for estado, acumulado in estados_10.items():
        if bateria['bateria'].startswith('laboratorio_10/' + estado + '_'):
            acumulado.update(observados.values())
totales = {
    'laboratorios': len(datos['laboratorios']), 'baterias': len(datos['baterias']),
    'ejecutados': conteo['APROBADO'] + conteo['FALLIDO'], 'aprobados': conteo['APROBADO'],
    'fallidos': conteo['FALLIDO'], 'bloqueados': conteo['BLOQUEADO'],
    'no_ejecutados_en_baterias': conteo['NO EJECUTADO'],
    'no_ejecutados_fuera_de_baterias': sum(len(l.get('criterios_ausentes_en_inicio', [])) for l in datos['laboratorios']),
}
correcto = (totales == datos['totales'] and fallos == datos['fallos_intencionales']
            and all(b['evaluacion_del_recorrido'] == 'APROBADO' for b in datos['baterias'])
            and sum(b['errores_de_ejecucion'] for b in datos['baterias']) == 0)
salida = {'estado': 'APROBADO' if correcto else 'FALLIDO', 'totales_recontados': totales,
          'fallos_observados_por_bateria': fallos,
          'errores_de_ejecucion': sum(b['errores_de_ejecucion'] for b in datos['baterias']),
          'laboratorio_10_por_estado': {k: dict(v) for k, v in estados_10.items()},
          'alcance': 'Recuento de los estados efectivamente observados; no es otra ejecucion funcional.'}
with (SESION / 'RECUENTO_OBSERVADO_INDEPENDIENTE.json').open('x', encoding='utf-8') as f:
    json.dump(salida, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps(salida, ensure_ascii=False, indent=2))
raise SystemExit(0 if correcto else 1)
