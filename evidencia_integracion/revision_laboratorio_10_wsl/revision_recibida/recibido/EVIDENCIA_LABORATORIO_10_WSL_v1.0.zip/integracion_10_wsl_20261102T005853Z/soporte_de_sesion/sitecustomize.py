"""Copia de lectura de las capturas antes del saneamiento, sin cambiar fuentes.

Se activa solo al ejecutar el auxiliar con LAB10_ARCHIVO_CAPTURAS. Conserva los
bytes declarados en comandos.json antes de llamar al cierre original intacto.
Los blobs originales quedan fuera del ZIP saneado.
"""
import hashlib
import importlib.abc
import importlib.machinery
import json
import os
from pathlib import Path
import sys
import uuid

ARCHIVO = os.environ.get('LAB10_ARCHIVO_CAPTURAS')

def conservar(salida):
    raiz = Path(salida)
    if not raiz.is_dir() or raiz.is_symlink():
        return
    almacen = Path(ARCHIVO)
    blobs = almacen / 'blobs'
    registros = almacen / 'cierres'
    blobs.mkdir(parents=True, exist_ok=True)
    registros.mkdir(parents=True, exist_ok=True)
    entradas = []
    for archivo in sorted(raiz.rglob('comandos.json')):
        try:
            datos = archivo.read_bytes()
            comandos = json.loads(datos.decode('utf-8')).get('registros', [])
            objetos = [(archivo, datos)]
            for comando in comandos:
                for flujo in ('stdout', 'stderr'):
                    nombre = comando.get(flujo)
                    if isinstance(nombre, str) and nombre not in ('.', '..') and not any(c in nombre for c in '/\\:'):
                        destino = archivo.parent / nombre
                        if destino.is_file() and not destino.is_symlink():
                            objetos.append((destino, destino.read_bytes()))
            for destino, contenido in objetos:
                sha = hashlib.sha256(contenido).hexdigest()
                blob = blobs / sha
                try:
                    with blob.open('xb') as f:
                        f.write(contenido)
                except FileExistsError:
                    pass
                entradas.append({'archivo': destino.relative_to(raiz).as_posix(),
                                 'sha256': sha, 'bytes': len(contenido)})
        except (OSError, ValueError, TypeError, AttributeError):
            # Los casos de infraestructura incluyen estructuras inválidas.
            # La función original conserva su propia validación y resultado.
            continue
    if entradas:
        (registros / (uuid.uuid4().hex + '.json')).write_text(
            json.dumps({'salida_original': str(raiz), 'entradas': entradas},
                       ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

class Cargador(importlib.abc.Loader):
    def __init__(self, original):
        self.original = original

    def create_module(self, spec):
        return self.original.create_module(spec)

    def exec_module(self, modulo):
        self.original.exec_module(modulo)
        original = getattr(modulo, 'cerrar_evidencia', None)
        if original is not None:
            def cerrar_con_copia(salida, transformar):
                conservar(salida)
                return original(salida, transformar)
            modulo.cerrar_evidencia = cerrar_con_copia

class Observador(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.rsplit('.', 1)[-1] != 'huellas_evidencia':
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        if spec is not None and spec.loader is not None:
            spec.loader = Cargador(spec.loader)
        return spec

if ARCHIVO:
    sys.meta_path.insert(0, Observador())
