"""Cotejo final de solo lectura del arbol, originales y capturas de esta sesion."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
from registrar_operacion import REPO, SESION, ORIGINALES

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def guardar(nombre, datos):
    with (SESION / nombre).open('x', encoding='utf-8') as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
        f.write('\n')

def main():
    inicio = datetime.now(timezone.utc).isoformat()
    antes = json.loads((SESION / 'antes.json').read_text())
    preparado = json.loads((SESION / 'preparado.json').read_text())
    inventario = json.loads((SESION / 'CONSERVACION_ANTES.json').read_text())
    alcance = json.loads((SESION / 'ALCANCE_CONSERVACION.json').read_text())
    revision = SESION / 'verificacion_intento_01'
    salida = json.loads((revision / 'RESULTADO_REVISION.json').read_text())
    index = []
    for fila in git('ls-files', '--stage', '-z').decode().split('\0'):
        if not fila:
            continue
        meta, nombre = fila.split('\t', 1)
        modo, oid, etapa = meta.split()
        p = REPO / nombre
        contenido = p.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(contenido)).encode() + b'\0' + contenido).hexdigest()
        index.append({'archivo': nombre, 'oid_indice': oid, 'oid_bytes': blob,
                      'sha256': hashlib.sha256(contenido).hexdigest(),
                      'etapa': etapa, 'modo_indice': modo,
                      'coincide': oid == blob and etapa == '0'})
    guardar('IDENTIDAD_BYTES_INDICE.json', {'estado': 'APROBADO' if all(e['coincide'] for e in index) else 'FALLIDO',
                                           'archivos': len(index), 'entradas': index})
    excluidos = set(alcance['existentes_modificados_por_parche'])
    protegidos = []
    for nombre, dato in inventario['versionados'].items():
        if nombre in excluidos:
            continue
        p = REPO / nombre
        coincide = p.is_file() and sha256(p) == dato['sha256']
        modo = p.is_file() and oct(p.stat().st_mode & 0o777) == dato['modo_fs']
        protegidos.append({'archivo': nombre, 'sha256': dato['sha256'], 'bytes_conservados': coincide,
                           'modo_fs_conservado': modo})
    previos = [{'archivo': n, 'sha256': h,
                'conservado': (REPO / n).is_file() and sha256(REPO / n) == h}
               for n, h in inventario['trabajo_preexistente'].items()]
    guardar('CONSERVACION_ARCHIVOS_POST.json', {
        'estado': 'APROBADO' if all(e['bytes_conservados'] and e['modo_fs_conservado'] for e in protegidos)
                  and all(e['conservado'] for e in previos) else 'FALLIDO',
        'protegidos_versionados': protegidos, 'evidencia_trabajo_anterior': previos})
    blobs = ORIGINALES / 'snapshots/blobs'
    blob_hashes = {p.name for p in blobs.iterdir() if p.is_file() and sha256(p) == p.name}
    capturas = []
    for p in sorted(revision.rglob('comandos.json')):
        for r in json.loads(p.read_text())['registros']:
            for flujo in ('stdout', 'stderr'):
                h = r.get('sha256_' + flujo + '_capturado')
                if h:
                    capturas.append({'registro': p.relative_to(SESION).as_posix(), 'id': r.get('id'),
                                     'flujo': flujo, 'sha256_capturado': h,
                                     'bytes_originales_conservados': h in blob_hashes})
    guardar('CAPTURAS_ORIGINALES_COTEJADAS.json', {
        'estado': 'APROBADO' if capturas and all(e['bytes_originales_conservados'] for e in capturas) else 'FALLIDO',
        'declaraciones_comprobadas': len(capturas), 'blobs_distintos_verificados': len(blob_hashes),
        'almacen_local_fuera_del_zip': 'trabajo/' + ORIGINALES.name + '/snapshots/blobs',
        'registros': capturas})
    operaciones = []
    for p in sorted((SESION / 'operaciones').glob('*.json')):
        r = json.loads(p.read_text())
        if 'stdout' not in r:
            continue
        for flujo in ('stdout', 'stderr'):
            nombre = r[flujo]
            operaciones.append({'id': r['id'], 'flujo': flujo,
                'final_coincide': sha256(p.parent / nombre) == r['sha256_' + flujo],
                'capturado_coincide': sha256(ORIGINALES / 'operaciones' / nombre) == r['sha256_' + flujo + '_capturado']})
    guardar('AUDITORIA_OPERACIONES_POST.json', {
        'estado': 'APROBADO' if all(e['final_coincide'] and e['capturado_coincide'] for e in operaciones) else 'FALLIDO',
        'nota': 'La operacion que ejecuta esta auditoria se captura al terminar y se valida en el envio.',
        'registros': operaciones})
    head, main_local, arbol_head = git('rev-parse', 'HEAD', 'main', 'HEAD^{tree}').decode().splitlines()
    rama = git('branch', '--show-current').decode().strip()
    arbol_indice = git('write-tree').decode().strip()
    refs = git('for-each-ref', '--format=%(refname) %(objectname)').decode()
    etiquetas = dict(l.split(' ', 1) for l in refs.splitlines() if l.startswith('refs/tags/'))
    sin_preparar = git('diff', '--name-only').decode().splitlines()
    no_seguidos = git('ls-files', '--others', '--exclude-standard').decode().splitlines()
    formato = subprocess.run(['git', 'diff', '--cached', '--check'], cwd=REPO, capture_output=True)
    checks = {
        'head_conservado': head == antes['head'] == preparado['head'],
        'main_conservado': main_local == antes['main_local'] == preparado['main_local'],
        'rama_preparada_conservada': rama == preparado['rama'] and rama != 'main',
        'arbol_indice_exacto': arbol_indice == preparado['arbol_indice'] == preparado['arbol_esperado_paquete'],
        'etiquetas_conservadas': etiquetas == antes['etiquetas_locales'] == preparado['etiquetas_locales'],
        'todas_las_referencias_preexistentes_conservadas': refs == inventario['refs'],
        'sin_cambios_fuera_indice': not sin_preparar and not no_seguidos,
        'formato_indice': formato.returncode == 0,
        'bytes_indice': all(e['coincide'] for e in index),
        'originales_versionados': all(e['bytes_conservados'] and e['modo_fs_conservado'] for e in protegidos),
        'evidencia_anterior': all(e['conservado'] for e in previos),
        'bytes_capturados': bool(capturas) and all(e['bytes_originales_conservados'] for e in capturas),
        'operaciones': all(e['final_coincide'] and e['capturado_coincide'] for e in operaciones),
        'revision_integral': salida['estado'] == 'APROBADO',
    }
    resultado = {'inicio_utc': inicio, 'fin_utc': datetime.now(timezone.utc).isoformat(),
                 'estado': 'APROBADO' if all(checks.values()) else 'FALLIDO',
                 'comprobaciones': checks, 'head': head, 'arbol_head': arbol_head,
                 'main_local': main_local, 'rama': rama, 'arbol_indice': arbol_indice,
                 'archivos_indice': len(index), 'originales_protegidos': len(protegidos),
                 'archivos_evidencia_anterior': len(previos), 'etiquetas': etiquetas,
                 'archivos_sin_preparar': sin_preparar, 'sin_seguimiento': no_seguidos}
    guardar('AUDITORIA_CIERRE.json', resultado)
    print(json.dumps({k:v for k,v in resultado.items() if k != 'etiquetas'}, ensure_ascii=False, indent=2))
    return 0 if resultado['estado'] == 'APROBADO' else 1

if __name__ == '__main__':
    raise SystemExit(main())
