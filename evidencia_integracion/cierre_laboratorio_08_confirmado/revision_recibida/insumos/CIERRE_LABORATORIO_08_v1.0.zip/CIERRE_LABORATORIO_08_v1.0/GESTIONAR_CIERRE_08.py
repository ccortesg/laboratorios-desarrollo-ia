"""Prepara documentación y registra el cierre; no hace commit, merge, tags ni push."""

import argparse
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import subprocess
import sys
from urllib.parse import urlsplit
from zipfile import ZipFile, ZIP_DEFLATED


class ErrorCierre(ValueError):
    """Precondición que preserva el trabajo actual."""


def exigir(condicion, mensaje):
    if not condicion:
        raise ErrorCierre(mensaje)


def ahora():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha(datos):
    return hashlib.sha256(datos).hexdigest()


def leer_json(archivo):
    return json.loads(archivo.read_bytes())


def relativo(nombre):
    exigir(isinstance(nombre, str) and nombre and not any(c in nombre for c in "\\:\n\r\t"),
           "Nombre de archivo no admitido en el paquete.")
    p = PurePosixPath(nombre)
    exigir(not p.is_absolute() and not any(c in {"", ".", ".."} for c in nombre.split("/")),
           "Referencia fuera del alcance del paquete.")
    return Path(*p.parts)


def guardar_nuevo(archivo, datos):
    with archivo.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
        f.write("\n")


def verificar_paquete(paquete):
    declarados = {}
    for linea in (paquete / "SHA256SUMS").read_text("utf-8").splitlines():
        digest, nombre = linea.split("  ", 1)
        relativo(nombre)
        exigir(re.fullmatch(r"[0-9a-f]{64}", digest) and nombre not in declarados
               and nombre != "SHA256SUMS", "Manifiesto de paquete inválido.")
        declarados[nombre] = digest
    entradas = list(paquete.rglob("*"))
    exigir(not any(p.is_symlink() for p in entradas), "El paquete no admite enlaces.")
    archivos = {p.relative_to(paquete).as_posix(): p for p in entradas
                if p.is_file() and p != paquete / "SHA256SUMS"}
    exigir(set(archivos) == set(declarados) and bool(archivos), "Inventario del paquete incompleto.")
    exigir(all(sha(p.read_bytes()) == declarados[n] for n, p in archivos.items()),
           "El paquete no coincide con sus huellas; conserva sus archivos.")
    return {"estado": "APROBADO", "archivos": len(archivos), "sha256_manifiesto": sha((paquete / "SHA256SUMS").read_bytes())}


def url_autorizada(valor, repositorio):
    if valor.startswith("git@github.com:"):
        return valor[len("git@github.com:"):].rstrip("/").removesuffix(".git") == repositorio
    try:
        u = urlsplit(valor)
        valido = (u.hostname == "github.com" and not u.query and not u.fragment
                  and u.path.rstrip("/").removesuffix(".git") == "/" + repositorio)
        return valido and ((u.scheme == "https" and u.username is None and u.password is None
                            and u.port in {None, 443})
                           or (u.scheme == "ssh" and u.username == "git" and u.password is None
                               and u.port in {None, 22}))
    except ValueError:
        return False


class Cierre:
    def __init__(self, repo, paquete, salida):
        self.repo, self.paquete = Path(repo).resolve(), Path(paquete).resolve()
        self.paquete_verificado = verificar_paquete(self.paquete)
        self.config = leer_json(self.paquete / "BASE_CIERRE.json")
        self.config_sha = sha((self.paquete / "BASE_CIERRE.json").read_bytes())
        solicitada = self.repo / salida
        for padre in (solicitada, *solicitada.parents):
            if padre == self.repo:
                break
            exigir(not padre.is_symlink(), "La salida no admite enlaces fuera del directorio de trabajo.")
        self.salida = solicitada.resolve()
        exigir((self.repo / "trabajo") in self.salida.parents,
               "La salida debe ser una carpeta dentro de trabajo/.")
        self.eventos = []
        for key in ("base_commit", "arbol_verificado", "arbol_documental"):
            exigir(re.fullmatch(r"[0-9a-f]{40}", self.config.get(key, "")), "Falta una identidad Git válida en el paquete.")
        exigir(self.config.get("repositorio") == "ccortesg/laboratorios-desarrollo-ia",
               "El paquete no identifica el repositorio sintético autorizado.")
        exigir(self.config.get("etiquetas_previstas") == ["lab-08-v1.0", "repositorio-v1.4"],
               "Las etiquetas previstas no coinciden con el encargo.")
        archivo = self.paquete / relativo(self.config["archivo_protegidos"])
        exigir(sha(archivo.read_bytes()) == self.config["sha256_archivo_protegidos"],
               "El mapa de conservación no coincide con su huella.")
        self.protegidos = leer_json(archivo)
        self.documentales = self.config["archivos_documentales"]
        for mapa in (self.protegidos, self.documentales):
            exigir(isinstance(mapa, dict) and mapa, "Falta un mapa de archivos obligatorio.")
            for nombre, digest in mapa.items():
                relativo(nombre)
                exigir(re.fullmatch(r"[0-9a-f]{64}", digest), "Huella de archivo inválida.")
        exigir(not set(self.protegidos) & set(self.documentales), "Los mapas del paquete se superponen.")
        self.tags_nuevas = {"refs/tags/" + n for n in self.config["etiquetas_previstas"]}

    def git(self, *args, datos=None, admisibles=(0,)):
        entorno = dict(os.environ, GIT_TERMINAL_PROMPT="0")
        try:
            p = subprocess.run(["git", *args], cwd=self.repo, env=entorno, input=datos,
                               capture_output=True, timeout=120)
        except (OSError, subprocess.TimeoutExpired):
            raise ErrorCierre("No se pudo completar una comprobación Git; conserva el estado actual.") from None
        self.eventos.append({"comando": ["git", *args], "codigo_salida": p.returncode})
        exigir(p.returncode in admisibles, "No se completó git " + args[0] + "; conserva los cambios y revisa la conexión o el estado local.")
        return p

    def texto(self, *args):
        return self.git(*args).stdout.decode("utf-8").strip()

    def identidad(self):
        tags = {}
        for linea in self.texto("for-each-ref", "--format=%(objectname)%09%(refname)", "refs/tags").splitlines():
            digest, nombre = linea.split("\t", 1)
            tags[nombre] = digest
        return {"rama": self.texto("branch", "--show-current"),
                "head": self.texto("rev-parse", "HEAD"),
                "main": self.texto("rev-parse", "main"),
                "arbol_indice": self.texto("write-tree"),
                "sin_preparar": self.texto("diff", "--name-only"),
                "no_seguidos": self.texto("ls-files", "--others", "--exclude-standard"),
                "etiquetas": tags}

    def autorizar_origin(self):
        for args in (("remote", "get-url", "--all", "origin"),
                     ("remote", "get-url", "--push", "--all", "origin")):
            urls = self.texto(*args).splitlines()
            exigir(len(urls) == 1 and url_autorizada(urls[0], self.config["repositorio"]),
                   "Origin debe tener una sola URL de lectura y de publicación del repositorio autorizado; no se modificó su configuración.")

    def consultar_remoto(self):
        self.autorizar_origin()
        refs = {}
        for linea in self.texto("ls-remote", "--refs", "origin", "refs/heads/main", "refs/tags/*").splitlines():
            digest, nombre = linea.split("\t", 1)
            exigir(re.fullmatch(r"[0-9a-f]{40}", digest) and nombre not in refs, "Respuesta remota inválida.")
            refs[nombre] = digest
        exigir("refs/heads/main" in refs, "Main no se encontró en la consulta remota.")
        return {"fecha_hora_utc": ahora(), "referencias": refs,
                "metodo": "git ls-remote --refs origin refs/heads/main refs/tags/*"}

    def conservar_tags(self, locales, remoto, anteriores=None):
        esperadas = dict(self.config["etiquetas_historicas"])
        for ref, digest in esperadas.items():
            exigir(locales.get(ref) == digest and remoto.get(ref) == digest,
                   "Una etiqueta histórica difiere; conserva todas las referencias para revisión.")
        if anteriores:
            for ref, digest in anteriores["identidad"]["etiquetas"].items():
                if ref not in self.tags_nuevas:
                    exigir(locales.get(ref) == digest, "Cambió una etiqueta local registrada al preparar el cierre.")
            for ref, digest in anteriores["remoto"]["referencias"].items():
                if ref.startswith("refs/tags/") and ref not in self.tags_nuevas:
                    exigir(remoto.get(ref) == digest, "Cambió una etiqueta remota registrada al preparar el cierre.")

    def blobs(self, arbol, nombres):
        solicitudes = b"".join((arbol + ":" + n + "\n").encode("utf-8") for n in nombres)
        contenido = self.git("cat-file", "--batch", datos=solicitudes).stdout
        observado, posicion = {}, 0
        for nombre in nombres:
            fin = contenido.find(b"\n", posicion)
            exigir(fin >= posicion, "Respuesta de objetos Git incompleta.")
            cabecera = contenido[posicion:fin].split()
            exigir(len(cabecera) == 3 and cabecera[1] == b"blob", "Falta un archivo documentado en el árbol preparado.")
            cantidad = int(cabecera[2]); inicio = fin + 1
            datos = contenido[inicio:inicio + cantidad]
            exigir(len(datos) == cantidad and contenido[inicio + cantidad:inicio + cantidad + 1] == b"\n", "Objeto Git incompleto.")
            observado[nombre] = sha(datos)
            posicion = inicio + cantidad + 1
        exigir(posicion == len(contenido), "La respuesta de objetos Git contiene registros adicionales.")
        return observado

    def mapas_modos(self, arbol):
        resultado = {}
        for registro in self.git("ls-tree", "-r", "-z", arbol).stdout.split(b"\0"):
            if registro:
                cabecera, nombre = registro.split(b"\t", 1)
                modo, tipo, _ = cabecera.decode("ascii").split()
                exigir(tipo == "blob", "El árbol contiene un tipo de objeto ajeno a los archivos del paquete.")
                resultado[nombre.decode("utf-8")] = modo
        return resultado

    def cotejar(self, arbol, incluir_documentos):
        mapa = dict(self.protegidos)
        if incluir_documentos:
            mapa.update(self.documentales)
        exigir(self.blobs(arbol, list(mapa)) == mapa,
               "Un archivo protegido o documental difiere del paquete. Conserva el avance y revisa las diferencias antes de publicar.")
        for nombre, esperado in mapa.items():
            p = self.repo / relativo(nombre)
            exigir(p.is_file() and not p.is_symlink() and sha(p.read_bytes()) == esperado,
                   "El archivo de trabajo no coincide con los bytes revisados; conserva el estado para revisión.")
        if incluir_documentos:
            trozos = self.git("diff", "--name-status", "--no-renames", "-z",
                              self.config["arbol_verificado"], arbol, "--").stdout.split(b"\0")
            pares = list(zip(trozos[:-1:2], trozos[1:-1:2]))
            exigir(len(trozos) == len(pares) * 2 + 1, "Diferencias Git incompletas.")
            exigir(all(s in {b"A", b"M"} and n.decode("utf-8") in self.documentales for s, n in pares),
                   "El avance incluye cambios fuera del incremento documental. Se requiere revisar y, si cambia código, verificar ese alcance.")
            antes, despues = self.mapas_modos(self.config["arbol_verificado"]), self.mapas_modos(arbol)
            exigir(all(despues.get(n) == modo for n, modo in antes.items())
                   and all(modo == "100644" for n, modo in despues.items() if n not in antes),
                   "Hay cambios de modos o archivos especiales fuera del cierre documental.")
        return {"estado": "APROBADO", "archivos_protegidos": len(self.protegidos),
                "archivos_documentales": len(self.documentales) if incluir_documentos else 0,
                "metodo": "SHA-256 de blobs Git y bytes del árbol de trabajo; conservación de modos y alcance del diff."}

    def limpio(self, identidad, comprometido=False):
        exigir(not identidad["sin_preparar"] and not identidad["no_seguidos"],
               "Hay cambios sin preparar o archivos no seguidos; consérvalos para revisión.")
        self.git("diff", "--cached", "--check")
        if comprometido:
            exigir(identidad["head"] == identidad["main"] and identidad["rama"] == "main"
                   and identidad["arbol_indice"] == self.texto("rev-parse", "HEAD^{tree}"),
                   "El cierre debe estar confirmado en main y el índice debe coincidir con HEAD.")

    def cargar_preparacion(self):
        exigir(self.salida.is_dir() and not self.salida.is_symlink(), "Falta la carpeta de preparación del cierre.")
        antes = leer_json(self.salida / "antes.json")
        preparado = leer_json(self.salida / "preparado.json")
        exigir(antes["sha256_base_cierre"] == self.config_sha and preparado["estado"] == "APROBADO"
               and preparado["sha256_antes"] == sha((self.salida / "antes.json").read_bytes()),
               "La preparación no corresponde al paquete actual o no terminó correctamente.")
        return antes, preparado

    def exigir_antecesor(self, anterior, posterior, origen):
        exigir(isinstance(anterior, str) and re.fullmatch(r"[0-9a-f]{40}", anterior),
               "La identidad histórica de main no es válida.")
        exigir(self.git("cat-file", "-e", anterior + "^{commit}", admisibles=(0, 1, 128)).returncode == 0,
               "Falta el objeto de " + origen + ": obtén los objetos con fetch sin etiquetas y conserva el registro para revisión.")
        exigir(self.git("merge-base", "--is-ancestor", anterior, posterior, admisibles=(0, 1)).returncode == 0,
               "El commit no conserva " + origen + " como antecesor; conserva todas las ramas para adaptar la integración.")

    def preparar(self):
        exigir(not self.salida.exists(), "La salida ya existe; conserva ese intento y elige una carpeta nueva.")
        inicial = self.identidad(); self.limpio(inicial)
        exigir(inicial["rama"] not in {"", "main", "master"} and inicial["head"] == self.config["base_commit"],
               "La rama o HEAD difieren del punto de preparación; conserva sus cambios para adaptar el cierre.")
        exigir(inicial["arbol_indice"] in {self.config["arbol_verificado"], self.config["arbol_documental"]},
               "El índice no coincide con el árbol Windows verificado ni con el documental; revisar sin restablecerlo.")
        remoto = self.consultar_remoto()
        self.conservar_tags(inicial["etiquetas"], remoto["referencias"])
        exigir(not self.tags_nuevas & (set(inicial["etiquetas"]) | set(remoto["referencias"])),
               "Una etiqueta prevista ya existe; conserva su identidad y revisa antes de continuar.")
        ya_aplicado = inicial["arbol_indice"] == self.config["arbol_documental"]
        self.cotejar(inicial["arbol_indice"], ya_aplicado)
        self.salida.mkdir(parents=True, exist_ok=False)
        antes = {"fecha_hora_utc": ahora(), "sistema": platform.system(), "identidad": inicial,
                 "remoto": remoto, "sha256_base_cierre": self.config_sha,
                 "paquete": self.paquete_verificado}
        guardar_nuevo(self.salida / "antes.json", antes)
        parche = self.paquete / relativo(self.config["parche"])
        exigir(sha(parche.read_bytes()) == self.config["sha256_parche"], "La huella del parche no coincide.")
        if not ya_aplicado:
            self.git("apply", "--check", "--index", str(parche))
            self.git("apply", "--index", str(parche))
        final = self.identidad(); self.limpio(final)
        exigir(final["arbol_indice"] == self.config["arbol_documental"], "El árbol final no coincide con el paquete.")
        exigir(all(final[k] == inicial[k] for k in ("rama", "head", "main", "etiquetas")),
               "Cambió una referencia local durante la preparación; conserva el estado para revisión.")
        conservacion = self.cotejar(final["arbol_indice"], True)
        registro = {"estado": "APROBADO", "codigo_salida": 0, "fecha_hora_utc": ahora(), "identidad": final,
                    "sha256_antes": sha((self.salida / "antes.json").read_bytes()),
                    "parche_aplicado_en_esta_fase": not ya_aplicado,
                    "documentacion_ya_preparada_al_inicio": ya_aplicado,
                    "main_remoto_avanzado": remoto["referencias"]["refs/heads/main"] != self.config["base_commit"],
                    "conservacion": conservacion,
                    "pruebas_funcionales_nuevas": "NO EJECUTADO: sólo cambia documentación; se conserva el código verificado en Windows.",
                    "commit_merge_etiquetas_push": "NO EJECUTADO por este auxiliar"}
        guardar_nuevo(self.salida / "preparado.json", registro)
        self.guardar_eventos("preparar")
        print("APROBADO: documentación preparada; código y evidencia histórica conservados.")
        print("Árbol documental:", final["arbol_indice"])
        if registro["main_remoto_avanzado"]:
            print("Main remoto avanzó: conserva el commit local y adapta la integración antes de publicar.")
        return registro

    def comprobar(self):
        antes, _ = self.cargar_preparacion()
        exigir(not (self.salida / "prepublicacion.json").exists(),
               "Ya existe un control previo; consérvalo. Revisa su vigencia antes de otro intento.")
        identidad = self.identidad(); self.limpio(identidad, comprometido=True)
        exigir(self.git("merge-base", "--is-ancestor", self.config["base_commit"], identidad["head"], admisibles=(0, 1)).returncode == 0,
               "El commit no conserva la base histórica como antecesor.")
        self.exigir_antecesor(antes["identidad"]["main"], identidad["head"], "main local registrado al preparar")
        self.exigir_antecesor(antes["remoto"]["referencias"]["refs/heads/main"], identidad["head"], "main remoto registrado al preparar")
        cotejo = self.cotejar(identidad["arbol_indice"], True)
        remoto = self.consultar_remoto()
        self.conservar_tags(identidad["etiquetas"], remoto["referencias"], antes)
        remoto_main = remoto["referencias"]["refs/heads/main"]
        exigir(self.git("cat-file", "-e", remoto_main + "^{commit}", admisibles=(0, 1, 128)).returncode == 0,
               "Falta el objeto de main remoto: ejecuta fetch sin etiquetas y conserva cualquier avance.")
        exigir(self.git("merge-base", "--is-ancestor", remoto_main, identidad["head"], admisibles=(0, 1)).returncode == 0,
               "Main remoto avanzó o diverge: intégralo conservando los cambios y revisa antes de publicar.")
        exigir(not self.tags_nuevas & set(remoto["referencias"]),
               "Una etiqueta prevista ya existe remotamente; compara su identidad sin moverla.")
        exigir(all(identidad["etiquetas"].get(t, identidad["head"]) == identidad["head"] for t in self.tags_nuevas),
               "Una etiqueta local prevista apunta a otro objeto; no la muevas ni la borres.")
        registro = {"estado": "APROBADO", "codigo_salida": 0, "fecha_hora_utc": ahora(), "identidad": identidad,
                    "remoto": remoto, "conservacion": cotejo,
                    "sha256_preparado": sha((self.salida / "preparado.json").read_bytes()),
                    "publicacion": "NO EJECUTADO por este auxiliar",
                    "revalidar_si_cambia_head": True}
        guardar_nuevo(self.salida / "prepublicacion.json", registro)
        self.guardar_eventos("comprobar")
        print("APROBADO: commit y main revisados; referencias remotas conservadas.")
        print("Commit previsto para publicar:", identidad["head"])
        return registro

    def registrar(self):
        antes, _ = self.cargar_preparacion()
        previo = leer_json(self.salida / "prepublicacion.json")
        exigir(previo["estado"] == "APROBADO" and previo["sha256_preparado"] == sha((self.salida / "preparado.json").read_bytes()),
               "El control previo no corresponde a esta preparación.")
        for nombre in ("RESULTADO_CIERRE.json", "SHA256_ARCHIVOS.json", "ESTADO_DEL_LIBRO_v1.7.4.md", "ESTADO_REPOSITORIO_v1.6.4.md"):
            exigir(not (self.salida / nombre).exists(), "El cierre ya tiene resultados; conserva esa evidencia sin sobrescribirla.")
        archivo_zip = self.salida.parent / ("EVIDENCIA_" + self.salida.name.upper() + ".zip")
        exigir(not archivo_zip.exists(), "El ZIP de cierre ya existe; consérvalo sin sobrescribirlo.")
        identidad = self.identidad(); self.limpio(identidad, comprometido=True)
        exigir(all(identidad[k] == previo["identidad"][k] for k in ("head", "main", "arbol_indice")),
               "El commit cambió después del control previo; conserva sus referencias y revisa antes del cierre.")
        conservacion = self.cotejar(identidad["arbol_indice"], True)
        remoto = self.consultar_remoto()
        self.conservar_tags(identidad["etiquetas"], remoto["referencias"], antes)
        exigir(remoto["referencias"]["refs/heads/main"] == identidad["head"],
               "Main remoto todavía no coincide con el commit revisado; no se declara publicado.")
        exigir(all(remoto["referencias"].get(t) == identidad["head"]
                   and identidad["etiquetas"].get(t) == identidad["head"] for t in self.tags_nuevas),
               "Las dos etiquetas no coinciden local y remotamente con el commit revisado; conserva todas las referencias.")
        resultado = {"estado": "APROBADO", "codigo_salida": 0, "fecha_hora_utc": ahora(), "sistema_observado": platform.system(),
                     "identidad_git": identidad, "consulta_remota": remoto, "conservacion": conservacion,
                     "arbol_windows_verificado": self.config["arbol_verificado"],
                     "arbol_documental_del_paquete": self.config["arbol_documental"],
                     "sha256_base_cierre": self.config_sha,
                     "sha256_prepublicacion": sha((self.salida / "prepublicacion.json").read_bytes()),
                     "observacion": "Se observa commit, main y dos etiquetas publicados. El auxiliar no ejecutó commit, merge, tag ni push.",
                     "metodo_subida": "La atomicidad y el comando exacto de subida deben cotejarse con la salida de Git Bash aportada por el autor.",
                     "ejecucion_funcional": "Windows ya auditado: 65 baterías, 583 ejecuciones, 571 aprobaciones y doce fallos didácticos. No se repitió por este cierre documental.",
                     "revision_editorial": "Pendiente del autor: capítulos 1–8.",
                     "capitulo_09": "NO EJECUTADO"}
        guardar_nuevo(self.salida / "RESULTADO_CIERRE.json", resultado)
        self.guardar_eventos("registrar")
        self.estados_finales(resultado)
        archivos = sorted(p for p in self.salida.rglob("*") if p.is_file())
        exigir(not any(p.is_symlink() for p in self.salida.rglob("*")), "La evidencia no admite enlaces.")
        guardar_nuevo(self.salida / "SHA256_ARCHIVOS.json", {p.relative_to(self.salida).as_posix(): sha(p.read_bytes()) for p in archivos})
        with ZipFile(archivo_zip, "x", compression=ZIP_DEFLATED) as z:
            for p in sorted(self.salida.rglob("*")):
                if p.is_file():
                    z.write(p, arcname=(Path(self.salida.name) / p.relative_to(self.salida)).as_posix())
        print("APROBADO: main y las dos etiquetas remotas coinciden con el commit revisado.")
        print("ZIP:", archivo_zip.relative_to(self.repo).as_posix())
        print("SHA256:", sha(archivo_zip.read_bytes()))
        return resultado

    def guardar_eventos(self, fase):
        eventos = json.dumps({"fase": fase, "fecha_hora_utc": ahora(), "comandos": self.eventos}, ensure_ascii=False, indent=2)
        for ruta, alias in ((self.repo, "<REPOSITORIO>"), (self.paquete, "<PAQUETE>"), (self.salida, "<SALIDA>")):
            for forma in (str(ruta), ruta.as_posix()):
                eventos = eventos.replace(forma.replace("\\", "\\\\"), alias).replace(forma, alias)
        with (self.salida / ("COMANDOS_" + fase.upper() + ".json")).open("x", encoding="utf-8", newline="\n") as f:
            f.write(eventos + "\n")

    def estados_finales(self, resultado):
        fecha = datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=-7))).isoformat(timespec="seconds")
        commit = resultado["identidad_git"]["head"]
        arbol = resultado["identidad_git"]["arbol_indice"]
        comun = (f"Fecha de observación: {fecha} (UTC-07:00).\n\n"
                 f"**APROBADO: cierre observado.** Main y las etiquetas `lab-08-v1.0` y `repositorio-v1.4` "
                 f"coinciden local y remotamente en `{commit}`, árbol `{arbol}`. "
                 f"Entorno del registro: {platform.system()}. La evidencia `RESULTADO_CIERRE.json` conserva la consulta efectiva.\n\n"
                 "La etiqueta del laboratorio 8 identifica su primera publicación e incluye la distribución corregida 1.0.1; "
                 "la distribución original 1.0 y su evidencia fallida se conservan. El código y los archivos protegidos coinciden "
                 f"con el árbol Windows verificado `{self.config['arbol_verificado']}`.\n\n"
                 "La ejecución funcional previa en Windows está auditada: 65 baterías, 583 ejecuciones, 571 aprobaciones, "
                 "doce fallos didácticos previstos, cero bloqueos y cero errores de ejecución; 48 NO EJECUTADO y diez ausentes aparte. "
                 "Sus ocho pruebas del recolector, cuatro de recursos y nueve del evaluador se cuentan separadamente. "
                 "Este cierre documental no añade otra ejecución funcional.\n\n"
                 "Se conservaron las referencias históricas y los archivos revisados. El auxiliar observó las referencias remotas "
                 "y no ejecutó la subida. La salida de Git Bash permite cotejar el comando de publicación.\n\n"
                 "Los capítulos 1–8 siguen pendientes de revisión editorial del autor. El maestro v1.0 permanece vigente. "
                 "No se redactó el capítulo 9. La siguiente entrega podrá partir de este commit y de estos estados, después de "
                 "reconsultar las referencias y conservar cualquier avance.\n\n"
                 "Este documento se generó después de publicar y se conserva fuera del commit al que se refiere. "
                 "Su incorporación futura debe hacerse como una adición documental, sin mover etiquetas.\n")
        for nombre, titulo, anterior in (
            ("ESTADO_DEL_LIBRO_v1.7.4.md", "Estado del libro · cierre del laboratorio 8", "ESTADO_DEL_LIBRO_v1.7.3.md"),
            ("ESTADO_REPOSITORIO_v1.6.4.md", "Estado operativo · laboratorio 8 publicado", "ESTADO_REPOSITORIO_v1.6.3.md")):
            with (self.salida / nombre).open("x", encoding="utf-8", newline="\n") as f:
                f.write("# " + titulo + "\n\nAntecedente conservado: `" + anterior + "`.\n\n" + comun)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("fase", choices=("preparar", "comprobar", "registrar"))
    parser.add_argument("--repositorio", type=Path, default=Path("."))
    parser.add_argument("--salida", type=Path, default=Path("trabajo/cierre_lab08_windows_01"))
    args = parser.parse_args()
    cierre = Cierre(args.repositorio, Path(__file__).resolve().parent, args.salida)
    getattr(cierre, args.fase)()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ErrorCierre as error:
        print("FALLIDO: " + str(error))
        print("Se conserva el estado actual. No se fuerza ni se elimina ninguna referencia.")
        raise SystemExit(1)
    except (OSError, ValueError, KeyError, TypeError):
        print("FALLIDO: no se pudo completar la comprobación del cierre; conserva los archivos y el estado Git para revisión.")
        raise SystemExit(1)
