"""Regresiones del auxiliar en Git aislado; sin red ni publicación real."""

import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile

from GESTIONAR_CIERRE_08 import Cierre, ErrorCierre, ahora, sha


class CierreTests(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory(prefix="qa_cierre08_")
        self.addCleanup(self.temporal.cleanup)
        self.raiz = Path(self.temporal.name)
        self.repo = self.raiz / "repo"
        self.remoto = self.raiz / "remoto.git"
        self.pack = self.raiz / "paquete"
        self.repo.mkdir(); self.pack.mkdir()
        self.entorno = dict(os.environ, GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM="1",
                            GIT_AUTHOR_NAME="Autor sintetico", GIT_AUTHOR_EMAIL="autor@example.invalid",
                            GIT_COMMITTER_NAME="Autor sintetico", GIT_COMMITTER_EMAIL="autor@example.invalid",
                            GIT_TERMINAL_PROMPT="0")
        self.git("init", "--quiet", "--initial-branch=main")
        (self.repo / ".gitignore").write_text("trabajo/\n", encoding="utf-8")
        (self.repo / "codigo.py").write_text("VALOR = 1\n", encoding="utf-8")
        (self.repo / "README.md").write_text("Estado inicial.\n", encoding="utf-8")
        self.git("add", ".")
        self.git("commit", "--quiet", "-m", "Base sintetica")
        self.base = self.git("rev-parse", "HEAD").strip()
        self.git("tag", "historica", self.base)
        self.git("switch", "--quiet", "-c", "integracion/laboratorio-08")
        (self.repo / "verificado.txt").write_text("Estado funcional revisado.\n", encoding="utf-8")
        self.git("add", "verificado.txt")
        self.verificado = self.git("write-tree").strip()
        self.protegidos = {n: sha((self.repo / n).read_bytes()) for n in [".gitignore", "codigo.py", "verificado.txt"]}
        (self.repo / "README.md").write_text("Cierre documental preparado.\n", encoding="utf-8")
        (self.repo / "docs").mkdir()
        (self.repo / "docs/estado.md").write_text("Publicación pendiente.\n", encoding="utf-8")
        self.git("add", "README.md", "docs/estado.md")
        self.documental = self.git("write-tree").strip()
        self.documentos = {n: sha((self.repo / n).read_bytes()) for n in ["README.md", "docs/estado.md"]}
        cambio = self.git_bytes("diff", "--binary", "--full-index", self.verificado, self.documental)
        (self.pack / "INCORPORAR_CIERRE_LABORATORIO_08.patch").write_bytes(cambio)
        self.git("read-tree", "--reset", "-u", self.verificado)
        # Toda escritura Git de esta batería se limita a esta carpeta temporal.
        self.git("init", "--quiet", "--bare", str(self.remoto))
        self.git_remoto("fetch", "--quiet", "--no-tags", str(self.repo), "main:refs/heads/main")
        self.git_remoto("update-ref", "refs/tags/historica", self.base)
        self.git("remote", "add", "origin", "https://github.com/ccortesg/laboratorios-desarrollo-ia.git")
        protegido_bytes = (json.dumps(self.protegidos, sort_keys=True) + "\n").encode()
        (self.pack / "PROTEGIDOS.json").write_bytes(protegido_bytes)
        self.config = {
            "base_commit": self.base, "arbol_verificado": self.verificado, "arbol_documental": self.documental,
            "parche": "INCORPORAR_CIERRE_LABORATORIO_08.patch", "sha256_parche": sha(cambio),
            "repositorio": "ccortesg/laboratorios-desarrollo-ia", "etiquetas_previstas": ["lab-08-v1.0", "repositorio-v1.4"],
            "etiquetas_historicas": {"refs/tags/historica": self.base},
            "archivo_protegidos": "PROTEGIDOS.json", "sha256_archivo_protegidos": sha(protegido_bytes),
            "archivos_documentales": self.documentos}
        (self.pack / "BASE_CIERRE.json").write_text(json.dumps(self.config), encoding="utf-8")
        self.manifiesto()
        # Sólo se sustituye el transporte de lectura por un bare local real.
        # No existe un argumento CLI para autorizar un remoto distinto.
        def consultar(objeto):
            objeto.autorizar_origin()
            refs = dict(line.split("\t", 1)[::-1] for line in self.git_remoto(
                "for-each-ref", "--format=%(objectname)%09%(refname)", "refs/heads/main", "refs/tags").splitlines())
            return {"fecha_hora_utc": ahora(), "referencias": refs,
                    "metodo": "QA: lectura de bare Git local aislado; no consulta GitHub."}
        self.lectura = patch.object(Cierre, "consultar_remoto", consultar)
        self.lectura.start(); self.addCleanup(self.lectura.stop)
        self.salida = "trabajo/cierre_lab08_qa_01"

    def run_git(self, args, cwd=None, datos=None):
        p = subprocess.run(["git", *args], cwd=cwd or self.repo, env=self.entorno,
                           input=datos, capture_output=True)
        self.assertEqual(p.returncode, 0, p.stderr.decode("utf-8", errors="replace"))
        return p.stdout

    def git(self, *args):
        return self.run_git(args).decode("utf-8")

    def git_bytes(self, *args):
        return self.run_git(args)

    def git_remoto(self, *args):
        return self.run_git(["--git-dir=" + str(self.remoto), *args]).decode("utf-8")

    def manifiesto(self):
        archivos = sorted(p for p in self.pack.iterdir() if p.is_file() and p.name != "SHA256SUMS")
        (self.pack / "SHA256SUMS").write_text("".join(sha(p.read_bytes()) + "  " + p.name + "\n" for p in archivos), encoding="utf-8")

    def contexto(self, salida=None):
        return Cierre(self.repo, self.pack, salida or self.salida)

    def fase(self, nombre, salida=None):
        with contextlib.redirect_stdout(io.StringIO()):
            return getattr(self.contexto(salida), nombre)()

    def confirmar_main(self):
        self.git("commit", "--quiet", "-m", "Integra material sintetico y cierre documental")
        self.git("switch", "--quiet", "main")
        self.git("merge", "--quiet", "--ff-only", "integracion/laboratorio-08")
        return self.git("rev-parse", "HEAD").strip()

    def publicar_fixture(self):
        commit = self.git("rev-parse", "HEAD").strip()
        self.git_remoto("fetch", "--quiet", "--no-tags", str(self.repo), "main:refs/heads/main")
        for nombre in self.config["etiquetas_previstas"]:
            self.git("tag", nombre, commit)
            self.git_remoto("update-ref", "refs/tags/" + nombre, commit)

    def test_preparar_aplica_y_reanudacion_no_reaplica(self):
        primero = self.fase("preparar")
        self.assertTrue(primero["parche_aplicado_en_esta_fase"])
        self.assertEqual(self.git("write-tree").strip(), self.documental)
        self.assertEqual(self.git("rev-parse", "main").strip(), self.base)
        self.assertEqual(self.git("rev-parse", "historica").strip(), self.base)
        segundo = self.fase("preparar", "trabajo/cierre_lab08_qa_02")
        self.assertFalse(segundo["parche_aplicado_en_esta_fase"])
        self.assertTrue(segundo["documentacion_ya_preparada_al_inicio"])

    def test_archivo_protegido_modificado_rechaza_publicacion(self):
        self.fase("preparar")
        (self.repo / "codigo.py").write_text("VALOR = 2\n", encoding="utf-8")
        self.git("add", "codigo.py")
        commit = self.confirmar_main()
        with self.assertRaisesRegex(ErrorCierre, "archivo protegido"):
            self.fase("comprobar")
        self.assertEqual(self.git("rev-parse", "HEAD").strip(), commit)
        self.assertFalse((self.repo / self.salida / "prepublicacion.json").exists())

    def test_etiqueta_remota_existente_no_se_mueve(self):
        self.git_remoto("update-ref", "refs/tags/lab-08-v1.0", self.base)
        with self.assertRaisesRegex(ErrorCierre, "etiqueta prevista ya existe"):
            self.fase("preparar")
        self.assertEqual(self.git("write-tree").strip(), self.verificado)
        self.assertEqual(self.git_remoto("rev-parse", "refs/tags/lab-08-v1.0").strip(), self.base)

    def test_main_remoto_divergente_se_conserva(self):
        self.fase("preparar"); local = self.confirmar_main()
        arbol_base = self.git("rev-parse", self.base + "^{tree}").strip()
        avance = self.run_git(["commit-tree", arbol_base, "-p", self.base], datos=b"Avance sintetico remoto\n").decode().strip()
        self.git("update-ref", "refs/heads/avance_remoto", avance)
        self.git_remoto("fetch", "--quiet", "--no-tags", str(self.repo), "avance_remoto:refs/heads/main")
        with self.assertRaisesRegex(ErrorCierre, "Main remoto avanzó o diverge"):
            self.fase("comprobar")
        self.assertEqual(self.git("rev-parse", "HEAD").strip(), local)
        self.assertEqual(self.git_remoto("rev-parse", "refs/heads/main").strip(), avance)

    def test_preparar_conserva_y_registra_avance_remoto(self):
        arbol_base = self.git("rev-parse", self.base + "^{tree}").strip()
        avance = self.run_git(["commit-tree", arbol_base, "-p", self.base], datos=b"Avance previo sintetico\n").decode().strip()
        self.git("update-ref", "refs/heads/avance_remoto", avance)
        self.git_remoto("fetch", "--quiet", "--no-tags", str(self.repo), "avance_remoto:refs/heads/main")
        resultado = self.fase("preparar")
        self.assertTrue(resultado["main_remoto_avanzado"])
        self.assertEqual(self.git("write-tree").strip(), self.documental)
        self.assertEqual(self.git("rev-parse", "HEAD").strip(), self.base)
        self.assertEqual(self.git("rev-parse", "main").strip(), self.base)
        self.assertEqual(self.git_remoto("rev-parse", "refs/heads/main").strip(), avance)

    def test_perdida_del_main_local_capturado_se_detecta(self):
        arbol_base = self.git("rev-parse", self.base + "^{tree}").strip()
        avance = self.run_git(["commit-tree", arbol_base, "-p", self.base], datos=b"Avance local previo\n").decode().strip()
        self.git("update-ref", "refs/heads/main", avance)
        self.fase("preparar")
        # Se simula una pérdida de historia sólo dentro de esta fixture.
        self.git("update-ref", "refs/heads/main", self.base)
        final = self.confirmar_main()
        with self.assertRaisesRegex(ErrorCierre, "main local registrado al preparar"):
            self.fase("comprobar")
        self.assertEqual(self.git("rev-parse", "HEAD").strip(), final)
        self.assertFalse((self.repo / self.salida / "prepublicacion.json").exists())

    def test_perdida_del_main_remoto_capturado_se_detecta(self):
        arbol_base = self.git("rev-parse", self.base + "^{tree}").strip()
        avance = self.run_git(["commit-tree", arbol_base, "-p", self.base], datos=b"Avance remoto previo\n").decode().strip()
        self.git("update-ref", "refs/heads/avance_remoto", avance)
        self.git_remoto("fetch", "--quiet", "--no-tags", str(self.repo), "avance_remoto:refs/heads/main")
        self.fase("preparar")
        # El remoto aislado vuelve atrás; el snapshot debe impedir aprobarlo.
        self.git_remoto("update-ref", "refs/heads/main", self.base)
        final = self.confirmar_main()
        with self.assertRaisesRegex(ErrorCierre, "main remoto registrado al preparar"):
            self.fase("comprobar")
        self.assertEqual(self.git("rev-parse", "HEAD").strip(), final)
        self.assertEqual(self.git_remoto("rev-parse", "refs/heads/main").strip(), self.base)

    def test_tag_local_en_otro_commit_se_conserva(self):
        self.fase("preparar"); self.confirmar_main()
        self.git("tag", "lab-08-v1.0", self.base)
        with self.assertRaisesRegex(ErrorCierre, "etiqueta local prevista"):
            self.fase("comprobar")
        self.assertEqual(self.git("rev-parse", "lab-08-v1.0").strip(), self.base)

    def test_registro_exige_publicacion_y_genera_zip_de_bytes(self):
        self.fase("preparar"); commit = self.confirmar_main(); self.fase("comprobar")
        with self.assertRaisesRegex(ErrorCierre, "Main remoto todavía no coincide"):
            self.fase("registrar")
        self.assertFalse((self.repo / self.salida / "RESULTADO_CIERRE.json").exists())
        self.publicar_fixture()
        resultado = self.fase("registrar")
        self.assertEqual(resultado["estado"], "APROBADO")
        self.assertEqual(resultado["identidad_git"]["head"], commit)
        self.assertEqual(resultado["consulta_remota"]["metodo"], "QA: lectura de bare Git local aislado; no consulta GitHub.")
        zip_path = self.repo / "trabajo/EVIDENCIA_CIERRE_LAB08_QA_01.zip"
        with ZipFile(zip_path) as z:
            self.assertIsNone(z.testzip())
            prefix = "cierre_lab08_qa_01/"
            manifesto = json.loads(z.read(prefix + "SHA256_ARCHIVOS.json"))
            self.assertEqual(set(manifesto), {n[len(prefix):] for n in z.namelist()} - {"SHA256_ARCHIVOS.json"})
            for nombre, digest in manifesto.items():
                self.assertEqual(sha(z.read(prefix + nombre)), digest)
        self.assertEqual(self.git("status", "--porcelain").strip(), "")

    def test_cambio_despues_de_comprobar_no_se_declara_cerrado(self):
        self.fase("preparar"); self.confirmar_main(); self.fase("comprobar")
        self.git("commit", "--quiet", "--allow-empty", "-m", "Avance posterior al control")
        nuevo = self.git("rev-parse", "HEAD").strip()
        with self.assertRaisesRegex(ErrorCierre, "commit cambió después"):
            self.fase("registrar")
        self.assertEqual(self.git("rev-parse", "HEAD").strip(), nuevo)

    def test_url_push_ajena_rechaza_antes_de_aplicar(self):
        self.git("remote", "set-url", "--push", "origin", "https://github.com/otro/repositorio.git")
        with self.assertRaisesRegex(ErrorCierre, "Origin debe tener"):
            self.fase("preparar")
        self.assertEqual(self.git("write-tree").strip(), self.verificado)
        self.assertFalse((self.repo / self.salida).exists())

    def test_salida_existente_no_se_sobrescribe(self):
        self.fase("preparar")
        ruta = self.repo / self.salida / "preparado.json"
        antes = ruta.read_bytes()
        with self.assertRaisesRegex(ErrorCierre, "salida ya existe"):
            self.fase("preparar")
        self.assertEqual(ruta.read_bytes(), antes)

    def test_archivo_extra_no_autorizado_requiere_revision(self):
        self.fase("preparar")
        (self.repo / "otro_codigo.py").write_text("OTRO = True\n", encoding="utf-8")
        self.git("add", "otro_codigo.py")
        self.confirmar_main()
        with self.assertRaisesRegex(ErrorCierre, "fuera del incremento documental"):
            self.fase("comprobar")
        self.assertTrue((self.repo / "otro_codigo.py").is_file())

    def test_salida_con_enlace_no_escribe_fuera_del_repositorio(self):
        externo = self.raiz / "externo"
        externo.mkdir()
        (self.repo / "trabajo").symlink_to(externo, target_is_directory=True)
        with self.assertRaisesRegex(ErrorCierre, "salida no admite enlaces"):
            self.fase("preparar")
        self.assertEqual(list(externo.iterdir()), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
