# Cierre documental y publicación del laboratorio 8

Este paquete continúa desde el árbol corregido que aprobó en Windows: `9ea6109fe8e89a2785bdce255252ffaabea1d122`. El incremento documental prepara el árbol `d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0`. No sustituye ni reaplica los paquetes de incorporación o corrección anteriores.

## Orden de uso

Descomprime el ZIP y sigue `INSTRUCCIONES_WINDOWS.md`. Primero ejecuta `python -B VERIFICAR_PAQUETE.py`. Después utiliza las fases `preparar`, `comprobar` y `registrar` de `GESTIONAR_CIERRE_08.py` en el orden indicado, separadas por los comandos Git expresos de la guía.

El autor autorizó el commit, la integración en main y la publicación exclusiva de `lab-08-v1.0` y `repositorio-v1.4`. El auxiliar aplica la documentación y comprueba estados; los comandos de commit, merge, tag y push quedan explícitos en la guía. No ejecuta esas cuatro operaciones automáticamente.

## Contenido útil

| Archivo o carpeta | Función |
| --- | --- |
| `INSTRUCCIONES_WINDOWS.md` | Recorrido completo con comandos exactos y resultados que deben comprobarse. |
| `GESTIONAR_CIERRE_08.py` | Aplicación documental, protección de archivos y referencias, registro del cierre observado. |
| `INCORPORAR_CIERRE_LABORATORIO_08.patch` | Diferencia documental entre el árbol Windows y el nuevo árbol. |
| `BASE_CIERRE.json` | Commit y árboles, etiquetas autorizadas, rutas documentales y huellas esperadas. |
| `ARCHIVOS_PROTEGIDOS.json` | SHA-256 de los 1.486 archivos que deben conservar sus bytes. |
| `SHA256SUMS` y `VERIFICAR_PAQUETE.py` | Inventario completo del paquete y comprobación local de integridad. |
| `ESTADO_DEL_LIBRO_v1.7.3.md` | Continuidad editorial: documentación preparada y revisión del autor pendiente. |
| `ESTADO_REPOSITORIO_v1.6.3.md` | Continuidad operativa anterior a la publicación. |
| `evidencia/` | Comprobaciones de preparación, aplicación del parche y revisión del procedimiento. |
| `test_gestionar_cierre_08.py` | Pruebas auxiliares en repositorios Git temporales aislados. |

## Qué queda conservado

El parche cambia 25 rutas documentales: incorpora la revisión Windows y su evidencia original, añade los estados vigentes y actualiza las referencias de continuidad. No cambia código, contratos, datos, distribuciones, herramientas comunes ni evidencias anteriores. La distribución corregida `LABORATORIO_08_v1.0.1.zip` sigue siendo la versión técnica verificada; la 1.0 queda como antecedente. `lab-08-v1.0` será la primera etiqueta publicada del laboratorio, con la distribución corregida incluida.

La evidencia funcional histórica sigue atribuida a la ejecución Windows del autor: 65 baterías, 583 ejecuciones, 571 aprobaciones y doce fallos didácticos previstos; cero bloqueos y cero errores de ejecución. Las pruebas de esta preparación son auxiliares y no aumentan esas cifras.

## Estado real de esta entrega

La preparación se ejecutó en Linux, sobre una copia aislada. La consulta remota de preparación y las comprobaciones locales están registradas. Todavía no acreditan un commit, una integración ni una publicación ejecutados en la copia Windows del autor.

Después del push manual, `registrar` exige que el commit revisado coincida con main y las dos etiquetas local y remotamente, y que todas las etiquetas históricas permanezcan. Sólo entonces escribe `RESULTADO_CIERRE.json`, los estados observados 1.7.4/1.6.4 y el ZIP de evidencia nuevo. La salida del push del autor completa la evidencia del comando atómico utilizado.

Si cambian archivos o referencias, conserva el estado y revisa la diferencia. El auxiliar rechaza avances que no pueda validar; no descarta cambios, no fuerza referencias y no altera el manifiesto para aceptar otro contenido. El procedimiento de adaptación está descrito en la guía.

Los capítulos 1–8 siguen pendientes de revisión editorial del autor. El capítulo 9 no forma parte de este cierre.
