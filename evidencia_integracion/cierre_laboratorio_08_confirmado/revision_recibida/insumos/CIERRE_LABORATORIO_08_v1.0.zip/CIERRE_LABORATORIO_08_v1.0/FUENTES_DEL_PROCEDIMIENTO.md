# Fuentes primarias del procedimiento

Consulta efectiva: 1 de noviembre de 2026, UTC.

## Git: aplicar frente a comprobar

[`git apply`](https://git-scm.com/docs/git-apply) documenta que `--check` comprueba la aplicabilidad sin aplicar el parche. Con `--index`, una aplicación modifica índice y árbol de trabajo. El auxiliar de este paquete ejecuta primero la comprobación y después la aplicación real; no trata la primera como si hubiera cambiado archivos.

## Git: publicación de referencias concretas

[`git push`](https://git-scm.com/docs/git-push) documenta los refspecs, `--atomic` y `--no-follow-tags`. La guía especifica main y las dos etiquetas autorizadas mediante sus referencias completas. `--atomic` solicita una transacción remota en la que se actualizan todas esas referencias o ninguna; si el servidor no soporta esa modalidad, Git rechaza la operación. `--no-follow-tags` desactiva el seguimiento automático de etiquetas adicionales.

Estos documentos describen el comportamiento de Git. La publicación real del laboratorio sólo queda acreditada por la salida del comando ejecutado por el autor y la consulta posterior de las referencias. Las pruebas auxiliares locales del procedimiento no equivalen a un push real a GitHub.
