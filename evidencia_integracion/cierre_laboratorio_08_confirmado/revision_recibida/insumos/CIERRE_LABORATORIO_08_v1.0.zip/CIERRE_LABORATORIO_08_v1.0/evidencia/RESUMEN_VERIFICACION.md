# Verificación de la preparación del cierre

Fecha de consulta y preparación: 1 de noviembre de 2026, UTC. Esta evidencia corresponde a una preparación en Linux; la ejecución Windows funcional anterior pertenece al autor.

## Resultado alcanzado

**APROBADO: parche documental y auxiliar preparados para el recorrido Windows.** El punto de partida es el árbol corregido `9ea6109fe8e89a2785bdce255252ffaabea1d122`; el parche produjo realmente `d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0` en una copia aislada. Se cotejaron las 25 rutas documentales y los bytes y modos de los 1.486 archivos protegidos. La copia fuente permaneció idéntica.

| Comprobación | Resultado observado | Evidencia |
| --- | --- | --- |
| Auxiliar: casos positivos y rechazos por pérdida de historia, cambios ajenos, colisiones, salidas existentes y otros límites concretos | APROBADO: 14 pruebas, salida 0 | `auxiliar/RESULTADO_QA_AUXILIAR.json` y sus flujos. |
| Aplicación del payload real después de empaquetar y descomprimir | APROBADO: árbol documental exacto, 25 rutas, 1.486 archivos protegidos | `paquete_real_qa/RESULTADO_QA_PAYLOAD_REAL.json`. |
| Fases del auxiliar con commit e integración por avance rápido en copia temporal | APROBADO dentro de la QA controlada | `paquete_real_qa/COMANDOS_QA.json`. |
| Guía de Git Bash | APROBADO: sintaxis de sus 16 bloques | `SINTAXIS_GUIA.json`. |
| Coherencia entre configuración, parche, auxiliar y estados | APROBADO | `REVISION_ARCHIVOS.json`. |
| Revisión independiente de conservación de main e instrucciones | APROBADO por revisión del código y de la guía | `procedimiento_revisado.md`. |
| Consulta real a GitHub al terminar la preparación | APROBADO: main 46f389b…, once etiquetas históricas, nuevas ausentes | `REFERENCIAS_ANTES_DE_ENTREGAR.json`. |
| Aplicación, commit, main, etiquetas y push en la copia Windows del autor | NO EJECUTADO en esta sesión | Se producirán al seguir la guía. |

Se comprobaron además 35 enlaces relativos en los Markdown incorporados; todos resuelven dentro de la copia preparada.

## Límites de las pruebas auxiliares

Las 14 pruebas utilizan Git y un remoto bare local aislados. La prueba con el payload del proyecto utiliza el código, el índice y los blobs reales en una copia temporal, y sustituye expresamente la consulta remota y el inventario de once identidades históricas. La copia fuente es superficial y no incluye todos los objetos de las etiquetas antiguas. El intento inicial detenido por esa limitación de la fixture se conserva en `paquete_real_qa_intento01/INTENTO_FIXTURE.json`; no fue una ejecución fallida del parche.

La prueba posterior conserva reales la aplicación del parche, el commit sintético, la integración por avance rápido y la comprobación de archivos. Ninguna de esas operaciones modifica GitHub ni el equipo Windows. Los estados y el ZIP de cierre simulados se eliminaron junto con la copia temporal. Las referencias reales de GitHub se consultaron separadamente mediante lectura y se distinguen de esas respuestas controladas.

La comprobación de sintaxis no equivale a ejecutar los comandos de la guía en Windows. La publicación real y el cierre posterior todavía deben observarse. La prueba del paquete descargable final se realiza después de añadir esta auditoría; sus instrucciones y payload conservan las huellas comprobadas.

## Evidencia funcional que se conserva

La ejecución Windows auditada continúa siendo la misma: 65 baterías, 583 ejecuciones, 571 aprobaciones y doce fallos didácticos previstos; cero bloqueos y cero errores de ejecución; 48 NO EJECUTADO y diez ausentes aparte. Sus ocho pruebas del recolector, cuatro de recursos y nueve del evaluador siguen separadas. La incorporación documental no modifica el código y no se presenta como una nueva ejecución funcional.

Los capítulos 1–8 siguen pendientes de revisión editorial. El capítulo 9 continúa fuera del encargo.
