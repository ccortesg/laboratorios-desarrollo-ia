# Cierre del laboratorio 8 en Git Bash de Windows

## Qué hace esta entrega

El código corregido ya aprobó en Windows sobre el árbol `9ea6109fe8e89a2785bdce255252ffaabea1d122`. Esta entrega añade documentación y evidencia; conserva el código, las distribuciones y los antecedentes. El nuevo árbol documental es `d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0`.

El auxiliar tiene tres fases: `preparar` aplica el parche documental y registra la base; `comprobar` revisa el commit integrado antes de publicar; `registrar` comprueba las referencias después de publicar y genera el ZIP de cierre. El auxiliar no crea commits, no integra ramas, no crea etiquetas ni ejecuta push. Esas operaciones se realizan expresamente en los bloques Git de esta guía, autorizados por el encargo de cierre.

Trabaja en tu copia existente. No vuelvas a aplicar los parches de incorporación o de corrección del laboratorio 8. No copies estos archivos sobre `laboratorios/laboratorio_08/`. Ejecuta cada bloque completo y continúa sólo si termina con el resultado indicado. Captura `$?` inmediatamente, como aparece en los bloques.

## 1. Extraer y verificar el paquete

Descomprime `CIERRE_LABORATORIO_08_v1.0.zip` para que el auxiliar quede directamente en:

`C:\github\CIERRE_LABORATORIO_08_v1.0\GESTIONAR_CIERRE_08.py`

Evita una segunda carpeta del mismo nombre anidada dentro. Ejecuta:

```bash
cd /c/github/CIERRE_LABORATORIO_08_v1.0
export PYTHONIOENCODING=utf-8
python -B VERIFICAR_PAQUETE.py
codigo_paquete_cierre08=$?
printf 'Codigo del paquete: %s\n' "$codigo_paquete_cierre08"
```

Debe indicar APROBADO y código 0. El verificador comprueba el inventario completo y las huellas del paquete, sin modificar el repositorio.

## 2. Preparar la incorporación documental

```bash
cd /c/github/laboratorios-desarrollo-ia
python -B /c/github/CIERRE_LABORATORIO_08_v1.0/GESTIONAR_CIERRE_08.py preparar --repositorio . --salida trabajo/cierre_lab08_windows_01
codigo_preparacion_cierre08=$?
printf 'Codigo de preparacion: %s\n' "$codigo_preparacion_cierre08"
```

Debe indicar APROBADO, código 0 y árbol `d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0`. Esta fase comprueba el paquete, HEAD, el índice, las URLs de lectura/publicación de origin, las etiquetas y los archivos protegidos. Ejecuta tanto la comprobación del parche como su aplicación real. Si el árbol documental ya estuviera aplicado, lo reconoce y no lo aplica de nuevo; aun así necesita una carpeta de evidencia nueva.

El estado previsto al empezar es la rama `integracion/laboratorio-08`, HEAD `46f389bc4acf3e231a8eb1a1bb3972db0fe7e622` e índice 9ea6109.... Si hay diferencias, se conservan y se informa el límite. Un main remoto avanzado queda registrado; se incorpora después de crear el commit local. No se restablecen ramas.

## 3. Revisar lo que se incorporará

```bash
git branch --show-current
git diff --cached --check
git diff --name-only
git write-tree
git --no-pager diff --cached --stat 9ea6109fe8e89a2785bdce255252ffaabea1d122
```

La rama debe seguir siendo `integracion/laboratorio-08`; las dos comprobaciones de diferencias iniciales deben quedar sin salida; el árbol debe ser d7cc2ce.... El resumen del incremento documental comprende 25 rutas. El índice también conserva toda la incorporación del laboratorio 8 que ya estaba preparada: no es necesario ejecutar `git add .`.

Los 1.486 archivos protegidos coinciden con el árbol Windows verificado. Por eso no se repiten las 583 ejecuciones funcionales en este cierre documental. Si incorporas un cambio de código, esa justificación deja de ser suficiente.

## 4. Crear el commit en la rama de integración

```bash
git commit -m "Integra laboratorio 8 y evidencia verificada en Windows"
codigo_commit_cierre08=$?
printf 'Codigo del commit: %s\n' "$codigo_commit_cierre08"
```

Debe terminar con código 0. Después:

```bash
git rev-parse HEAD
git rev-parse 'HEAD^{tree}'
git status --short
```

El commit será un identificador nuevo. Su árbol debe ser d7cc2ce... y el estado debe quedar limpio. Conserva la salida. Si Git solicita configurar identidad o un hook bloquea el commit, atiende ese mensaje sin inventar una identidad ni desactivar controles automáticamente.

## 5. Conservar avances de main

Actualiza primero la referencia remota, sin importar etiquetas:

```bash
git fetch --no-tags origin
codigo_fetch_cierre08=$?
printf 'Codigo del fetch: %s\n' "$codigo_fetch_cierre08"
```

Continúa sólo con código 0. Todavía en la rama de integración, conserva primero main local y después origin/main:

```bash
git merge --no-edit main
codigo_main_local_cierre08=$?
printf 'Codigo de incorporacion de main local: %s\n' "$codigo_main_local_cierre08"
```

```bash
git merge --no-edit origin/main
codigo_main_remoto_cierre08=$?
printf 'Codigo de incorporacion de main remoto: %s\n' "$codigo_main_remoto_cierre08"
```

Cada bloque debe terminar con código 0. Con las referencias observadas al preparar el paquete, ambos merges indicarán que ya estaba actualizado. Si hay conflictos, conserva el estado y revisa antes de seguir: no uses reset ni descartes archivos.

Comprueba que el contenido resultante siga siendo el revisado:

```bash
git diff --quiet d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0 HEAD --
codigo_arbol_cierre08=$?
printf 'Codigo de conservacion del arbol: %s\n' "$codigo_arbol_cierre08"
```

Con código 0, continúa. Con código 1 hay contenido adicional o diferente: conserva el commit y ejecuta `git --no-pager diff --name-status d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0 HEAD --` para revisar el avance. Ese caso requiere adaptar el cierre; si afecta código, ejecutar las comprobaciones pertinentes. No edites el manifiesto para aceptar cambios sin revisar.

## 6. Integrar en main mediante avance rápido

```bash
git switch main && git merge --ff-only integracion/laboratorio-08
codigo_integracion_cierre08=$?
printf 'Codigo de integracion en main: %s\n' "$codigo_integracion_cierre08"
```

Debe terminar con código 0. Un rechazo conserva las ramas y exige revisar su relación; no fuerces la integración.

Ahora realiza el control previo a la publicación:

```bash
python -B /c/github/CIERRE_LABORATORIO_08_v1.0/GESTIONAR_CIERRE_08.py comprobar --repositorio . --salida trabajo/cierre_lab08_windows_01
codigo_control_cierre08=$?
printf 'Codigo del control previo: %s\n' "$codigo_control_cierre08"
```

Debe indicar APROBADO y código 0. Comprobará main limpio, el código y documentos, la conservación de los main registrados al preparar, el main remoto actual y las etiquetas. Guardará `prepublicacion.json` con el commit concreto que se publicará. Si cambias HEAD después, ese registro ya no permite cerrar automáticamente.

## 7. Crear únicamente las dos etiquetas autorizadas

```bash
git tag lab-08-v1.0 HEAD && git tag repositorio-v1.4 HEAD
codigo_etiquetas_cierre08=$?
printf 'Codigo de creacion de etiquetas: %s\n' "$codigo_etiquetas_cierre08"
```

Debe terminar con código 0. Si alguna ya existe, conserva su identidad y revísala; no uses `-f` ni la borres. La etiqueta `lab-08-v1.0` es la primera publicación del laboratorio e incluye la distribución técnica corregida 1.0.1. `repositorio-v1.4` identifica el conjunto integrado.

Comprueba los tres objetivos locales:

```bash
git rev-parse HEAD lab-08-v1.0 repositorio-v1.4
```

Las tres líneas deben mostrar el mismo commit nuevo.

## 8. Publicar main y esas dos etiquetas

Ejecuta el comando completo:

```bash
git push --atomic --no-follow-tags origin refs/heads/main:refs/heads/main refs/tags/lab-08-v1.0:refs/tags/lab-08-v1.0 refs/tags/repositorio-v1.4:refs/tags/repositorio-v1.4
codigo_push_cierre08=$?
printf 'Codigo de publicacion: %s\n' "$codigo_push_cierre08"
```

Debe terminar con código 0. Conserva esta salida para acreditar el comando de publicación utilizado. El alcance explícito comprende sólo main y las dos etiquetas nuevas.

Si Git rechaza la subida porque main avanzó o apareció una etiqueta, conserva las referencias existentes y envía el mensaje para adaptar el cierre. No muevas las etiquetas locales automáticamente al commit que resulte de otro merge, ni uses push forzado. Si hay un error de red con resultado incierto, consulta las referencias antes de repetir la publicación.

## 9. Confirmar las referencias reales y registrar el cierre

```bash
git ls-remote --refs origin refs/heads/main refs/tags/lab-08-v1.0 refs/tags/repositorio-v1.4
git rev-parse HEAD
git status --short
```

Main remoto y las dos etiquetas deben mostrar el mismo commit local; el estado debe estar limpio. El auxiliar comprueba además todas las etiquetas históricas:

```bash
python -B /c/github/CIERRE_LABORATORIO_08_v1.0/GESTIONAR_CIERRE_08.py registrar --repositorio . --salida trabajo/cierre_lab08_windows_01
codigo_cierre08=$?
printf 'Codigo del registro final: %s\n' "$codigo_cierre08"
```

Con APROBADO y código 0, generará:

- `trabajo/cierre_lab08_windows_01/RESULTADO_CIERRE.json`.
- Los estados observados `ESTADO_DEL_LIBRO_v1.7.4.md` y `ESTADO_REPOSITORIO_v1.6.4.md` dentro de esa carpeta.
- `trabajo/cierre_lab08_windows_01/SHA256_ARCHIVOS.json`.
- `trabajo/EVIDENCIA_CIERRE_LAB08_WINDOWS_01.zip`.

Adjunta el ZIP final y la salida del push, de la consulta remota y del auxiliar. Se revisarán como evidencia nueva. El comprobante posterior permanece fuera del commit que acredita; no hace falta otro commit ni mover las etiquetas para incluirlo.

## Límites y reanudación

El paquete fue preparado y probado en Linux; la ejecución funcional Windows previa procede del autor. Las fases que ejecutes ahora producirán su propia evidencia de Windows. El auxiliar no convierte resultados históricos en nuevas pruebas y no declara publicación hasta comprobar las referencias reales.

Si una carpeta o un archivo de registro ya existe, se conserva. No lo borres para repetir un paso. Un fallo anterior a crear la carpeta permite repetir tras resolver la causa; un intento parcialmente registrado requiere revisar su estado y, cuando corresponda, usar otra salida sin perder el anterior. Las tres fases deben referirse a la misma preparación válida.

Los capítulos 1–8 siguen pendientes de revisión editorial. Este cierre no incluye el capítulo 9.
