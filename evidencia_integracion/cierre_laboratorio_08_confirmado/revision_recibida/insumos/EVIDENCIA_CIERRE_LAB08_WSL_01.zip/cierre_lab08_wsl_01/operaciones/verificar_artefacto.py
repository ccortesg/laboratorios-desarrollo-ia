"""Verifica exhaustivamente el ZIP final, su manifiesto y los bytes guardados."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import json
from zipfile import ZipFile

base = Path(__file__).resolve().parent
repo = base.parents[1]
salida = repo / 'trabajo/cierre_lab08_wsl_01'
archivo = repo / 'trabajo/EVIDENCIA_CIERRE_LAB08_WSL_01.zip'
prefijo = salida.name + '/'

def sha(datos):
    return hashlib.sha256(datos).hexdigest()

manifiesto = json.loads((salida / 'SHA256_ARCHIVOS.json').read_bytes())
reales = {p.relative_to(salida).as_posix(): p for p in salida.rglob('*') if p.is_file()}
assert not any(p.is_symlink() for p in salida.rglob('*'))
assert set(reales) == set(manifiesto) | {'SHA256_ARCHIVOS.json'}
for nombre, digest in manifiesto.items():
    assert sha(reales[nombre].read_bytes()) == digest, nombre
with ZipFile(archivo) as z:
    nombres = z.namelist()
    assert len(nombres) == len(set(nombres))
    assert all(n.startswith(prefijo) and not PurePosixPath(n).is_absolute()
               and '..' not in PurePosixPath(n).parts for n in nombres)
    assert set(nombres) == {prefijo + n for n in reales}
    assert z.testzip() is None
    for nombre, ruta in reales.items():
        assert z.read(prefijo + nombre) == ruta.read_bytes(), nombre
    assert json.loads(z.read(prefijo + 'SHA256_ARCHIVOS.json')) == manifiesto
resultado = json.loads((salida / 'RESULTADO_CIERRE.json').read_bytes())
assert resultado['estado'] == 'APROBADO'
assert resultado['identidad_git']['rama'] == 'main'
assert resultado['sistema_observado'] == 'Linux'
for p in (salida / 'operaciones').glob('*/comando.json'):
    r = json.loads(p.read_bytes())
    for flujo, digest in r.get('sha256_finales', {}).items():
        assert sha((p.parent / (flujo + '.txt')).read_bytes()) == digest, str(p)
print(json.dumps({'estado': 'APROBADO', 'fecha_utc': datetime.now(timezone.utc).isoformat(),
                  'zip': str(archivo), 'sha256_zip': sha(archivo.read_bytes()),
                  'archivos_zip': len(reales), 'archivos_declarados_manifiesto': len(manifiesto),
                  'cobertura_completa': True, 'bytes_zip_iguales_a_guardados': True,
                  'identidad_git': resultado['identidad_git'],
                  'referencias_remotas': resultado['consulta_remota'],
                  'estados_generados': ['ESTADO_DEL_LIBRO_v1.7.4.md', 'ESTADO_REPOSITORIO_v1.6.4.md']},
                 ensure_ascii=False, indent=2))
