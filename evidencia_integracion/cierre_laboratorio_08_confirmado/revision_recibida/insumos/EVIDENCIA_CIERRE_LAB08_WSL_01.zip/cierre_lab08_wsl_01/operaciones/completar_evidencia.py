"""Conserva capturas reales previas al registro; no modifica referencias Git."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import shutil

base = Path(__file__).resolve().parent
repo = base.parents[1]
salida = repo / 'trabajo/cierre_lab08_wsl_01'
paquete = repo.parent / 'CIERRE_LABORATORIO_08_v1.0'
antes = json.loads((salida / 'antes.json').read_bytes())
despues = json.loads((base / '23_referencias_publicadas/stdout.txt').read_bytes())
push = json.loads((base / '22_push_atomico/comando.json').read_bytes())
assert despues['estado'] == 'APROBADO' and push['codigo_salida'] == 0
esperado = ['git', 'push', '--atomic', '--no-follow-tags', 'origin',
            'refs/heads/main:refs/heads/main',
            'refs/tags/lab-08-v1.0:refs/tags/lab-08-v1.0',
            'refs/tags/repositorio-v1.4:refs/tags/repositorio-v1.4']
assert push['comando'] == esperado
ref_antes = antes['remoto']['referencias']
ref_despues = despues['referencias_remotas']
historicas = {r: h for r, h in ref_antes.items() if r.startswith('refs/tags/')}
assert all(ref_despues.get(r) == h for r, h in historicas.items())
assert set(ref_despues) - set(ref_antes) == {'refs/tags/lab-08-v1.0', 'refs/tags/repositorio-v1.4'}

def guardar(nombre, datos):
    with (salida / nombre).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(datos, f, ensure_ascii=False, indent=2); f.write('\n')

guardar('REFERENCIAS_ANTES_Y_DESPUES.json', {
    'estado': 'APROBADO', 'antes': antes['remoto'],
    'despues': {'fecha_utc': despues['fecha_utc'], 'referencias': ref_despues},
    'etiquetas_historicas_conservadas': len(historicas),
    'commit_publicado': despues['head'], 'arbol': despues['arbol'],
    'push_atomico': push, 'comprobacion_ascendencia': 'APROBADO en la captura 23.'})
registros = []
for p in sorted(base.glob('*/comando.json')):
    r = json.loads(p.read_bytes())
    registros.append({'captura': p.parent.name, 'codigo_salida': r['codigo_salida'],
                      'estado': 'APROBADO' if r['codigo_salida'] == 0 else 'FALLIDO',
                      'comando': r['comando']})
guardar('RESUMEN_OPERACIONES.json', {
    'registros': registros,
    'incidencia_resuelta': '06_refrescar_estadisticas fallo por index.lock mientras una inspeccion Git anterior refrescaba su cache. Se conservo la captura. Tras terminar ese proceso, 07_refrescar_estadisticas_reintento aprobo. No se borro el lock ni se descartaron archivos.',
    'bloqueos_pendientes': [],
    'funcional_nuevo': 'NO EJECUTADO: se conserva la ejecucion Windows del autor; el cotejo acredita codigo identico.',
    'pruebas_recolector_wsl': {'estado': 'APROBADO', 'pruebas': 8, 'captura': '04_pruebas_recolector'}})
fecha = datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=-7))).isoformat()
nota = f'''# Cierre real desde WSL/Linux

Fecha de documentacion: {fecha} (UTC-07:00).

Checkout existente: /mnt/c/github/laboratorios-desarrollo-ia, equivalente a C:\\github\\laboratorios-desarrollo-ia. Se uso su unica copia de trabajo, sin clon ni worktree nuevos. La rama inicial fue integracion/laboratorio-08; se conserva junto con main en el commit {despues['head']}, arbol {despues['arbol']}.

Las operaciones se ejecutaron desde bash en WSL2/Linux con Git 2.34.1. Python 3.10.12 ejecuto solamente los auxiliares documentales y las ocho pruebas del recolector. No se ejecuto la aplicacion ni se instalo su entorno Python 3.11+ o dependencias de navegador. El Windows funcional previo del autor (Python 3.11.9 y demas versiones de su auditoria) es una ejecucion distinta, conservada sin reinterpretarla como una prueba de esta sesion.

El ajuste local core.filemode=true -> false adapta Git al montaje NTFS que presenta los archivos 100644 como ejecutables. No altera bytes ni modos del indice; las fases cotejan los modos de los arboles Git y los SHA-256 de blobs y archivos. No se cambiaron identidad, hooks, configuracion de origin, auxiliares del paquete ni manifiestos entregados.

Las fases preparar y comprobar aprobaron usando la misma carpeta cierre_lab08_wsl_01; registrar se ejecutara a continuacion sobre esa preparacion. La adicion documental abarca exactamente 25 rutas y conserva 1486 archivos protegidos. El indice completo revisado incluia las 549 rutas de la integracion ya preparada y el incremento documental. Se confirmo sin git add global ni archivos de trabajo.

Se conservaron main local y origin/main mediante los merges de la guia: ambos ya estaban contenidos. Main avanzo mediante --ff-only. El push real uso exactamente el alcance autorizado con --atomic y --no-follow-tags, codigo 0. La captura operaciones/22_push_atomico/ conserva argumentos, fecha, stdout, stderr y hashes. La captura 23 consulta main y todas las etiquetas despues de publicar y verifica historia, estado limpio, las dos etiquetas nuevas y las once historicas. REFERENCIAS_ANTES_Y_DESPUES.json conserva las respuestas completas.

El auxiliar original contiene menciones fijas a Git Bash y a una salida aportada por el autor. En este cierre la prueba del comando de subida es la captura real de Git Linux desde WSL indicada arriba. No se modifico el auxiliar ni esas menciones; sistema_observado=Linux y los registros de entorno identifican la ejecucion efectiva.

Las cifras funcionales de 65 baterias, 583 ejecuciones, 571 aprobaciones y 12 fallos didacticos proceden de la ejecucion Windows auditada del autor. Se conservan 48 NO EJECUTADO y 10 ausentes aparte, 102/102 huellas del conjunto y 10/10 auxiliares. Sus pruebas 8/4/9 estan separadas. Esta sesion anade solo las ocho pruebas del recolector de WSL y las comprobaciones documentales/Git, sin sumarlas a las 583 ejecuciones.

La captura 06 conserva un fallo de infraestructura temporal del refresco del indice. El reintento 07 aprobo despues de finalizar la inspeccion anterior. No equivale a un fallo didactico y no deja un bloqueo pendiente.

Los capitulos 1-8 siguen pendientes de revision editorial del autor; no se modificaron manuscritos ni se redacto el capitulo 9. Los comprobantes posteriores, estados 1.7.4/1.6.4, manifiesto y ZIP permanecen fuera del commit publicado. No se creara otro commit ni se moveran etiquetas para incluirlos.

Las capturas se sanearon antes de guardar y calcular las huellas finales; las capturas desde 08 conservan tambien las huellas del flujo capturado antes del saneamiento. Los registros iniciales conservan sus bytes guardados y no se reescriben para anadir supuestas huellas originales. El manifiesto final cubrira todos los archivos presentes, con exclusion de si mismo.
'''
with (salida / 'NOTAS_ENTORNO_Y_ALCANCE.md').open('x', encoding='utf-8', newline='\n') as f:
    f.write(nota)
shutil.copytree(base, salida / 'operaciones')
shutil.copytree(paquete, salida / 'paquete_original')
copiados = {p.relative_to(paquete).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in paquete.rglob('*') if p.is_file()}
assert all(hashlib.sha256((salida / 'paquete_original' / n).read_bytes()).hexdigest() == h
           for n, h in copiados.items())
guardar('COPIA_PAQUETE_ORIGINAL.json', {'estado': 'APROBADO', 'archivos': copiados})
print('APROBADO: capturas reales de commit, integracion y push, referencias, notas y paquete original incorporados antes de registrar.')
