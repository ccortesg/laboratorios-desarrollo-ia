"""Cotejo del indice que se va a confirmar, sin preparar archivos."""
from pathlib import Path
import json
import subprocess

repo = Path(__file__).resolve().parents[2]
config = json.loads((repo.parent / 'CIERRE_LABORATORIO_08_v1.0/BASE_CIERRE.json').read_bytes())
comandos = []

def git(*args):
    p = subprocess.run(['git', *args], cwd=repo, capture_output=True)
    salida = p.stdout.decode('utf-8')
    comandos.append({'comando': ['git', *args], 'codigo_salida': p.returncode,
                     'stdout': salida, 'stderr': p.stderr.decode('utf-8')})
    assert p.returncode == 0, args
    return salida.strip()

rama = git('branch', '--show-current')
head = git('rev-parse', 'HEAD')
main = git('rev-parse', 'main')
arbol = git('write-tree')
assert rama == 'integracion/laboratorio-08'
assert head == config['base_commit']
assert arbol == config['arbol_documental']
assert not git('diff', '--cached', '--check')
assert not git('diff', '--name-only')
assert not git('ls-files', '--others', '--exclude-standard')
diff = git('diff', '--cached', '--name-status', '--no-renames', config['arbol_verificado'], '--')
cambios = [linea.split('\t', 1) for linea in diff.splitlines()]
assert {n for _, n in cambios} == set(config['archivos_documentales'])
assert all(estado in {'A', 'M'} for estado, _ in cambios)
todo = git('diff', '--cached', '--name-status', '--no-renames', 'HEAD', '--')
assert not any(n.startswith('trabajo/') for _, n in (linea.split('\t', 1) for linea in todo.splitlines()))
print(json.dumps({'estado': 'APROBADO', 'rama': rama, 'head': head, 'main': main,
                  'arbol_indice': arbol, 'rutas_documentales_exactas': len(cambios),
                  'rutas_preparadas_desde_head': len(todo.splitlines()),
                  'comandos': comandos}, ensure_ascii=False, indent=2))
