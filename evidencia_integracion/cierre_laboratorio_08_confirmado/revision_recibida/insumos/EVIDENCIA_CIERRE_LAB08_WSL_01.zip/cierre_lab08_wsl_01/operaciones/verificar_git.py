"""Comprueba historia, contenido y referencias observadas del cierre."""
from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess
import sys

repo = Path(__file__).resolve().parents[2]
config = json.loads((repo.parent / 'CIERRE_LABORATORIO_08_v1.0/BASE_CIERRE.json').read_bytes())
antes = json.loads((repo / 'trabajo/cierre_lab08_wsl_01/antes.json').read_bytes())
fase = sys.argv[1]
comandos = []

def git(*args):
    p = subprocess.run(['git', *args], cwd=repo, capture_output=True)
    salida = p.stdout.decode('utf-8')
    comandos.append({'comando': ['git', *args], 'codigo_salida': p.returncode,
                     'stdout': salida, 'stderr': p.stderr.decode('utf-8')})
    assert p.returncode == 0, args
    return salida.strip()

rama = git('branch', '--show-current')
head = git('rev-parse', 'HEAD')
arbol = git('rev-parse', 'HEAD^{tree}')
indice = git('write-tree')
main = git('rev-parse', 'main')
origin_main = git('rev-parse', 'origin/main')
assert arbol == indice == config['arbol_documental']
assert not git('diff', '--quiet', config['arbol_documental'], 'HEAD', '--')
assert not git('status', '--porcelain=v1')
for ref in [config['base_commit'], antes['identidad']['main'],
            antes['remoto']['referencias']['refs/heads/main'], main, origin_main]:
    git('merge-base', '--is-ancestor', ref, head)
etiquetas = dict(line.split('\t', 1)[::-1] for line in
                 git('for-each-ref', '--format=%(objectname)%09%(refname)', 'refs/tags').splitlines())
for ref, digest in antes['identidad']['etiquetas'].items():
    assert etiquetas[ref] == digest
remoto = None
if fase == 'publicado':
    assert rama == 'main' and main == head
    remoto = dict(line.split('\t', 1)[::-1] for line in
                  git('ls-remote', '--refs', 'origin', 'refs/heads/main', 'refs/tags/*').splitlines())
    assert remoto['refs/heads/main'] == head
    for nombre in config['etiquetas_previstas']:
        ref = 'refs/tags/' + nombre
        assert remoto[ref] == etiquetas[ref] == git('rev-parse', ref + '^{commit}') == head
    for ref, digest in antes['remoto']['referencias'].items():
        if ref.startswith('refs/tags/'):
            assert remoto[ref] == digest
else:
    assert rama == 'integracion/laboratorio-08'
print(json.dumps({'estado': 'APROBADO', 'fase': fase,
                  'fecha_utc': datetime.now(timezone.utc).isoformat(),
                  'rama': rama, 'head': head, 'arbol': arbol, 'indice': indice,
                  'main': main, 'origin_main': origin_main, 'etiquetas_locales': etiquetas,
                  'referencias_remotas': remoto, 'comandos': comandos},
                 ensure_ascii=False, indent=2))
