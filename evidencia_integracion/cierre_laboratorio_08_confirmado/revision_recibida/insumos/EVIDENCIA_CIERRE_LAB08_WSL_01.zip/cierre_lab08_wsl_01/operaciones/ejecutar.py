"""Registro de operaciones de esta sesion WSL; no altera el auxiliar entregado."""
from pathlib import Path
from datetime import datetime, timezone
import json
import hashlib
import os
import re
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
PAQUETE = REPO.parent / 'CIERRE_LABORATORIO_08_v1.0'

def sanear(texto):
    for ruta, alias in [(str(REPO), '<REPOSITORIO>'), (str(PAQUETE), '<PAQUETE>')]:
        texto = texto.replace(ruta, alias)
    texto = re.sub(r'/home/[^/\s]+', '/home/<USUARIO>', texto)
    texto = re.sub(r'/mnt/c/Users/[^/\s]+', '/mnt/c/Users/<USUARIO>', texto)
    texto = re.sub(r'https://[^/\s:@]+:[^/\s@]+@', 'https://<CREDENCIAL>@', texto)
    texto = re.sub(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', '<CORREO>', texto)
    return texto

def main():
    etiqueta, cwd, *args = sys.argv[1:]
    destino = BASE / etiqueta
    destino.mkdir(exist_ok=False)
    env = dict(os.environ, GIT_TERMINAL_PROMPT='0', GIT_PAGER='cat',
               GIT_MERGE_AUTOEDIT='no', PYTHONDONTWRITEBYTECODE='1',
               PYTHONIOENCODING='utf-8')
    # El montaje Windows presenta los archivos 100644 como ejecutables en WSL.
    # La opcion se limita al proceso; el indice y la configuracion se conservan.
    count = int(env.get('GIT_CONFIG_COUNT', '0'))
    env.update({'GIT_CONFIG_COUNT': str(count + 1),
                'GIT_CONFIG_KEY_' + str(count): 'core.filemode',
                'GIT_CONFIG_VALUE_' + str(count): 'false'})
    inicio = datetime.now(timezone.utc).isoformat()
    try:
        proc = subprocess.run(args, cwd=cwd, env=env, capture_output=True, timeout=240)
        code, out, err = proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired as e:
        code, out, err = 124, e.stdout or b'', (e.stderr or b'') + b'\nTIMEOUT 240s\n'
    capturadas = {'stdout': hashlib.sha256(out).hexdigest(), 'stderr': hashlib.sha256(err).hexdigest()}
    out, err = [sanear(v.decode('utf-8', errors='replace')) for v in [out, err]]
    for nombre, contenido in [('stdout.txt', out), ('stderr.txt', err)]:
        with (destino / nombre).open('x', encoding='utf-8', newline='\n') as f:
            f.write(contenido)
    dato = {'inicio_utc': inicio, 'fin_utc': datetime.now(timezone.utc).isoformat(),
            'entorno': 'WSL2/Linux; bash; Git Linux',
            'cwd': sanear(cwd), 'comando': [sanear(v) for v in args],
            'codigo_salida': code, 'stdout': 'stdout.txt', 'stderr': 'stderr.txt',
            'sha256_capturados': capturadas,
            'sha256_finales': {'stdout': hashlib.sha256(out.encode('utf-8')).hexdigest(),
                               'stderr': hashlib.sha256(err.encode('utf-8')).hexdigest()},
            'opcion_git_por_proceso': {'core.filemode': False},
            'saneamiento': 'Alias de rutas personales, correos y credenciales en URL antes de guardar.'}
    with (destino / 'comando.json').open('x', encoding='utf-8', newline='\n') as f:
        json.dump(dato, f, ensure_ascii=False, indent=2); f.write('\n')
    print(json.dumps(dato, ensure_ascii=False))
    print(out[:6000], end=''); print(err[:3000], end='', file=sys.stderr)
    return code

if __name__ == '__main__':
    raise SystemExit(main())
