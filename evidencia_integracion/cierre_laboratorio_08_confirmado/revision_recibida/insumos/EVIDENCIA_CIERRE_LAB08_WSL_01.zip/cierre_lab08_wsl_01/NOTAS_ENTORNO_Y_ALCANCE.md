# Cierre real desde WSL/Linux

Fecha de documentacion: 2026-11-01T13:40:25.470198-07:00 (UTC-07:00).

Checkout existente: /mnt/c/github/laboratorios-desarrollo-ia, equivalente a C:\github\laboratorios-desarrollo-ia. Se uso su unica copia de trabajo, sin clon ni worktree nuevos. La rama inicial fue integracion/laboratorio-08; se conserva junto con main en el commit 9212ee99b88f70f0b289837b88d6bbf34da91a52, arbol d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0.

Las operaciones se ejecutaron desde bash en WSL2/Linux con Git 2.34.1. Python 3.10.12 ejecuto solamente los auxiliares documentales y las ocho pruebas del recolector. No se ejecuto la aplicacion ni se instalo su entorno Python 3.11+ o dependencias de navegador. El Windows funcional previo del autor (Python 3.11.9 y demas versiones de su auditoria) es una ejecucion distinta, conservada sin reinterpretarla como una prueba de esta sesion.

El ajuste local core.filemode=true -> false adapta Git al montaje NTFS que presenta los archivos 100644 como ejecutables. No altera bytes ni modos del indice; las fases cotejan los modos de los arboles Git y los SHA-256 de blobs y archivos. No se cambiaron identidad, hooks, configuracion de origin, auxiliares del paquete ni manifiestos entregados.

Las fases preparar y comprobar aprobaron usando la misma carpeta cierre_lab08_wsl_01; registrar se ejecutara a continuacion sobre esa preparacion. La adicion documental abarca exactamente 25 rutas y conserva 1486 archivos protegidos. El indice completo revisado incluia las 549 rutas de la integracion ya preparada y el incremento documental. Se confirmo sin git add global ni archivos de trabajo.

Se conservaron main local y origin/main mediante los merges de la guia: ambos ya estaban contenidos. Main avanzo mediante --ff-only. El push real uso exactamente el alcance autorizado con --atomic y --no-follow-tags, codigo 0. La captura operaciones/22_push_atomico/ conserva argumentos, fecha, stdout, stderr y hashes. La captura 23 consulta main y todas las etiquetas despues de publicar y verifica historia, estado limpio, las dos etiquetas nuevas y las once historicas. REFERENCIAS_ANTES_Y_DESPUES.json conserva las respuestas completas.

El auxiliar original contiene menciones fijas a Git Bash y a una salida aportada por el autor. En este cierre la prueba del comando de subida es la captura real de Git Linux desde WSL indicada arriba. No se modifico el auxiliar ni esas menciones; sistema_observado=Linux y los registros de entorno identifican la ejecucion efectiva.

Las cifras funcionales de 65 baterias, 583 ejecuciones, 571 aprobaciones y 12 fallos didacticos proceden de la ejecucion Windows auditada del autor. Se conservan 48 NO EJECUTADO y 10 ausentes aparte, 102/102 huellas del conjunto y 10/10 auxiliares. Sus pruebas 8/4/9 estan separadas. Esta sesion anade solo las ocho pruebas del recolector de WSL y las comprobaciones documentales/Git, sin sumarlas a las 583 ejecuciones.

La captura 06 conserva un fallo de infraestructura temporal del refresco del indice. El reintento 07 aprobo despues de finalizar la inspeccion anterior. No equivale a un fallo didactico y no deja un bloqueo pendiente.

Los capitulos 1-8 siguen pendientes de revision editorial del autor; no se modificaron manuscritos ni se redacto el capitulo 9. Los comprobantes posteriores, estados 1.7.4/1.6.4, manifiesto y ZIP permanecen fuera del commit publicado. No se creara otro commit ni se moveran etiquetas para incluirlos.

Las capturas se sanearon antes de guardar y calcular las huellas finales; las capturas desde 08 conservan tambien las huellas del flujo capturado antes del saneamiento. Los registros iniciales conservan sus bytes guardados y no se reescriben para anadir supuestas huellas originales. El manifiesto final cubrira todos los archivos presentes, con exclusion de si mismo.
