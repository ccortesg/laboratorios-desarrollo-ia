from pathlib import Path
import json, shutil
from control import ROOT, REPO, save, sha, utc
validated=json.loads((ROOT/'VALIDACION_INSUMOS.json').read_text())
assert validated['estado']=='APROBADO'
review=REPO.parent/'REVISION_LABORATORIO_09_WSL_v1.0'
dest=REPO/'evidencia_integracion/revision_laboratorio_09_wsl'
assert not dest.exists()
dest.mkdir()
shutil.copytree(review,dest/'revision_recibida')
outer=ROOT/'insumos/REVISION_LABORATORIO_09_WSL_v1.0.zip'
shutil.copy2(outer,dest/outer.name)
paths=[]
for name in ['ESTADO_DEL_LIBRO_v1.8.1.md','ESTADO_REPOSITORIO_v1.7.1.md']:
    p=REPO/'docs/estados'/name
    assert not p.exists()
    shutil.copy2(review/name,p)
    assert p.read_bytes()==(review/name).read_bytes()
    paths.append(p.relative_to(REPO).as_posix())
shared='''La base es `9212ee99b88f70f0b289837b88d6bbf34da91a52`, árbol `d7cc2ce8b1502daa6c53c14f2aa1c8fb6984aaf0`. El índice funcional auditado y cotejado al iniciar este cierre es `251105483bc5bef040c57dc3a036d5bc3a7e0da0`: 771 rutas preparadas y 2.273 archivos idénticos en disco. Los documentos del cierre producen un árbol distinto, que se registrará fuera del commit que acredita.

La revisión recibida está incorporada en `evidencia_integracion/revision_laboratorio_09_wsl/`, con su paquete original, auditorías y evidencia WSL exacta. El SHA-256 del ZIP de revisión es `3309df01455ce38f8c0e29ced072ea63fa33c788ef1d240f24336714bce64eaf`; el de la evidencia funcional es `6aaeb6ce9e0cf781239499fae2f57bb147b5b2b07b7a20d5cfbd5d61a4ffb239`.

La evidencia WSL anterior acredita 92 baterías y 805 ejecuciones: 781 APROBADO, 24 FALLIDO didácticos exactos, cero bloqueos y cero errores de ejecución; 48 NO EJECUTADO y diez ausentes aparte. Solución 9: 74/74. La infraestructura 8/9/4 se conserva separada. Este cierre no repite las 805 ejecuciones: vuelve a comprobar todas las huellas declaradas, 210/210, y ejecuta las ocho pruebas del recolector con Python 3.12.16 y SQLite 3.53.1 en WSL2; resultado APROBADO, salida 0.

El autor invocó expresamente el encargo de cierre y autorizó incorporar documentos y evidencia, crear el commit, integrar en main conservando avances y publicar únicamente main, `lab-09-v1.0` y `repositorio-v1.5`. La consulta inicial conserva las trece etiquetas históricas y main en la base. El parche no se reaplica. El cierre está preparado; la publicación y sus referencias finales se acreditarán con comprobantes posteriores fuera del commit, bajo una carpeta nueva de `trabajo/`. Este estado previo no afirma una publicación ya realizada.

El maestro editorial 1.0 y los manuscritos permanecen sin cambios. Los capítulos 1–9 siguen pendientes de revisión editorial del autor. No se redacta el capítulo 10. Windows nativo, CI remota, producción y nuevas interacciones con Copilot o Grok Build están NO EJECUTADO en este cierre. Las dos capturas originales ausentes del ZIP anterior no se reconstruyen; sus bytes finales recibidos sí están verificados.
'''
for kind,version,previous in [('LIBRO','1.8.2','1.8.1'),('REPOSITORIO','1.7.2','1.7.1')]:
    name='ESTADO_'+('DEL_LIBRO' if kind=='LIBRO' else 'REPOSITORIO')+'_v'+version+'.md'
    p=REPO/'docs/estados'/name
    assert not p.exists()
    p.write_text('# Estado '+('del libro' if kind=='LIBRO' else 'operativo del repositorio')+' · cierre del laboratorio 9 preparado\n\n**Versión:** '+version+'. **Fecha:** 1 de noviembre de 2026. **Estado:** cierre preparado, publicación pendiente. **Antecedente exacto conservado:** '+previous+'.\n\n'+shared,encoding='utf-8')
    paths.append(p.relative_to(REPO).as_posix())
(dest/'README.md').write_text('''# Revisión WSL del laboratorio 9 incorporada

El informe y los estados 1.8.1/1.7.1 recibidos se conservan exactos en [revision_recibida/](revision_recibida/LEEME.md). El paquete original se conserva junto a esa extracción. Su evidencia original está en [el ZIP recibido](revision_recibida/recibido/EVIDENCIA_LABORATORIO_09_WSL_v1.0.zip). No hay paquetes que se contengan a sí mismos.

La auditoría anterior aprobó la preparación funcional sobre el árbol `251105483bc5bef040c57dc3a036d5bc3a7e0da0`. La incorporación sólo añade documentación y evidencia: no corrige ni vuelve a aplicar la integración. Los estados de preparación son [libro 1.8.2](../../docs/estados/ESTADO_DEL_LIBRO_v1.8.2.md) y [repositorio 1.7.2](../../docs/estados/ESTADO_REPOSITORIO_v1.7.2.md), con publicación pendiente.

`INCORPORACION.json` identifica la recepción y `SHA256SUMS` cubre todos los archivos de esta carpeta excepto el propio manifiesto. El manifiesto original de `revision_recibida/` sigue intacto y se verifica con su `VERIFICAR_PAQUETE.py`.

Las ocho pruebas nuevas del recolector y la comprobación de huellas de este cierre se documentan fuera del commit que acreditan, en `trabajo/cierre_lab09_wsl_20261101T231144Z/`. Las 805 ejecuciones son evidencia anterior auditada; no se presentan como nueva ejecución de este cierre. El comprobante de publicación, si queda confirmada, y los estados posteriores 1.8.3/1.7.3 se entregan fuera de este commit.

Las evidencias anteriores conservan sus bytes y estados, incluidos los intentos fallidos o bloqueados y su posterior resolución. Capítulos 1–9 pendientes de revisión editorial; capítulo 10 fuera de alcance.
''',encoding='utf-8')
inc={'estado':'APROBADO','fecha_utc':utc(),'arbol_funcional_auditado':validated['arbol_funcional'],'revision_original':validated['revision'],'evidencia_original':validated['evidencia'],'archivos_revision':[{'archivo':p.relative_to(review).as_posix(),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(review.rglob('*')) if p.is_file()],'estados_recibidos_exactos':['docs/estados/ESTADO_DEL_LIBRO_v1.8.1.md','docs/estados/ESTADO_REPOSITORIO_v1.7.1.md'],'estados_preparacion':paths[2:],'publicacion':'Pendiente en este documento previo; comprobar después fuera del commit.','alcance':'Incorporación documental autorizada. Sin nueva ejecución de las 805 pruebas ni modificación funcional.'}
(dest/'INCORPORACION.json').write_text(json.dumps(inc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(dest/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.relative_to(dest).as_posix()+'\n' for p in sorted(dest.rglob('*')) if p.is_file()),encoding='utf-8')
# Actualización operativa de raíz; los antecedentes completos quedan debajo.
p=REPO/'CONTINUIDAD.md';old=p.read_text();p.write_text('''# Continuidad vigente · cierre del laboratorio 9 preparado

**Fecha:** 1 de noviembre de 2026. Estados vigentes de preparación: [libro 1.8.2](docs/estados/ESTADO_DEL_LIBRO_v1.8.2.md) y [repositorio 1.7.2](docs/estados/ESTADO_REPOSITORIO_v1.7.2.md). Incorporan como antecedente exacto la revisión 1.8.1/1.7.1. Maestro editorial 1.0 sin cambios; capítulos 1–9 pendientes de revisión del autor.

La ejecución funcional WSL fue auditada y aprobada sobre `251105483bc5bef040c57dc3a036d5bc3a7e0da0`. El cierre preserva íntegro ese contenido e incorpora [la revisión recibida](evidencia_integracion/revision_laboratorio_09_wsl/README.md). Las 805 ejecuciones y las pruebas 8/9/4 pertenecen a esa sesión anterior. En este cierre se comprobaron los 2.273 archivos de ese árbol, las 210 huellas declaradas y ocho pruebas nuevas del recolector con el runtime aislado; todas aprobaron.

**Operación autorizada vigente:** el autor invocó `PROMPT_CIERRE_LABORATORIO_09_v1.0.md` y autorizó commit, integración en main conservando avances y push atómico de main con únicamente `lab-09-v1.0` y `repositorio-v1.5`. Las restricciones de las preparaciones anteriores describen su momento y no cancelan este encargo expreso. La publicación sigue pendiente en este documento previo; commit, árbol documental y consultas posteriores se registran fuera del commit que acreditan, en `trabajo/cierre_lab09_wsl_20261101T231144Z/`.

No reaplicar el parche, forzar referencias, mover etiquetas históricas ni modificar código, pruebas, datos, distribuciones o evidencias anteriores. Los estados posteriores 1.8.3/1.7.3 y el comprobante confirmado sólo se emitirán según el resultado real. No redactar el capítulo 10.

## Antecedentes íntegros de preparación

El texto siguiente conserva las observaciones y restricciones de sus sesiones; la continuidad vigente es la que encabeza este documento.

'''+old,encoding='utf-8')
p=REPO/'VERSIONES.md';old=p.read_text();p.write_text('''# Versiones vigentes · cierre 1.5 preparado, publicación pendiente

**Fecha:** 1 de noviembre de 2026. Estados documentales [libro 1.8.2](docs/estados/ESTADO_DEL_LIBRO_v1.8.2.md) y [repositorio 1.7.2](docs/estados/ESTADO_REPOSITORIO_v1.7.2.md). La revisión recibida 1.8.1/1.7.1 se conserva exacta. Maestro editorial 1.0; capítulos 1–9 pendientes de revisión editorial.

| Referencia | Situación de preparación |
| --- | --- |
| Trece etiquetas históricas, hasta lab-08-v1.0/repositorio-v1.4 | Identidades conservadas y reconsultadas antes del cierre. |
| LABORATORIO_09_v1.0.zip | Distribución verificada, sin regenerar ni cambiar bytes. |
| lab-09-v1.0 y repositorio-v1.5 | Únicas etiquetas nuevas autorizadas; publicación pendiente de comprobar. |
| Árbol funcional auditado | 251105483bc5bef040c57dc3a036d5bc3a7e0da0; separado del árbol documental de cierre. |

La publicación se realiza como operación posterior mediante el encargo ya invocado. Sus SHA y estados posteriores 1.8.3/1.7.3 se documentan fuera del commit que verifican. Esta preparación no anticipa esos identificadores ni afirma el resultado del push. [Revisión incorporada](evidencia_integracion/revision_laboratorio_09_wsl/README.md).

## Antecedentes íntegros

'''+old,encoding='utf-8')
p=REPO/'README.md';s=p.read_text();s=s.replace('# Laboratorios de desarrollo de software con IA\n','# Laboratorios de desarrollo de software con IA\n\n**Cierre del laboratorio 9 preparado, publicación pendiente:** revisión WSL incorporada; estados [libro 1.8.2](docs/estados/ESTADO_DEL_LIBRO_v1.8.2.md) y [repositorio 1.7.2](docs/estados/ESTADO_REPOSITORIO_v1.7.2.md). Consulta [la revisión](evidencia_integracion/revision_laboratorio_09_wsl/README.md) y la [continuidad vigente](CONTINUIDAD.md). El encargo del autor autoriza el commit y la publicación limitada; el comprobante posterior se entrega fuera del commit que acredita.\n',1)
old='La integración técnica 1.5 del laboratorio 9 queda preparada localmente para revisión. No se creó un commit, no se integró main ni se crearon o movieron etiquetas ni se hizo push. `lab-09-v1.0` y `repositorio-v1.5` son nombres previstos. Consulta `docs/estados/ESTADO_REPOSITORIO_v1.7.md` y el paquete de integración; las versiones documentales y técnicas son independientes. Los capítulos 1–9 siguen pendientes de revisión editorial.'
assert old in s
s=s.replace(old,'La integración técnica 1.5 está auditada en WSL sobre `251105483bc5bef040c57dc3a036d5bc3a7e0da0`. El cierre documental incorpora los estados 1.8.1/1.7.1 exactos y prepara 1.8.2/1.7.2. La publicación autorizada de main y únicamente `lab-09-v1.0`/`repositorio-v1.5` se comprobará después, conservando todas las referencias históricas; sus comprobantes quedarán fuera del commit que acreditan. Las 805 ejecuciones son evidencia anterior: el cierre documental ejecuta las ocho pruebas del recolector y comprueba identidad y huellas. Las versiones documentales y técnicas son independientes; capítulos 1–9 pendientes de revisión editorial.')
p.write_text(s,encoding='utf-8')
p=REPO/'AGENTS.md';s=p.read_text();s=s.replace('El estado editorial de esta preparación es ESTADO_DEL_LIBRO_v1.8.md y el operativo es ESTADO_REPOSITORIO_v1.7.md.','El estado editorial de esta preparación es ESTADO_DEL_LIBRO_v1.8.2.md y el operativo es ESTADO_REPOSITORIO_v1.7.2.md; las revisiones recibidas 1.8.1/1.7.1 se conservan exactas.')
old='La tarea vigente prepara el capítulo y laboratorio 9 localmente. No integrar en main, no crear ni mover etiquetas y no hacer push durante esta preparación. Los nombres lab-09-v1.0 y repositorio-v1.5 sólo están previstos.'
assert old in s
s=s.replace(old,'El autor ha invocado el encargo de cierre del laboratorio 9: autoriza incorporar documentación y evidencia revisadas, crear el commit, integrar en main conservando avances y publicar mediante push atómico sólo main y las etiquetas ligeras nuevas lab-09-v1.0 y repositorio-v1.5. El estado de preparación conserva la publicación pendiente; registra el resultado real y los estados posteriores fuera del commit que acreditan. Conserva las trece etiquetas históricas y cualquier referencia añadida después, sin forzar ni reaplicar el parche.')
p.write_text(s,encoding='utf-8')
p=REPO/'evidencia_integracion/README.md';s=p.read_text();p.write_text(s+'\nLa [revisión WSL del laboratorio 9](revision_laboratorio_09_wsl/README.md) conserva el paquete revisado y la evidencia funcional original exactos. El incremento de cierre es documental; su comprobante de publicación y estados posteriores quedan fuera del commit que acreditan.\n',encoding='utf-8')
p=REPO/'PROCEDENCIA.json';d=json.loads(p.read_text());assert 'cierre_laboratorio_09_preparado' not in d
d['cierre_laboratorio_09_preparado']={'estado':'APROBADO','publicacion':'Pendiente de comprobar después del commit','arbol_funcional_auditado':validated['arbol_funcional'],'revision':'evidencia_integracion/revision_laboratorio_09_wsl/revision_recibida/REVISION_LABORATORIO_09_WSL_v1.0.md','sha256_zip_revision':validated['revision']['sha256'],'sha256_zip_evidencia':validated['evidencia']['sha256'],'estado_libro':'docs/estados/ESTADO_DEL_LIBRO_v1.8.2.md','estado_repositorio':'docs/estados/ESTADO_REPOSITORIO_v1.7.2.md','etiquetas_autorizadas':['lab-09-v1.0','repositorio-v1.5'],'limite':'805 ejecuciones anteriores auditadas; nuevo cierre documental y ocho pruebas del recolector, sin reaplicar parche.'}
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
paths+=['AGENTS.md','CONTINUIDAD.md','VERSIONES.md','README.md','PROCEDENCIA.json','evidencia_integracion/README.md']
paths += [p.relative_to(REPO).as_posix() for p in sorted(dest.rglob('*')) if p.is_file()]
save('RUTAS_DOCUMENTALES_AUTORIZADAS.json',{'rutas':sorted(paths),'fecha_utc':utc()})
print('Incorporación documental creada:',len(paths),'rutas explícitas.')
