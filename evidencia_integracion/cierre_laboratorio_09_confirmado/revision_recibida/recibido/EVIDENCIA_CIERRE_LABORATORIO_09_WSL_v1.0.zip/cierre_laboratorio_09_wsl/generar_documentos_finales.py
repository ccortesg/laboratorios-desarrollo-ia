import json
from pathlib import Path
from control import ROOT,REPO,save,utc
p=json.loads((ROOT/'PUBLICACION_CONFIRMADA.json').read_text());assert p['estado']=='APROBADO'
v=json.loads((ROOT/'VALIDACION_PRECOMMIT.json').read_text())
folder=ROOT/'entrega';folder.mkdir()
for name in ['ESTADO_DEL_LIBRO_v1.8.3.md','ESTADO_REPOSITORIO_v1.7.3.md']:
    assert not (REPO/'docs/estados'/name).exists(),'Investigar versión ya existente'
commit=p['commit'];tree=p['arbol'];time=p['fecha_confirmacion_utc']
common=f'''**Resultado técnico:** APROBADO. Confirmado mediante consultas remotas después del push atómico, el {time}.

| Referencia o contenido | SHA confirmado |
| --- | --- |
| main remoto | `{p['main_remoto_confirmado']}` |
| lab-09-v1.0 | `{commit}` |
| repositorio-v1.5 | `{commit}` |
| Árbol del commit de cierre | `{tree}` |
| Árbol funcional auditado anterior | `{p['arbol_funcional_auditado']}` |
| Commit de base conservado | `{p['base']}` |

Se incorporaron la revisión WSL exacta y los estados recibidos libro 1.8.1/repositorio 1.7.1. Los estados de preparación 1.8.2/1.7.2 permanecen en el commit como fotografía anterior a la publicación. El incremento posterior al árbol funcional consta de 29 rutas documentales; 2.268 archivos anteriores conservan identidad y los 1.502 archivos protegidos mantienen sus hashes. No se reaplicó el parche ni se modificaron código, pruebas, datos, distribuciones o evidencias anteriores.

El commit se creó en `codex/integracion-laboratorio-09`, se integró en main por avance rápido y se publicaron exclusivamente las tres referencias autorizadas, sin forzar. Las trece etiquetas históricas conservan su identidad local y remota; las dos nuevas son ligeras. Main no presentó avances ajenos durante este cierre. El árbol de trabajo terminó limpio, en main. Las consultas acreditan el estado puntual registrado, sin impedir futuros avances legítimos.

Las 805 ejecuciones de 92 baterías son evidencia WSL anterior auditada: 781 APROBADO, 24 FALLIDO didácticos exactos, cero bloqueos y cero errores de ejecución; 48 NO EJECUTADO y diez criterios ausentes aparte. Solución 9: 74/74. La infraestructura histórica 8/9/4 sigue separada. Este cierre no repitió esas 805 ejecuciones. Ejecutó ocho pruebas nuevas del recolector, APROBADO con salida 0, y comprobó todas las huellas declaradas de la evidencia usada: 210/210, derivadas de los registros. Se cotejaron también CRC, cobertura de manifiestos, archivos y referencias Git.

Entorno nuevo observado: Linux/WSL2, Python funcional 3.12.16, SQLite 3.53.1; Python de preparación 3.10.12. Las pruebas funcionales anteriores conservan su atribución WSL; Windows nativo, CI remota, producción y nuevas interacciones Copilot/Grok Build están NO EJECUTADO en este cierre. Los intentos anteriores FALLIDO o BLOQUEADO y sus resoluciones se conservan con sus bytes y estados. Las dos capturas originales ausentes del envío previo no se reconstruyeron; sus bytes finales sí se verificaron.

El maestro editorial 1.0 y los manuscritos no se modificaron. Los capítulos 1–9 continúan pendientes de revisión editorial del autor. No se redactó el capítulo 10.

Este documento se genera después de publicar y permanece fuera del commit que acredita. Su evidencia está en el ZIP de cierre, con manifiesto completo y hashes de bytes finales. El SHA-256 del ZIP se entrega aparte para evitar autorreferencia.
'''
for filename,title,version,previous in [('ESTADO_DEL_LIBRO_v1.8.3.md','Estado del libro · laboratorio 9 publicado','1.8.3','1.8.2'),('ESTADO_REPOSITORIO_v1.7.3.md','Estado operativo · cierre del laboratorio 9 confirmado','1.7.3','1.7.2')]:
    (folder/filename).write_text(f'# {title}\n\n**Versión:** {version}. **Fecha local:** 1 de noviembre de 2026 (Hermosillo). **Antecedente:** {previous}.\n\n'+common,encoding='utf-8')
(folder/'CIERRE_LABORATORIO_09_CONFIRMADO_v1.0.md').write_text('# Cierre del laboratorio 9 confirmado · v1.0\n\n'+common+'\nComprobantes directos: [publicación confirmada](../PUBLICACION_CONFIRMADA.json), [validación previa](../VALIDACION_PRECOMMIT.json), [referencias remotas posteriores](../operaciones/remotas_despues_publicacion.stdout.txt), [push atómico](../operaciones/push_atomico_autorizado.stderr.txt), [pruebas del recolector](../operaciones/recolector.stderr.txt) y [árbol de trabajo final](../operaciones/estado_local_final.stdout.txt).\n',encoding='utf-8')
ops=[]
for f in sorted((ROOT/'operaciones').glob('*.json')):
    d=json.loads(f.read_text())
    if 'comando' in d:
        ops.append({'id':f.stem,'comando':d['comando'],'cwd':d['cwd'],'inicio_utc':d['inicio_utc'],'fin_utc':d['fin_utc'],'codigo_salida':d['codigo_salida'],'estado':d['estado'],'registro':f.relative_to(ROOT).as_posix()})
# Este índice previo omite únicamente su propia operación, aún en curso; el índice final se genera al empaquetar.
save('INDICE_OPERACIONES_PREVIO.json',{'operaciones':ops,'alcance':'Índice de consulta; el registro completo y definitivo de operaciones está en operaciones/comandos.json del envío.'})
rows='\n'.join('| '+o['id']+' | '+str(o['codigo_salida'])+' | '+o['estado']+' |' for o in ops)
report=f'''# Informe de cierre del laboratorio 9 · WSL · v1.0

{common}

## Qué cambió y qué se ejecutó

Se mantuvo el índice funcional recibido con sus 771 rutas preparadas. Se verificaron el ZIP de revisión (SHA-256 `3309df01455ce38f8c0e29ced072ea63fa33c788ef1d240f24336714bce64eaf`, 16 archivos extraídos) y el ZIP funcional original (SHA-256 `6aaeb6ce9e0cf781239499fae2f57bb147b5b2b07b7a20d5cfbd5d61a4ffb239`, 453 archivos y 452 entradas del manifiesto). Ambas extracciones coinciden byte a byte con sus contenedores. Los estados 1.8.1/1.7.1 son copias exactas.

El contenido autorizado añadido se identifica por rutas, SHA-256 y tamaños en [VALIDACION_PRECOMMIT.json](../VALIDACION_PRECOMMIT.json). README, continuidad, versiones, AGENTS y procedencia se actualizaron como documentación de preparación. Se conservó íntegro el índice histórico de evidencia al resultar suficiente la referencia de raíz; [ajuste de la adición propia](../AJUSTE_DOCUMENTAL.json). Los originales del paquete y las evidencias anteriores no se alteraron.

Antes de añadir documentos se comprobaron los 2.273 archivos del árbol auditado; después, sólo difieren los cinco documentos operativos de raíz autorizados, y se añaden 24 rutas documentales. El recolector y sus ocho pruebas coinciden incluso con la base del laboratorio 8. La comprobación del índice acredita bytes y modos para todo archivo previo que debía conservarse.

Las referencias iniciales, anteriores a commit, anteriores a etiquetas y posteriores al push están en `operaciones/`. Se utilizó `git fetch --no-tags origin`, se comprobó ascendencia, se integró con `git merge --ff-only codex/integracion-laboratorio-09` y se crearon sólo las dos etiquetas ligeras nuevas. La publicación exacta fue:

```bash
git push --atomic --no-follow-tags origin refs/heads/main:refs/heads/main refs/tags/lab-09-v1.0:refs/tags/lab-09-v1.0 refs/tags/repositorio-v1.5:refs/tags/repositorio-v1.5
```

La operación y la reconsulta terminaron con salida 0. El resultado real está en [PUBLICACION_CONFIRMADA.json](../PUBLICACION_CONFIRMADA.json). Los registros de comandos contienen argumentos exactos, directorio mediante alias, inicio/fin UTC, código de salida, stdout/stderr y hashes originales/finales separados. Las capturas originales nuevas se preservan localmente en `trabajo/cierre_lab09_wsl_20261101T231144Z_capturas_originales/`, fuera del ZIP saneado.

## Clasificación

| Alcance | Estado y atribución |
| --- | --- |
| Identidad del árbol auditado, paquetes, manifiestos y 210 huellas anteriores | APROBADO; nueva comprobación de integridad, sin nueva batería funcional. |
| Ocho pruebas del recolector | APROBADO; nueva ejecución del cierre, salida 0. |
| 805 ejecuciones funcionales y pruebas 8/9/4 | APROBADO como evidencia anterior auditada; 24 FALLIDO didácticos conservados. |
| Commit, avance rápido, push atómico y referencias finales | APROBADO; operaciones nuevas efectivamente ejecutadas. |
| Fallos inesperados o bloqueos nuevos pendientes | Ninguno. |
| Repetición funcional, Windows nativo, CI remota, producción y reto opcional | NO EJECUTADO en este cierre. |
| Revisión editorial de capítulos 1–9 | Pendiente del autor; la validación técnica no la acredita. |

## Operaciones y códigos

| Registro | Salida | Estado |
| --- | ---: | --- |
{rows}

El índice definitivo se deriva de todos los JSON realmente capturados al finalizar: [operaciones/comandos.json](../operaciones/comandos.json). Los resultados generados después de esta tabla también se incluyen allí. El manifiesto final se calcula después del saneamiento, con cobertura completa excepto el propio manifiesto. La verificación posterior del ZIP y su SHA-256 se conservan fuera del archivo. Ningún comprobante posterior se añadió al commit publicado.
'''
(folder/'INFORME_CIERRE_LABORATORIO_09_WSL_v1.0.md').write_text(report,encoding='utf-8')
print('Documentos posteriores creados fuera del commit publicado:',commit)
