import json
from control import ROOT,REPO,save,git,utc
c=json.loads((ROOT/'COMMIT_CIERRE.json').read_text());assert c['estado']=='APROBADO'
commit=c['commit'];historical=json.loads((ROOT/'REFERENCIAS_HISTORICAS.json').read_text())['etiquetas_historicas']
newnames=['lab-09-v1.0','repositorio-v1.5']
def refs(text):return {l.split()[1]:l.split()[0] for l in text.splitlines()}
def preserved(d):assert all(d.get(k)==v for k,v in historical.items())
assert not git('estado_antes_integracion','status','--porcelain=v1').strip()
git('fetch_antes_integracion','fetch','--no-tags','origin')
remote=refs(git('remotas_antes_integracion','ls-remote','--heads','--tags','origin'));preserved(remote)
git('main_ancestro_cierre','merge-base','--is-ancestor','main',commit)
git('origin_ancestro_cierre','merge-base','--is-ancestor','origin/main',commit)
git('cambiar_a_main','switch','main')
git('integrar_main_avance_rapido','merge','--ff-only','codex/integracion-laboratorio-09')
assert git('identidad_main_integrado','rev-parse','HEAD','HEAD^{tree}').splitlines()==[commit,c['arbol']]
# Reconsulta inmediatamente anterior a crear sólo las etiquetas autorizadas.
git('fetch_prepublicacion','fetch','--no-tags','origin')
remote=refs(git('remotas_prepublicacion','ls-remote','--heads','--tags','origin'));preserved(remote)
local=refs(git('locales_prepublicacion','show-ref'));preserved(local)
git('avance_remoto_prepublicacion','merge-base','--is-ancestor','origin/main',commit)
for name in newnames:
    ref='refs/tags/'+name
    assert remote.get(ref) in (None,commit),(ref,remote.get(ref))
    assert local.get(ref) in (None,commit),(ref,local.get(ref))
    if ref not in local:git('crear_'+name.replace('.','_'),'tag',name,commit)
    assert git('tipo_'+name.replace('.','_'),'cat-file','-t',ref).strip()=='commit'
assert git('main_inmediato_pre_push','rev-parse','main').strip()==commit
push_error=None
try:
    git('push_atomico_autorizado','push','--atomic','--no-follow-tags','origin','refs/heads/main:refs/heads/main','refs/tags/lab-09-v1.0:refs/tags/lab-09-v1.0','refs/tags/repositorio-v1.5:refs/tags/repositorio-v1.5')
except RuntimeError as e:
    push_error=str(e)
# Consultar incluso si el transporte dio una respuesta indeterminada.
remote_after=refs(git('remotas_despues_publicacion','ls-remote','--heads','--tags','origin'));preserved(remote_after)
assert all(remote_after.get('refs/tags/'+name)==commit for name in newnames)
git('fetch_despues_publicacion','fetch','--no-tags','origin')
git('cierre_ancestro_remoto_final','merge-base','--is-ancestor',commit,'origin/main')
local_after=refs(git('locales_despues_publicacion','show-ref'));preserved(local_after)
status=git('estado_local_final','status','--porcelain=v1');assert not status.strip()
identity=git('identidad_local_final','rev-parse','HEAD','HEAD^{tree}','main','origin/main').splitlines()
assert identity[:3]==[commit,c['arbol'],commit]
branches=git('ramas_finales','branch','-v')
result={'estado':'APROBADO','fecha_confirmacion_utc':utc(),'commit':commit,'arbol':c['arbol'],'base':c['base'],'arbol_funcional_auditado':c['arbol_funcional_auditado'],'main_remoto_confirmado':remote_after['refs/heads/main'],'main_remoto_es_commit_publicado':remote_after['refs/heads/main']==commit,'commit_publicado_ancestro_main_remoto':True,'referencias_antes':remote,'referencias_despues':remote_after,'etiquetas_historicas_conservadas':len(historical),'etiquetas_nuevas':{name:remote_after['refs/tags/'+name] for name in newnames},'tipo_etiquetas':'ligeras','push_error':push_error,'estado_local':'Limpio; main integrado por avance rápido','integracion':'Avance rápido; sin adaptación funcional ni descarte de avances','publicacion':'Push atómico de tres referencias explícitas; no se publicaron otras ramas ni etiquetas','repeticion_805':'NO EJECUTADO; documentación y evidencia únicamente','limite':'Consulta puntual; una intervención posterior puede avanzar main sin cambiar las etiquetas del cierre.'}
save('PUBLICACION_CONFIRMADA.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['referencias_antes','referencias_despues']},ensure_ascii=False,indent=2))
