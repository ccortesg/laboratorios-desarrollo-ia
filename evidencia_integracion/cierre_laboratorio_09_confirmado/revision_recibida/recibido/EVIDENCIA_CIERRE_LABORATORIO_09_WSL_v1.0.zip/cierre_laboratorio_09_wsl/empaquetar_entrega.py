import json,hashlib,re,stat,ast,sys
from pathlib import Path,PurePosixPath
from zipfile import ZipFile,ZIP_DEFLATED
from control import ROOT,REPO,save,sha,utc
assert json.loads((ROOT/'VALIDACION_POSTERIOR.json').read_text())['estado']=='APROBADO'
archive=ROOT.parent/'EVIDENCIA_CIERRE_LABORATORIO_09_WSL_v1.0.zip'
assert not archive.exists()
assert not (ROOT/'MANIFIESTO_CIERRE.json').exists()
ops=[];originals=ROOT.with_name(ROOT.name+'_capturas_originales')
for meta in sorted((ROOT/'operaciones').glob('*.json')):
    d=json.loads(meta.read_text())
    if 'capturas' not in d:continue
    r={k:v for k,v in d.items() if k!='capturas'};r['id']=meta.stem
    for flow,item in d['capturas'].items():
        file=ROOT/item['archivo'];data=file.read_bytes();assert sha(data)==item['sha256_final']
        raw=originals/file.name
        assert raw.exists() and sha(raw.read_bytes())==item['sha256_captura_original']
        r[flow]=file.name;r['sha256_'+flow]=item['sha256_final'];r['sha256_'+flow+'_capturado']=item['sha256_captura_original']
    ops.append(r)
assert all(r['estado']=='APROBADO' and r['codigo_salida']==0 for r in ops)
(ROOT/'operaciones/comandos.json').write_text(json.dumps({'registros':ops,'alcance':'Operaciones nuevas del cierre; capturas originales y finales diferenciadas. Los datos funcionales incluidos pertenecen a la sesión anterior auditada.'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sys.path.insert(0,str(REPO/'herramientas'))
from huellas_evidencia import comprobar_huellas
result=comprobar_huellas(ROOT);assert result['estado']=='APROBADO'
save('HUELLAS_FINALES_CIERRE.json',{'fecha_utc':utc(),'resultado':result,'operaciones_nuevas':len(ops),'huellas_operaciones_nuevas':len(ops)*2,'huellas_anteriores_incluidas':result['comprobadas']-len(ops)*2,'alcance':'Recuento derivado de todas las declaraciones, sin contador histórico fijo. No agrega pruebas funcionales.'})
# Validación de enlaces en los documentos posteriores. El índice de operaciones ya existe.
links=0
for p in (ROOT/'entrega').glob('*.md'):
    for target in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)',p.read_text()):
        if '://' in target or target.startswith('#'):continue
        assert (p.parent/target.split('#')[0]).exists(),(p.name,target)
        links+=1
# Revisión de patrones concretos de rutas y secretos, sin publicar capturas originales.
findings=[]
for p in ROOT.rglob('*'):
    assert not p.is_symlink()
    if not p.is_file() or p.suffix.lower()=='.zip':continue
    data=p.read_bytes();text=data.decode('utf-8')
    patterns=[r'/mnt/[a-z]/Users/[A-Za-z0-9_.-]+',r'/home/[A-Za-z0-9_.-]+',r'[A-Za-z]:\\Users\\[A-Za-z0-9_.-]+',r'gh[pousr]_[A-Za-z0-9]{20,}',r'\bsk-proj-[A-Za-z0-9_-]{20,}']
    for pattern in patterns:
        if re.search(pattern,text):findings.append({'archivo':p.relative_to(ROOT).as_posix(),'patron':pattern})
assert not findings,findings
save('REVISION_FINAL_ENTREGA.json',{'estado':'APROBADO','fecha_utc':utc(),'operaciones_nuevas':len(ops),'huellas_todas':result,'enlaces_documentos_posteriores':links,'rutas_personales_secretos_en_patrones':findings,'capturas_originales':'Conservadas y cotejadas fuera del ZIP; sus hashes permanecen como campos separados.','limite':'Búsqueda por patrones y lectura de documentos; no detector universal de identidad semántica.'})
files=sorted(p for p in ROOT.rglob('*') if p.is_file())
manifest={'fecha_utc':utc(),'archivos':[{'archivo':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files],'alcance':'Cobertura completa de la entrega excepto este propio manifiesto; bytes finales saneados. SHA del ZIP y comprobación posterior se entregan fuera del contenedor.'}
save('MANIFIESTO_CIERRE.json',manifest)
with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
    for p in sorted(p for p in ROOT.rglob('*') if p.is_file()):
        z.write(p,'cierre_laboratorio_09_wsl/'+p.relative_to(ROOT).as_posix())
with ZipFile(archive) as z:
    names=z.namelist();assert len(names)==len(set(names));assert z.testzip() is None
    prefix='cierre_laboratorio_09_wsl/'
    m=json.loads(z.read(prefix+'MANIFIESTO_CIERRE.json'));expected={prefix+e['archivo'] for e in m['archivos']}
    assert set(names)==expected|{prefix+'MANIFIESTO_CIERRE.json'}
    for e in m['archivos']:
        data=z.read(prefix+e['archivo']);assert len(data)==e['bytes'] and sha(data)==e['sha256']
    references=0
    for name in names:
        if name.endswith('/comandos.json'):
            for rec in json.loads(z.read(name))['registros']:
                for flow in ['stdout','stderr']:
                    key='sha256_'+flow
                    if flow not in rec and key not in rec:continue
                    target=name.rsplit('/',1)[0]+'/'+rec[flow]
                    assert sha(z.read(target))==rec[key];references+=1
    assert references==result['comprobadas']
digest=sha(archive.read_bytes())
receipt={'estado':'APROBADO','fecha_utc':utc(),'zip':archive.name,'bytes':archive.stat().st_size,'sha256':digest,'crc':'APROBADO','archivos_zip':len(names),'archivos_manifestados':len(m['archivos']),'cobertura':'APROBADO; sólo el manifiesto se excluye a sí mismo','huellas_stdout_stderr_dentro_zip':references,'referencias_remotas':'Consultas exactas guardadas en el ZIP; confirmación posterior al push, sin alterar referencias históricas.'}
check=ROOT.parent/'COMPROBACION_EVIDENCIA_CIERRE_LABORATORIO_09_WSL_v1.0.json';assert not check.exists();check.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha_file=archive.with_suffix('.zip.sha256');assert not sha_file.exists();sha_file.write_text(digest+'  '+archive.name+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
