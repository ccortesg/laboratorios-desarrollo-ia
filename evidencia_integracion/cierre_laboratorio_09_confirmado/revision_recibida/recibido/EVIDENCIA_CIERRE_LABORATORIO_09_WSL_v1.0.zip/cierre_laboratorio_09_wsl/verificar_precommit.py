import json,re,hashlib,subprocess
from pathlib import Path
from control import ROOT,REPO,save,git,sha,utc
original=json.loads((ROOT/'identidad_funcional_inicial.json').read_text())
allowed=json.loads((ROOT/'RUTAS_DOCUMENTALES_FINALES.json').read_text())['rutas']
expected=set(allowed)
audit=original['arbol']
changed=git('rutas_documentales_precommit','diff','--cached','--name-only',audit).splitlines()
assert set(changed)==expected,(set(changed)^expected)
assert not git('sin_preparar_precommit','diff','--name-only').strip()
assert not git('nuevos_precommit','ls-files','--others','--exclude-standard').strip()
# Todas las rutas previas fuera de los cinco documentos de raíz conservan bytes.
rootdocs={'AGENTS.md','README.md','CONTINUIDAD.md','VERSIONES.md','PROCEDENCIA.json'}
protected=json.loads((ROOT/'evidencia_recibida/protegidos_antes.json').read_text())
actual={};changes=[]
for e in original['archivos']:
    path=e['ruta']; digest=sha((REPO/path).read_bytes());actual[path]=digest
    if digest!=e['sha256']:
        assert path in rootdocs,path
        changes.append({'ruta':path,'sha256_anterior':e['sha256'],'sha256_final':digest})
assert {e['ruta'] for e in changes}==rootdocs
for path,digest in protected.items(): assert actual[path]==digest,path
raw=git('inventario_documental_precommit','ls-tree','-r','-z',git('arbol_documental_validado','write-tree').strip())
staged={}
for record in raw.split('\0'):
    if not record:continue
    meta,path=record.split('\t',1);staged[path]=meta.split()
for path in changed:
    data=(REPO/path).read_bytes();oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert staged[path][2]==oid,path
for e in original['archivos']:
    if e['ruta'] not in rootdocs: assert staged[e['ruta']]==[e['modo'],'blob',e['blob']]
# Manifiestos originales e incorporación final, sin tocar evidencias históricas.
folder=REPO/'evidencia_integracion/revision_laboratorio_09_wsl'
entries={}
for line in (folder/'SHA256SUMS').read_text().splitlines():
    digest,path=line.split('  ',1);assert path not in entries;entries[path]=digest
files={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
# Hay un segundo SHA256SUMS original que sí debe quedar cubierto.
files={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file() and p!=folder/'SHA256SUMS'}
assert set(entries)==files
for path,digest in entries.items():assert sha((folder/path).read_bytes())==digest,path
for name in ['ESTADO_DEL_LIBRO_v1.8.1.md','ESTADO_REPOSITORIO_v1.7.1.md']:
    assert (REPO/'docs/estados'/name).read_bytes()==(folder/'revision_recibida'/name).read_bytes()
old=json.loads(subprocess.check_output(['git','show',audit+':PROCEDENCIA.json'],cwd=REPO))
new=json.loads((REPO/'PROCEDENCIA.json').read_text());assert {k:v for k,v in new.items() if k!='cierre_laboratorio_09_preparado'}==old
patterns=[r'/mnt/[a-z]/Users/[^\s"<>]+',r'/home/[^\s"<>]+',r'(?i)[a-z]:\\Users\\[^\s"<>]+',r'gh[pousr]_[A-Za-z0-9]{20,}',r'sk-proj-[A-Za-z0-9_-]+',r'-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----']
findings=[]
for path in changed:
    p=REPO/path
    if p.suffix.lower() in {'.zip'}:continue
    text=p.read_text(encoding='utf-8')
    for pattern in patterns:
        if re.search(pattern,text):findings.append({'ruta':path,'patron':pattern})
assert not findings,findings
# Fuentes de recolector y sus ocho tests preservadas incluso frente a HEAD de la base.
for path in ['herramientas/huellas_evidencia.py','herramientas/pruebas/test_huellas_evidencia.py']:
    assert subprocess.check_output(['git','show','9212ee99b88f70f0b289837b88d6bbf34da91a52:'+path],cwd=REPO)==(REPO/path).read_bytes()
result={'estado':'APROBADO','fecha_utc':utc(),'arbol_funcional_auditado':audit,'arbol_documental':(ROOT/'operaciones/arbol_documental_validado.stdout.txt').read_text().strip(),'rutas_documentales':[{'ruta':p,'sha256':sha((REPO/p).read_bytes()),'bytes':(REPO/p).stat().st_size} for p in changed],'documentos_raiz_modificados':changes,'archivos_funcionales_conservados':len(original['archivos'])-len(changes),'archivos_protegidos_coincidentes':len(protected),'recolector_y_pruebas':'Idénticos a base y árbol auditado','manifiesto_incorporacion':{'declarados':len(entries),'coincidentes':len(entries),'cobertura':'APROBADO'},'confidencialidad':{'estado':'APROBADO','hallazgos':findings,'alcance':'Patrones de rutas personales y secretos en documentos añadidos; paquetes originales exactos previamente revisados.'},'funcionales_nuevas':'NO EJECUTADO: sólo documentos y evidencia; fuentes intactas','recolector_nuevo':'APROBADO: 8 pruebas, salida 0','huellas_evidencia_anterior':'APROBADO: todas las declaradas, sin fijar contador histórico'}
save('VALIDACION_PRECOMMIT.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['rutas_documentales','documentos_raiz_modificados']},ensure_ascii=False,indent=2))
