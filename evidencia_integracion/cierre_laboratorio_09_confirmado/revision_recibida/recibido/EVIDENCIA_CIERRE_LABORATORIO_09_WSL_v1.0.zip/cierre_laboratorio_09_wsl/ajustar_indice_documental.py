from control import ROOT,REPO,save,utc
import json
p=REPO/'evidencia_integracion/README.md'
addition='\nLa [revisión WSL del laboratorio 9](revision_laboratorio_09_wsl/README.md) conserva el paquete revisado y la evidencia funcional original exactos. El incremento de cierre es documental; su comprobante de publicación y estados posteriores quedan fuera del commit que acreditan.\n'
s=p.read_text();assert s.endswith(addition);p.write_text(s[:-len(addition)],encoding='utf-8')
d=json.loads((ROOT/'RUTAS_DOCUMENTALES_AUTORIZADAS.json').read_text());d['rutas'].remove('evidencia_integracion/README.md')
save('RUTAS_DOCUMENTALES_FINALES.json',d)
save('AJUSTE_DOCUMENTAL.json',{'estado':'APROBADO','fecha_utc':utc(),'accion':'Retirada sólo la adición propia al índice README de evidencia, antes de preparar Git.','motivo':'La referencia ya figura en README y continuidad; se preservan íntegros los 1502 archivos protegidos.','rutas':['evidencia_integracion/README.md']})
