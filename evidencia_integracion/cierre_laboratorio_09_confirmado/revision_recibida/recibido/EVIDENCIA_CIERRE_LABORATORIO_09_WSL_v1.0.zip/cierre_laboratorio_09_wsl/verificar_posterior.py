import json,hashlib,re
from pathlib import Path
from control import ROOT,REPO,save,sha,utc
pub=json.loads((ROOT/'PUBLICACION_CONFIRMADA.json').read_text());assert pub['estado']=='APROBADO'
raw=(ROOT/'operaciones/inventario_documental_precommit.stdout.txt').read_text()
count=0
for record in raw.split('\0'):
    if not record:continue
    meta,path=record.split('\t',1);mode,kind,oid=meta.split();data=(REPO/path).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,path
    count+=1
protected=json.loads((ROOT/'evidencia_recibida/protegidos_antes.json').read_text())
for path,digest in protected.items():assert sha((REPO/path).read_bytes())==digest,path
for name in ['ESTADO_DEL_LIBRO_v1.8.3.md','ESTADO_REPOSITORIO_v1.7.3.md','CIERRE_LABORATORIO_09_CONFIRMADO_v1.0.md','INFORME_CIERRE_LABORATORIO_09_WSL_v1.0.md']:
    text=(ROOT/'entrega'/name).read_text();assert pub['commit'] in text and pub['arbol'] in text
    assert not (REPO/'docs/estados'/name).exists()
# Los únicos bytes que se publicaron están en el commit; los comprobantes posteriores son externos.
save('VALIDACION_POSTERIOR.json',{'estado':'APROBADO','fecha_utc':utc(),'commit_publicado':pub['commit'],'arbol_documental':pub['arbol'],'archivos_finales_identicos_a_indice_revisado':count,'archivos_protegidos_coincidentes':len(protected),'documentos_posteriores':'Fuera del commit que acreditan; SHA reales y revisión editorial pendiente conservados.','estado_git_acreditado':'main limpio, consulta posterior guardada en operaciones/estado_local_final.stdout.txt'})
print('APROBADO:',count,'archivos finales idénticos;',len(protected),'protegidos; documentos posteriores externos.')
