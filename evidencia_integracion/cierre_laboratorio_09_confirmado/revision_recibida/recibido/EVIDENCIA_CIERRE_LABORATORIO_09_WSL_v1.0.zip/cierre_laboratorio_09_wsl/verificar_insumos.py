import json, hashlib, stat
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
from control import ROOT, REPO, save, git, sha, utc
review=REPO.parent/'REVISION_LABORATORIO_09_WSL_v1.0'
outer=ROOT/'insumos'/'REVISION_LABORATORIO_09_WSL_v1.0.zip'
original=review/'recibido'/'EVIDENCIA_LABORATORIO_09_WSL_v1.0.zip'
assert sha(original.read_bytes())=='6aaeb6ce9e0cf781239499fae2f57bb147b5b2b07b7a20d5cfbd5d61a4ffb239'
results={}
for label,archive,extract in [('revision',outer,review),('evidencia',original,ROOT/'evidencia_recibida')]:
    with ZipFile(archive) as z:
        names=z.namelist(); files=[n for n in names if not n.endswith('/')]
        assert len(names)==len(set(names)) and z.testzip() is None
        for info in z.infolist():
            p=PurePosixPath(info.filename)
            assert not p.is_absolute() and '..' not in p.parts and ':' not in info.filename and '\\' not in info.filename
            assert not stat.S_ISLNK(info.external_attr>>16)
        prefix=files[0].split('/')[0]+'/'
        assert all(n.startswith(prefix) for n in files)
        if label=='evidencia':
            extract.mkdir()
            for n in files:
                p=extract/n[len(prefix):];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
        assert {p.relative_to(extract).as_posix() for p in extract.rglob('*') if p.is_file()}=={n[len(prefix):] for n in files}
        for n in files: assert (extract/n[len(prefix):]).read_bytes()==z.read(n)
        results[label]={'archivo':archive.name,'sha256':sha(archive.read_bytes()),'archivos':len(files),'crc':'APROBADO','extraccion_identica':'APROBADO'}
base=REPO.parent/'INTEGRACION_LABORATORIO_09_v1.0'
b=json.loads((base/'BASE_INTEGRACION.json').read_text())
assert sha((base/'INTEGRAR_LABORATORIO_09.patch').read_bytes())==b['sha256_parche']
assert (ROOT/'operaciones/indice_inicial.stdout.txt').read_text().strip()==b['arbol_preparado']
assert set((ROOT/'operaciones/rutas_indice_inicial.stdout.txt').read_text().splitlines())==set(b['rutas_parche'])
assert not (ROOT/'operaciones/sin_preparar_inicial.stdout.txt').read_text().strip()
assert not (ROOT/'operaciones/nuevos_inicial.stdout.txt').read_text().strip()
for filename in ['antes.json','preparado.json','despues.json']:
    doc=json.loads((ROOT/'evidencia_recibida'/filename).read_text())
    results[filename]={k:doc[k] for k in ['estado','head','arbol_head','main_local','arbol_indice','rama','fecha_hora_utc']}
    assert doc['head']==b['commit_base']
manifest=json.loads((ROOT/'evidencia_recibida/MANIFIESTO_ENVIO.json').read_text())
entries=manifest['archivos']; expected={e['archivo'] for e in entries}
actual={p.relative_to(ROOT/'evidencia_recibida').as_posix() for p in (ROOT/'evidencia_recibida').rglob('*') if p.is_file()}
assert len(expected)==len(entries) and actual==expected|{'MANIFIESTO_ENVIO.json'}
for e in entries:
    data=(ROOT/'evidencia_recibida'/e['archivo']).read_bytes()
    assert sha(data)==e['sha256'] and len(data)==e['bytes']
# El índice y el disco completo se comparan contra el árbol funcional auditado.
raw=git('inventario_arbol_funcional','ls-tree','-r','-z',b['arbol_preparado'])
rows=[]
for record in raw.split('\0'):
    if not record: continue
    meta,path=record.split('\t',1);mode,kind,oid=meta.split()
    data=(REPO/path).read_bytes()
    assert kind=='blob' and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,path
    rows.append({'ruta':path,'modo':mode,'blob':oid,'sha256':sha(data),'bytes':len(data)})
save('identidad_funcional_inicial.json',{'estado':'APROBADO','fecha_utc':utc(),'arbol':b['arbol_preparado'],'archivos':rows})
results.update({'estado':'APROBADO','fecha_utc':utc(),'arbol_funcional':b['arbol_preparado'],'archivos_arbol_identicos':len(rows),'rutas_preparadas':len(b['rutas_parche']),'manifiesto_original':{'declarados':len(entries),'coincidentes':len(entries),'cobertura':'APROBADO'},'parche':'Conservado; no reaplicado'})
save('VALIDACION_INSUMOS.json',results)
print(json.dumps({k:v for k,v in results.items() if k!='antes.json'},ensure_ascii=False,indent=2))
