import os, sys, json, hashlib, subprocess, datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
def save(name, value): (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def sanitize(s):
    return s.replace(str(REPO),"<REPOSITORIO>").replace(str(REPO.parent),"<CONTENEDOR>")
def run(name,args,cwd=None,ok=(0,)):
    folder=ROOT/"operaciones"
    originals=ROOT.with_name(ROOT.name+"_capturas_originales")
    originals.mkdir(exist_ok=True)
    assert not (folder/(name+".json")).exists(), name
    start=utc()
    p=subprocess.run(args,cwd=cwd or REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","GIT_TERMINAL_PROMPT":"0"})
    result={"comando":[sanitize(str(a)) for a in args],"cwd":sanitize(str(cwd or REPO)),"inicio_utc":start,"fin_utc":utc(),"codigo_salida":p.returncode,"estado":"APROBADO" if p.returncode in ok else "FALLIDO","capturas":{}}
    for stream,data in (("stdout",p.stdout),("stderr",p.stderr)):
        (originals/(name+"."+stream+".txt")).write_bytes(data)
        final=sanitize(data.decode("utf-8",errors="replace")).encode()
        path=folder/(name+"."+stream+".txt")
        path.write_bytes(final)
        result["capturas"][stream]={"archivo":path.relative_to(ROOT).as_posix(),"sha256_captura_original":sha(data),"sha256_final":sha(final),"saneamiento":data!=final,"bytes_finales":len(final)}
    (folder/(name+".json")).write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(name+": "+result["estado"]+" ("+str(p.returncode)+")",flush=True)
    if p.returncode not in ok: raise RuntimeError(name+": "+sanitize(p.stderr.decode(errors="replace"))[:1500])
    return p.stdout.decode("utf-8")
def git(name,*args): return run(name,["git",*args])
if __name__=="__main__": run(sys.argv[1],sys.argv[2:])
