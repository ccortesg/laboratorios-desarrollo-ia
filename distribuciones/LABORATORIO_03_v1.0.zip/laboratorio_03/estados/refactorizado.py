"""Busqueda con acceso al catalogo y filtro de nombres separados."""

from laboratorio import consultar_catalogo


def filtrar_por_nombre(articulos, texto):
    """Devuelve coincidencias sin consultar datos ni modificar la lista."""
    termino = texto.strip().casefold()
    resultado = []
    for articulo in articulos:
        if termino in articulo["nombre"].casefold():
            resultado.append(articulo)
    return resultado


def buscar_catalogo(almacen, texto):
    """Filtra nombres dentro de los articulos disponibles del almacen."""
    articulos = consultar_catalogo("solucion", almacen)
    return filtrar_por_nombre(articulos, texto)
